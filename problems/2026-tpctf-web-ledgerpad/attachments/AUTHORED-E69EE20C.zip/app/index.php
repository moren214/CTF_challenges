<?php echo "OK\n";
