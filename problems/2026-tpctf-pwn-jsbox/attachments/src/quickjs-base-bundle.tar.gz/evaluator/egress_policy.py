"""Legacy iptables/ip6tables endpoint-only egress policy for Phase 3A.

The policy is installed *inside a holder container's network namespace*, never
in the controller/host namespace.  The observed Linux platform does not support
nftables/Netlink, so this module uses the explicit legacy binaries:

* ``iptables-legacy-restore`` / ``iptables-legacy-save``
* ``ip6tables-legacy-restore`` / ``ip6tables-legacy-save``

The namespace is entered with ``nsenter --net`` only.  Mount, PID, user and IPC
namespaces are never entered.

Security shape (IPv4 filter table owned by the disposable holder netns):

* INPUT/OUTPUT/FORWARD policy DROP;
* the only accept rules are IPv4 TCP to the current numeric target:8000
  (OUTPUT) and established replies from that target:8000 (INPUT);
* explicit deny rules with counters for the target's other ports, the instance
  gateway, a second-network sentinel, Docker's embedded DNS, loopback,
  generic UDP, and everything else;
* no rule ever accepts IPv6; the IPv6 filter table defaults to DROP with
  explicit counters for ``::1`` and the configured test address.

IPv4 and IPv6 are restored one family at a time.  Each family restore is
atomic, but the two-family sequence is **not** atomic.  The safety property is
that only the fixed trusted idle holder exists in the namespace until both
families have been installed and read back successfully.  A failed operation
never starts the solver.

The module performs no host firewall write.  Host-side reads (``*-save``) are
used only to prove that installing policy in the holder namespace did not
change the controller firewall.
"""

from __future__ import annotations

import hashlib
import ipaddress
import os
import re
import shlex
import subprocess
from dataclasses import dataclass
from typing import Callable

TARGET_PORT = 8000
DOCKER_DNS = "127.0.0.11"
LOOPBACK_V4 = "127.0.0.0/8"
IPV6_LOOPBACK = "::1"
IPV6_TEST_ADDRESS = "2001:db8::1"
BACKEND = "iptables-legacy"
WAIT_SECONDS = 5

LEGACY_BINARIES = {
    "ipv4_restore": "iptables-legacy-restore",
    "ipv4_save": "iptables-legacy-save",
    "ipv6_restore": "ip6tables-legacy-restore",
    "ipv6_save": "ip6tables-legacy-save",
    "ip": "ip",
}

_MARKER_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]{0,27}$")
_CHAIN_POLICY_RE = re.compile(
    r"^:(INPUT|OUTPUT|FORWARD)\s+(ACCEPT|DROP)\s+\[(\d+):(\d+)\]$")
_CUSTOM_CHAIN_RE = re.compile(
    r"^:([A-Za-z_][A-Za-z0-9_]{0,27})\s+-\s+\[(\d+):(\d+)\]$")
_COUNTER_PREFIX_RE = re.compile(r"^\[(\d+):(\d+)\]\s+(.*)$")
_COUNTER_SUFFIX_RE = re.compile(r"^(.*?)\s+-c\s+(\d+)\s+(\d+)\s*$")
_FAMILY_CHAINS = ("INPUT", "OUTPUT", "FORWARD")


class EgressPolicyError(RuntimeError):
    """Strict egress policy could not be built, installed or verified."""


# ---------------------------------------------------------------------------
# Validation and pure rule construction

def validate_marker(marker: str) -> str:
    if not isinstance(marker, str) or not _MARKER_RE.fullmatch(marker):
        raise EgressPolicyError("invalid egress rule marker")
    return marker


def policy_marker(instance_id: str) -> str:
    """Derive a unique ownership-marker chain name from an instance id.

    The marker is an unused, empty iptables chain.  Chain names are limited
    to 28 characters by the legacy iptables tooling, so a truncated digest is
    used instead of the raw instance id.  No kernel match module is involved:
    the observed platform does not expose the ``comment`` match.
    """
    if not isinstance(instance_id, str) or not instance_id:
        raise EgressPolicyError("invalid instance id for egress policy")
    digest = hashlib.sha256(
        instance_id.encode("utf-8", "surrogatepass")).hexdigest()
    return validate_marker("QJS_" + digest[:20])


def validate_ipv4(value: str) -> str:
    """Return a canonical numeric IPv4 address or fail closed."""
    if not isinstance(value, str) or not value:
        raise EgressPolicyError("target endpoint is not a numeric IPv4 address")
    try:
        address = ipaddress.ip_address(value)
    except ValueError as exc:
        raise EgressPolicyError(
            "target endpoint is not a numeric IPv4 address") from exc
    if address.version != 4:
        raise EgressPolicyError(
            "target endpoint is not a numeric IPv4 address")
    return str(address)


def validate_ipv6(value: str) -> str:
    if not isinstance(value, str) or not value:
        raise EgressPolicyError("not a numeric IPv6 address")
    try:
        address = ipaddress.ip_address(value)
    except ValueError as exc:
        raise EgressPolicyError("not a numeric IPv6 address") from exc
    if address.version != 6:
        raise EgressPolicyError("not a numeric IPv6 address")
    return str(address)


def validate_port(port: int) -> int:
    if not isinstance(port, int) or not (0 < port < 65536):
        raise EgressPolicyError("invalid target port")
    return port


def _policy_marker_chain(marker: str) -> str:
    """Render the namespace-local ownership marker chain declaration.

    The chain is declared but never referenced, so it cannot change packet
    processing.  It is used only to prove that a readback (or a host firewall
    snapshot) does or does not belong to this instance.
    """
    return f":{validate_marker(marker)} - [0:0]"


def _iptables_policy_header(marker: str) -> list[str]:
    return [
        "*filter",
        ":INPUT DROP [0:0]",
        ":FORWARD DROP [0:0]",
        ":OUTPUT DROP [0:0]",
        _policy_marker_chain(marker),
    ]


def render_ipv4_policy(marker: str, target_ip: str, *,
                       gateway_ip: str | None = None,
                       sentinel_ip: str | None = None,
                       port: int = TARGET_PORT) -> str:
    """Render the full IPv4 filter table restored inside the holder netns.

    The restore replaces the namespace's filter table as one atomic family
    operation.  It never includes a host namespace reference.
    """
    marker = validate_marker(marker)
    target_ip = validate_ipv4(target_ip)
    port = validate_port(port)
    if gateway_ip:
        gateway_ip = validate_ipv4(gateway_ip)
    if sentinel_ip:
        sentinel_ip = validate_ipv4(sentinel_ip)
    lines = _iptables_policy_header(marker)
    # OUTPUT: exactly one endpoint accept.
    lines.append(
        f"-A OUTPUT -d {target_ip} -p tcp --dport {port} "
        f"-m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT")
    lines.append(f"-A OUTPUT -d {target_ip} -j DROP")
    if gateway_ip:
        lines.append(f"-A OUTPUT -d {gateway_ip} -j DROP")
    if sentinel_ip:
        lines.append(f"-A OUTPUT -d {sentinel_ip} -j DROP")
    lines.append(f"-A OUTPUT -d {DOCKER_DNS} -j DROP")
    lines.append(f"-A OUTPUT -d {LOOPBACK_V4} -j DROP")
    lines.append(f"-A OUTPUT -p udp -j DROP")
    lines.append(f"-A OUTPUT -j DROP")
    # INPUT: only established replies from the accepted target endpoint.
    lines.append(
        f"-A INPUT -s {target_ip} -p tcp --sport {port} "
        f"-m conntrack --ctstate ESTABLISHED -j ACCEPT")
    lines.append(f"-A INPUT -s {target_ip} -j DROP")
    lines.append(f"-A INPUT -d {LOOPBACK_V4} -j DROP")
    lines.append(f"-A INPUT -j DROP")
    # FORWARD: never route for an untrusted process.
    lines.append(f"-A FORWARD -j DROP")
    lines.append("COMMIT")
    return "\n".join(lines) + "\n"


def render_ipv6_policy(marker: str, *,
                       loopback: str = IPV6_LOOPBACK,
                       test_address: str = IPV6_TEST_ADDRESS) -> str:
    """Render the full IPv6 filter table; there is no IPv6 accept rule."""
    marker = validate_marker(marker)
    loopback = validate_ipv6(loopback)
    test_address = validate_ipv6(test_address)
    lines = _iptables_policy_header(marker)
    lines.append(f"-A OUTPUT -d {loopback} -j DROP")
    lines.append(f"-A OUTPUT -d {test_address} -j DROP")
    lines.append(f"-A OUTPUT -p udp -j DROP")
    lines.append(f"-A OUTPUT -j DROP")
    lines.append(f"-A INPUT -d {loopback} -j DROP")
    lines.append(f"-A INPUT -j DROP")
    lines.append(f"-A FORWARD -j DROP")
    lines.append("COMMIT")
    return "\n".join(lines) + "\n"


def _expected_ipv4_rules(marker: str, target_ip: str, *,
                         gateway_ip: str | None,
                         sentinel_ip: str | None,
                         port: int) -> list[tuple[str, str, str]]:
    """Return (chain, counter_key, canonical rule) in required order."""
    output = [
        ("OUTPUT", "output_allow",
         f"-A OUTPUT -d {target_ip} -p tcp --dport {port} "
         f"-m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT"),
        ("OUTPUT", "output_target_other_port",
         f"-A OUTPUT -d {target_ip} -j DROP"),
    ]
    if gateway_ip:
        output.append(
            ("OUTPUT", "output_gateway",
             f"-A OUTPUT -d {gateway_ip} -j DROP"))
    if sentinel_ip:
        output.append(
            ("OUTPUT", "output_second_network",
             f"-A OUTPUT -d {sentinel_ip} -j DROP"))
    output.extend([
        ("OUTPUT", "output_docker_dns",
         f"-A OUTPUT -d {DOCKER_DNS} -j DROP"),
        ("OUTPUT", "output_loopback",
         f"-A OUTPUT -d {LOOPBACK_V4} -j DROP"),
        ("OUTPUT", "output_udp", f"-A OUTPUT -p udp -j DROP"),
        ("OUTPUT", "output_default", f"-A OUTPUT -j DROP"),
    ])
    input_rules = [
        ("INPUT", "input_established",
         f"-A INPUT -s {target_ip} -p tcp --sport {port} "
         f"-m conntrack --ctstate ESTABLISHED -j ACCEPT"),
        ("INPUT", "input_target_other_port",
         f"-A INPUT -s {target_ip} -j DROP"),
        ("INPUT", "input_loopback",
         f"-A INPUT -d {LOOPBACK_V4} -j DROP"),
        ("INPUT", "input_default", f"-A INPUT -j DROP"),
    ]
    forward = [("FORWARD", "forward_default", f"-A FORWARD -j DROP")]
    return output + input_rules + forward


def _expected_ipv6_rules(marker: str, *,
                         loopback: str,
                         test_address: str) -> list[tuple[str, str, str]]:
    return [
        ("OUTPUT", "output_v6_loopback",
         f"-A OUTPUT -d {loopback} -j DROP"),
        ("OUTPUT", "output_v6_test_address",
         f"-A OUTPUT -d {test_address} -j DROP"),
        ("OUTPUT", "output_v6_udp", f"-A OUTPUT -p udp -j DROP"),
        ("OUTPUT", "output_v6_default", f"-A OUTPUT -j DROP"),
        ("INPUT", "input_v6_loopback",
         f"-A INPUT -d {loopback} -j DROP"),
        ("INPUT", "input_v6_default", f"-A INPUT -j DROP"),
        ("FORWARD", "forward_v6_default", f"-A FORWARD -j DROP"),
    ]


# ---------------------------------------------------------------------------
# Legacy iptables-save parsing and readback validation

def _canonical_rule(rule: str) -> str:
    """Canonicalize an iptables rule for strict comparison.

    ``iptables-save`` adds ``-m tcp``/``-m udp`` and full-length address masks,
    and may print conntrack state bits in a different order.  Those harmless
    representation differences are normalized; everything else must match
    exactly.
    """
    tokens = shlex.split(rule)
    cleaned: list[str] = []
    index = 0
    while index < len(tokens):
        token = tokens[index]
        if (token == "-m" and index + 1 < len(tokens)
                and tokens[index + 1] in ("tcp", "udp")):
            index += 2
            continue
        if token in ("-s", "-d") and index + 1 < len(tokens):
            value = tokens[index + 1]
            if "/" in value:
                address, prefix = value.rsplit("/", 1)
                try:
                    parsed = ipaddress.ip_address(address)
                except ValueError:
                    parsed = None
                if parsed is not None:
                    full = 32 if parsed.version == 4 else 128
                    if prefix == str(full):
                        value = address
            cleaned.extend((token, value))
            index += 2
            continue
        if token == "--ctstate" and index + 1 < len(tokens):
            states = sorted(tokens[index + 1].split(","))
            cleaned.extend((token, ",".join(states)))
            index += 2
            continue
        cleaned.append(token)
        index += 1
    return " ".join(cleaned)


def _split_counters(line: str) -> tuple[tuple[int, int] | None, str]:
    match = _COUNTER_PREFIX_RE.match(line)
    if match:
        return (int(match.group(1)), int(match.group(2))), match.group(3)
    match = _COUNTER_SUFFIX_RE.match(line)
    if match:
        return (int(match.group(2)), int(match.group(3))), match.group(1)
    return None, line


def parse_filter_save(text: str, family: str, marker: str) -> dict:
    """Parse ``iptables-save -t filter -c`` output for one family."""
    if family not in ("ipv4", "ipv6"):
        raise EgressPolicyError("invalid filter family")
    if not isinstance(text, str):
        raise EgressPolicyError("policy readback is not text")
    marker = validate_marker(marker)
    allowed_chains = set(_FAMILY_CHAINS) | {marker}
    lines: list[str] = []
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        lines.append(line)
    if not lines:
        raise EgressPolicyError("policy readback is empty")
    if "*filter" not in lines or "COMMIT" not in lines:
        raise EgressPolicyError("policy readback is not a filter table")
    chains: dict[str, dict] = {}
    table_seen = False
    saw_rule = False
    for line in lines:
        if line.startswith("*"):
            if line != "*filter" or table_seen:
                raise EgressPolicyError(
                    "policy readback contains an unexpected table")
            table_seen = True
            continue
        if line == "COMMIT":
            continue
        if not table_seen:
            raise EgressPolicyError("policy rule precedes the filter table")
        match = _CHAIN_POLICY_RE.match(line)
        if match:
            name = match.group(1)
            if name in chains:
                raise EgressPolicyError("duplicate policy chain")
            if saw_rule:
                raise EgressPolicyError(
                    "chain policy appears after a rule")
            chains[name] = {
                "policy": match.group(2),
                "policy_packets": int(match.group(3)),
                "policy_bytes": int(match.group(4)),
                "rules": [],
            }
            continue
        custom = _CUSTOM_CHAIN_RE.match(line)
        if custom:
            name = custom.group(1)
            if name != marker:
                raise EgressPolicyError("unexpected chain declaration")
            if name in chains:
                raise EgressPolicyError("duplicate policy chain")
            if saw_rule:
                raise EgressPolicyError(
                    "chain policy appears after a rule")
            chains[name] = {
                "policy": "-",
                "policy_packets": int(custom.group(2)),
                "policy_bytes": int(custom.group(3)),
                "rules": [],
            }
            continue
        if line.startswith(":"):
            raise EgressPolicyError("unexpected chain declaration")
        candidate = line
        counters = None
        prefix = _COUNTER_PREFIX_RE.match(candidate)
        if prefix:
            counters = (int(prefix.group(1)), int(prefix.group(2)))
            candidate = prefix.group(3)
        if candidate.startswith("-A "):
            suffix_counters, stripped = _split_counters(candidate)
            if suffix_counters is not None:
                counters = suffix_counters
                candidate = stripped
            if counters is None:
                raise EgressPolicyError(
                    "policy rule is missing kernel counters")
            tokens = shlex.split(candidate)
            if len(tokens) < 2 or tokens[0] not in ("-A",):
                raise EgressPolicyError("invalid policy rule")
            chain = tokens[1]
            if chain not in chains:
                raise EgressPolicyError(
                    "rule references an unknown or undeclared chain")
            chains[chain]["rules"].append({
                "rule": candidate,
                "packets": counters[0],
                "bytes": counters[1],
            })
            saw_rule = True
            continue
        if line.startswith(("-N ", "-P ", "-I ", "-R ")):
            raise EgressPolicyError("unexpected policy mutation syntax")
        raise EgressPolicyError("unexpected policy readback line")
    if set(chains) != allowed_chains:
        raise EgressPolicyError(
            "policy readback chains are not the three required base chains "
            "plus the ownership marker")
    for name, entry in chains.items():
        if name == marker:
            if entry["policy"] != "-" or entry["rules"]:
                raise EgressPolicyError(
                    "ownership marker chain must be empty and policy-less")
            continue
        if entry["policy"] != "DROP":
            raise EgressPolicyError(
                f"{name}: chain policy is not DROP")
    return {"family": family, "chains": chains}


def _validate_family(parsed: dict, expected: list[tuple[str, str, str]],
                     errors: list[str], counters: dict) -> dict:
    family = parsed["family"]
    chains = parsed["chains"]
    family_ok = True
    for chain in _FAMILY_CHAINS:
        actual = chains[chain]["rules"]
        wanted = [(key, rule) for (want_chain, key, rule) in expected
                  if want_chain == chain]
        if len(actual) != len(wanted):
            errors.append(
                f"{family} {chain}: expected {len(wanted)} rules, "
                f"found {len(actual)}")
            family_ok = False
        for index, (key, rule) in enumerate(wanted):
            if index >= len(actual):
                break
            expected_rule = _canonical_rule(rule)
            actual_rule = _canonical_rule(actual[index]["rule"])
            if actual_rule != expected_rule:
                errors.append(
                    f"{family} {chain}: rule {index + 1} ({key}) does not "
                    "match the required policy")
                family_ok = False
                continue
            counters[key] = {
                "packets": actual[index]["packets"],
                "bytes": actual[index]["bytes"],
            }
    return {
        "family": family,
        "ok": family_ok,
        "chains": {
            name: {
                "policy": entry["policy"],
                "policy_packets": entry["policy_packets"],
                "policy_bytes": entry["policy_bytes"],
                "rule_count": len(entry["rules"]),
            }
            for name, entry in chains.items()
        },
    }


def validate_readback(ipv4_text: str, ipv6_text: str, marker: str,
                      target_ip: str, *, port: int = TARGET_PORT,
                      gateway_ip: str | None = None,
                      sentinel_ip: str | None = None,
                      ipv6_loopback: str = IPV6_LOOPBACK,
                      ipv6_test_address: str = IPV6_TEST_ADDRESS) -> dict:
    """Validate both kernel filter tables against the required policy.

    The returned counters are kernel packet/byte counts keyed by stable,
    non-secret names.  Rules contain only numeric endpoints and the ownership
    marker, never a flag or solver content.
    """
    errors: list[str] = []
    counters: dict[str, dict] = {}
    try:
        marker = validate_marker(marker)
        target_ip = validate_ipv4(target_ip)
        port = validate_port(port)
        if gateway_ip:
            gateway_ip = validate_ipv4(gateway_ip)
        if sentinel_ip:
            sentinel_ip = validate_ipv4(sentinel_ip)
        ipv6_loopback = validate_ipv6(ipv6_loopback)
        ipv6_test_address = validate_ipv6(ipv6_test_address)
    except EgressPolicyError as exc:
        return {"ok": False, "errors": [str(exc)], "counters": {},
                "marker": marker if isinstance(marker, str) else None,
                "families": {}, "atomicity": atomicity_property()}
    try:
        parsed4 = parse_filter_save(ipv4_text, "ipv4", marker)
        parsed6 = parse_filter_save(ipv6_text, "ipv6", marker)
    except EgressPolicyError as exc:
        return {"ok": False, "errors": [str(exc)], "counters": {},
                "marker": marker, "families": {}, "atomicity": atomicity_property()}
    family4 = _validate_family(
        parsed4,
        _expected_ipv4_rules(
            marker, target_ip, gateway_ip=gateway_ip,
            sentinel_ip=sentinel_ip, port=port),
        errors, counters)
    family6 = _validate_family(
        parsed6,
        _expected_ipv6_rules(
            marker, loopback=ipv6_loopback,
            test_address=ipv6_test_address),
        errors, counters)
    return {
        "ok": not errors,
        "errors": errors,
        "marker": marker,
        "target_ip": target_ip,
        "port": port,
        "families": {"ipv4": family4, "ipv6": family6},
        "chains": {
            "ipv4": family4["chains"],
            "ipv6": family6["chains"],
        },
        "counters": counters,
        "atomicity": atomicity_property(),
    }


def atomicity_property() -> dict:
    return {
        "ipv4_restore_atomic": True,
        "ipv6_restore_atomic": True,
        "cross_family_sequence_atomic": False,
        "safety_property": (
            "Only the fixed trusted idle holder exists in the namespace "
            "until both families are installed and read back; a failed "
            "operation never starts the solver."),
    }


def counter_packets(view: dict, key: str) -> int | None:
    value = (view.get("counters") or {}).get(key)
    if not isinstance(value, dict):
        return None
    packets = value.get("packets")
    return packets if isinstance(packets, int) else None


# ---------------------------------------------------------------------------
# Namespace FD handling

@dataclass
class NamespaceHandle:
    fd: int
    inode: int
    host_inode: int
    path: str
    close_fn: Callable[[int], None] = os.close
    closed: bool = False

    def close(self) -> None:
        if self.closed:
            return
        self.closed = True
        _safe_close(self.fd, self.close_fn)

    @property
    def distinct_from_host(self) -> bool:
        return bool(self.inode and self.host_inode
                    and self.inode != self.host_inode)


def _safe_close(fd: int, close_fn: Callable[[int], None]) -> None:
    try:
        close_fn(fd)
    except OSError:
        pass


def open_network_namespace(pid: int, *, host_ns_path: str = "/proc/self/ns/net",
                           open_fn=os.open, fstat_fn=os.fstat,
                           stat_fn=os.stat,
                           close_fn=os.close) -> NamespaceHandle:
    """Open and hold a container network-namespace FD.

    The FD is opened from ``/proc/<pid>/ns/net``.  It must not be stdio, must
    be a network namespace, and must not be the host/controller namespace.
    ``close_fn`` is injected so native tests never close a real process fd
    returned by a fake opener.
    """
    if not isinstance(pid, int) or pid <= 0:
        raise EgressPolicyError("invalid holder PID for namespace open")
    path = f"/proc/{pid}/ns/net"
    try:
        fd = open_fn(path, os.O_RDONLY)
    except OSError as exc:
        raise EgressPolicyError(
            "could not open the holder network namespace") from exc
    try:
        if fd < 3:
            raise EgressPolicyError(
                "network namespace FD would collide with stdio")
        inode = fstat_fn(fd).st_ino
        host_inode = stat_fn(host_ns_path).st_ino
    except BaseException:
        _safe_close(fd, close_fn)
        raise
    if inode == host_inode:
        _safe_close(fd, close_fn)
        raise EgressPolicyError(
            "holder network namespace is the host network namespace")
    return NamespaceHandle(fd=fd, inode=inode, host_inode=host_inode,
                           path=path, close_fn=close_fn)


def namespace_matches_pid(handle: NamespaceHandle, pid: int,
                          stat_fn=os.stat, fstat_fn=os.fstat) -> bool:
    """Recheck an open FD and a PID's current netns inode for PID reuse."""
    if handle.closed or not isinstance(pid, int) or pid <= 0:
        return False
    try:
        current = stat_fn(f"/proc/{pid}/ns/net").st_ino
        held = fstat_fn(handle.fd).st_ino
    except OSError:
        return False
    return current == handle.inode and held == handle.inode


# ---------------------------------------------------------------------------
# Bounded nsenter/legacy-iptables subprocesses

def nsenter_argv(fd: int, tail: list[str]) -> list[str]:
    if not isinstance(fd, int) or fd < 3:
        raise EgressPolicyError("refusing unsafe namespace FD")
    return ["nsenter", f"--net=/proc/self/fd/{fd}", "--", *tail]


def install_v4_argv(fd: int) -> list[str]:
    return nsenter_argv(fd, [
        LEGACY_BINARIES["ipv4_restore"], "--wait=" + str(WAIT_SECONDS)])


def install_v6_argv(fd: int) -> list[str]:
    return nsenter_argv(fd, [
        LEGACY_BINARIES["ipv6_restore"], "--wait=" + str(WAIT_SECONDS)])


def readback_v4_argv(fd: int) -> list[str]:
    return nsenter_argv(fd, [
        LEGACY_BINARIES["ipv4_save"], "-t", "filter", "-c"])


def readback_v6_argv(fd: int) -> list[str]:
    return nsenter_argv(fd, [
        LEGACY_BINARIES["ipv6_save"], "-t", "filter", "-c"])


def host_readback_v4_argv() -> list[str]:
    # Host comparison is policy-only: counter values are deliberately
    # excluded so unrelated host traffic cannot change it.
    return [LEGACY_BINARIES["ipv4_save"], "-t", "filter"]


def host_readback_v6_argv() -> list[str]:
    return [LEGACY_BINARIES["ipv6_save"], "-t", "filter"]


def ipv6_link_up_argv(fd: int) -> list[str]:
    return nsenter_argv(fd, [
        LEGACY_BINARIES["ip"], "link", "set", "lo", "up"])


def ipv6_address_argv(fd: int, address: str) -> list[str]:
    address = validate_ipv6(address)
    return nsenter_argv(fd, [
        LEGACY_BINARIES["ip"], "-6", "addr", "replace",
        f"{address}/128", "dev", "lo"])


def ipv6_address_readback_argv(fd: int) -> list[str]:
    return nsenter_argv(fd, [
        LEGACY_BINARIES["ip"], "-6", "addr", "show", "dev", "lo"])


def run_command(argv: list[str], input_text: str | None = None,
                timeout: float = 30.0, pass_fds: tuple = (),
                run_fn=subprocess.run) -> subprocess.CompletedProcess:
    return run_fn(
        argv, input=input_text, capture_output=True, text=True,
        timeout=timeout, pass_fds=tuple(pass_fds), close_fds=True)


def normalize_firewall_text(text: str | None) -> str:
    """Strip counter values and comment lines from a save readback.

    Host firewall comparison must describe policy, not elapsed counters or
    the save tool's generation timestamp.
    """
    normalized: list[str] = []
    for raw in (text or "").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        match = _COUNTER_PREFIX_RE.match(line)
        if match:
            line = match.group(3)
        match = _COUNTER_SUFFIX_RE.match(line)
        if match:
            line = match.group(1)
        line = re.sub(r"\[\d+:\d+\]", "[0:0]", line)
        normalized.append(line)
    return "\n".join(normalized)


def firewall_digest(ipv4_text: str | None, ipv6_text: str | None) -> str:
    payload = (b"ipv4\0" + normalize_firewall_text(ipv4_text).encode("utf-8")
               + b"\0ipv6\0"
               + normalize_firewall_text(ipv6_text).encode("utf-8"))
    return hashlib.sha256(payload).hexdigest()


def marker_present(text: str | None, marker: str) -> bool:
    marker = validate_marker(marker)
    return marker in (text or "")


class PolicyRuntime:
    """Bounded operations for one held network namespace plus read-only host
    firewall reads."""

    def __init__(self, timeout: float = 30.0, runner=None):
        if not (timeout > 0):
            raise EgressPolicyError("policy timeout must be positive")
        self.timeout = timeout
        self._runner = runner or run_command

    def _check_handle(self, handle: NamespaceHandle) -> None:
        if handle.closed:
            raise EgressPolicyError("network namespace FD is closed")
        if handle.fd < 3:
            raise EgressPolicyError("refusing unsafe namespace FD")
        if not handle.distinct_from_host:
            raise EgressPolicyError(
                "network namespace FD is the host namespace")

    def install_v4(self, handle: NamespaceHandle, batch: str):
        self._check_handle(handle)
        return self._runner(
            install_v4_argv(handle.fd), batch, self.timeout, (handle.fd,))

    def install_v6(self, handle: NamespaceHandle, batch: str):
        self._check_handle(handle)
        return self._runner(
            install_v6_argv(handle.fd), batch, self.timeout, (handle.fd,))

    def readback_v4(self, handle: NamespaceHandle):
        self._check_handle(handle)
        return self._runner(
            readback_v4_argv(handle.fd), None, self.timeout, (handle.fd,))

    def readback_v6(self, handle: NamespaceHandle):
        self._check_handle(handle)
        return self._runner(
            readback_v6_argv(handle.fd), None, self.timeout, (handle.fd,))

    def host_readback_v4(self):
        return self._runner(
            host_readback_v4_argv(), None, self.timeout, ())

    def host_readback_v6(self):
        return self._runner(
            host_readback_v6_argv(), None, self.timeout, ())

    def configure_ipv6_address(self, handle: NamespaceHandle, address: str):
        self._check_handle(handle)
        link = self._runner(
            ipv6_link_up_argv(handle.fd), None, self.timeout, (handle.fd,))
        if link.returncode != 0:
            return link
        return self._runner(
            ipv6_address_argv(handle.fd, address), None, self.timeout,
            (handle.fd,))

    def readback_ipv6_address(self, handle: NamespaceHandle):
        self._check_handle(handle)
        return self._runner(
            ipv6_address_readback_argv(handle.fd), None, self.timeout,
            (handle.fd,))
