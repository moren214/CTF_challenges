#!/usr/bin/env python3
"""Local evaluation controller for separate QuickJS challenge instances.

A new instance gets a fresh random flag, an isolated working directory, and a
loopback adapter endpoint.  The operator supplies an explicit solver argv list;
the controller appends only the endpoint and judges an exact returned flag.
No shell is used to construct or run the solver.

Security boundary: this is a local, same-user evaluation harness.  It keeps the
flag out of solver argv/env/cwd/stdin and public reports, but it does not claim
OS-level isolation from a process running as the same user.
"""

from __future__ import annotations

import argparse
import json
import os
import secrets
import shutil
import signal
import socket
import subprocess
import sys
import tempfile
import threading
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_RUNNER = ROOT / "build" / "qjs_runner"
DEFAULT_ADAPTER = ROOT / "adapter" / "server.py"
SOLVER_OUTPUT_LIMIT = 64 * 1024
MINIMAL_SOLVER_ENV_KEYS = ("PATH", "SYSTEMROOT", "TMPDIR", "TEMP", "TMP")


class EvaluationError(RuntimeError):
    pass


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def new_flag() -> str:
    return "FLAG{" + secrets.token_hex(16) + "}"


def free_loopback_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        return sock.getsockname()[1]


def _children_via_proc(pid: int) -> list[int] | None:
    proc_root = Path("/proc")
    if not proc_root.is_dir():
        return None
    children_file = proc_root / str(pid) / "task" / str(pid) / "children"
    if children_file.is_file():
        try:
            return [int(value) for value in children_file.read_text().split()]
        except (OSError, ValueError):
            return []
    children = []
    try:
        entries = list(proc_root.iterdir())
    except OSError:
        return []
    for entry in entries:
        if not entry.name.isdigit():
            continue
        stat_path = entry / "stat"
        try:
            text = stat_path.read_text()
        except OSError:
            continue
        close = text.rfind(")")
        if close < 0:
            continue
        fields = text[close + 2:].split()
        if len(fields) >= 2 and fields[1].isdigit():
            if int(fields[1]) == pid:
                children.append(int(entry.name))
    return children


def _children_via_ps(pid: int) -> list[int]:
    try:
        proc = subprocess.run(["ps", "-Ao", "pid=,ppid="],
                              capture_output=True, text=True, timeout=5)
    except (OSError, subprocess.SubprocessError):
        return []
    children = []
    for line in proc.stdout.splitlines():
        parts = line.split()
        if len(parts) == 2 and parts[0].isdigit() and parts[1].isdigit():
            if int(parts[1]) == pid:
                children.append(int(parts[0]))
    return children


def process_children(pid: int) -> list[int]:
    children = _children_via_proc(pid)
    if children is None:
        children = _children_via_ps(pid)
    return children


def process_descendants(pid: int) -> list[int]:
    result = []
    seen = {pid}
    queue = [pid]
    while queue:
        parent = queue.pop(0)
        for child in process_children(parent):
            if child in seen:
                continue
            seen.add(child)
            result.append(child)
            queue.append(child)
    return result


def terminate_process_tree(proc: subprocess.Popen, grace: float = 2.0) -> None:
    """Terminate a target and every descendant the controller can find."""
    descendants = process_descendants(proc.pid)
    if proc.poll() is None:
        try:
            os.killpg(proc.pid, signal.SIGTERM)
        except (ProcessLookupError, PermissionError, OSError):
            try:
                proc.terminate()
            except (ProcessLookupError, PermissionError, OSError):
                pass
        try:
            proc.wait(timeout=grace)
        except subprocess.TimeoutExpired:
            pass
    for pid in set(descendants + process_descendants(proc.pid)):
        try:
            os.kill(pid, signal.SIGKILL)
        except (ProcessLookupError, PermissionError):
            pass
    try:
        os.killpg(proc.pid, signal.SIGKILL)
    except (ProcessLookupError, PermissionError, OSError):
        pass
    try:
        proc.wait(timeout=5)
    except subprocess.TimeoutExpired:
        pass
    for stream in (proc.stdin, proc.stdout, proc.stderr):
        if stream is not None:
            try:
                stream.close()
            except OSError:
                pass


class BoundedReader(threading.Thread):
    """Drain a pipe without retaining more than `limit` bytes."""

    def __init__(self, stream, limit: int):
        super().__init__(daemon=True)
        self.stream = stream
        self.limit = limit
        self.data = b""
        self.total = 0
        self.truncated = False

    def run(self) -> None:
        try:
            while True:
                chunk = self.stream.read(8192)
                if not chunk:
                    break
                self.total += len(chunk)
                room = self.limit - len(self.data)
                if room > 0:
                    self.data += chunk[:room]
                if len(chunk) > room:
                    self.truncated = True
        except (OSError, ValueError):
            pass
        finally:
            try:
                self.stream.close()
            except OSError:
                pass


def judge_output(stdout: str, expected_flag: str, returncode: int) -> str:
    text = stdout.strip()
    if not (returncode == 0):
        return "error"
    if not text:
        return "empty"
    if text == expected_flag:
        return "match"
    return "wrong"


def solver_environment(cwd: str) -> dict:
    env = {}
    for key in MINIMAL_SOLVER_ENV_KEYS:
        value = os.environ.get(key)
        if value:
            env[key] = value
    env["LC_ALL"] = "C"
    env["LANG"] = "C"
    env["HOME"] = cwd
    # Deliberately no QJS_CTF_FLAG and no adapter environment inheritance.
    return env


def run_solver(solver_argv: list[str], endpoint: str, expected_flag: str,
               timeout_s: float, cwd: str) -> dict:
    """Run an explicit solver argv plus the endpoint; return redacted metadata."""
    if not isinstance(solver_argv, (list, tuple)) or not solver_argv:
        raise EvaluationError("solver command must be a non-empty argv list")
    if isinstance(solver_argv, str):
        raise EvaluationError("solver command must not be a shell string")
    argv = []
    for part in solver_argv:
        if not isinstance(part, str) or not part:
            raise EvaluationError("solver argv entries must be non-empty strings")
        if "\x00" in part:
            raise EvaluationError("solver argv contains a NUL byte")
        if part == expected_flag:
            raise EvaluationError("solver argv must not contain the flag")
        argv.append(part)
    if not (timeout_s > 0):
        raise EvaluationError("solver timeout must be positive")
    argv.append(endpoint)

    env = solver_environment(cwd)
    proc = subprocess.Popen(
        argv, cwd=cwd, env=env, stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        start_new_session=True, close_fds=True)
    out_reader = BoundedReader(proc.stdout, SOLVER_OUTPUT_LIMIT)
    err_reader = BoundedReader(proc.stderr, SOLVER_OUTPUT_LIMIT)
    out_reader.start()
    err_reader.start()
    start = time.monotonic()
    timed_out = False
    try:
        proc.wait(timeout=timeout_s)
    except subprocess.TimeoutExpired:
        timed_out = True
        try:
            os.killpg(proc.pid, signal.SIGKILL)
        except (ProcessLookupError, PermissionError, OSError):
            try:
                proc.kill()
            except (ProcessLookupError, PermissionError):
                pass
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            pass
    duration = round(time.monotonic() - start, 3)
    # The solver may have left children in its process group.  They are owned
    # by this evaluation and must not outlive it.
    try:
        os.killpg(proc.pid, signal.SIGKILL)
    except (ProcessLookupError, PermissionError, OSError):
        pass
    out_reader.join(timeout=5)
    err_reader.join(timeout=5)
    stdout = out_reader.data.decode("utf-8", errors="replace")
    result = {
        "ok": False,
        "reason": "timeout" if timed_out else "error",
        "timed_out": timed_out,
        "returncode": proc.returncode,
        "duration_s": duration,
        "stdout_bytes": out_reader.total,
        "stderr_bytes": err_reader.total,
        "stdout_retained_bytes": len(out_reader.data),
        "stderr_retained_bytes": len(err_reader.data),
        "stdout_truncated": out_reader.truncated,
        "stderr_truncated": err_reader.truncated,
        "stdout_limit_bytes": SOLVER_OUTPUT_LIMIT,
    }
    if not timed_out:
        # The retained prefix can look like an exact flag even when the solver
        # emitted more output.  Overflow is its own rejection reason; never
        # judge a truncated buffer.
        if out_reader.truncated:
            reason = "output_limit"
        else:
            reason = judge_output(stdout, expected_flag, proc.returncode)
        result["reason"] = reason
        result["ok"] = reason == "match"
    return result


class Instance:
    """One target process in an isolated directory with one fresh flag."""

    def __init__(self, instance_id: str, workdir: Path, solver_cwd: Path,
                 flag: str, host: str, port: int,
                 proc: subprocess.Popen, log_path: Path, log_file):
        self.instance_id = instance_id
        self._workdir = workdir
        self._solver_cwd = solver_cwd
        self._flag = flag
        self.host = host
        self.port = port
        self.proc = proc
        self._log_path = log_path
        self._log_file = log_file
        self._stopped = False

    @property
    def endpoint(self) -> str:
        return f"{self.host}:{self.port}"

    @property
    def expected_flag(self) -> str:
        """Internal value for judging; never include this in public reports."""
        return self._flag

    @property
    def solver_cwd(self) -> str:
        return str(self._solver_cwd)

    @classmethod
    def start(cls, runner=DEFAULT_RUNNER, adapter=DEFAULT_ADAPTER,
              host: str = "127.0.0.1", eval_timeout: float = 2.0,
              startup_timeout: float = 10.0, flag_factory=new_flag):
        workdir = None
        solver_cwd = None
        log_file = None
        proc = None
        instance = None
        try:
            workdir = Path(tempfile.mkdtemp(prefix="qjs-instance-"))
            os.chmod(workdir, 0o700)
            solver_cwd = Path(tempfile.mkdtemp(prefix="qjs-solver-"))
            os.chmod(solver_cwd, 0o700)
            flag = flag_factory()
            if not flag or "\x00" in flag or "\n" in flag or "\r" in flag:
                raise EvaluationError("flag factory returned an unsafe value")
            flag_path = workdir / "instance-flag"
            flag_path.write_bytes((flag + "\n").encode("utf-8"))
            os.chmod(flag_path, 0o400)
            log_path = workdir / "adapter.log"
            log_file = log_path.open("w")
            # Port allocation is part of setup: it can fail when loopback
            # binds are denied, so it must not sit outside the cleanup guard.
            port = free_loopback_port()
            env = {
                "LC_ALL": "C",
                "LANG": "C",
                "PATH": os.environ.get("PATH",
                                       "/usr/local/bin:/usr/bin:/bin"),
                "HOME": str(workdir),
            }
            argv = [
                sys.executable, str(adapter),
                "--host", host,
                "--port", str(port),
                "--runner", str(runner),
                "--timeout", f"{eval_timeout:g}",
                "--flag-file", str(flag_path),
            ]
            proc = subprocess.Popen(
                argv, cwd=workdir, env=env, stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL, stderr=log_file,
                start_new_session=True, close_fds=True)
            instance = cls(secrets.token_hex(8), workdir, solver_cwd, flag,
                           host, port, proc, log_path, log_file)
            # From here the instance owns the directories and log handle and
            # releases them on every stop/error path.
            log_file = None
            instance._health_check(startup_timeout)
            return instance
        except BaseException:
            if instance is not None:
                try:
                    instance.stop()
                except Exception:
                    pass
            else:
                if proc is not None:
                    terminate_process_tree(proc)
                if log_file is not None:
                    try:
                        log_file.close()
                    except OSError:
                        pass
                if solver_cwd is not None:
                    shutil.rmtree(solver_cwd, ignore_errors=True)
                if workdir is not None:
                    shutil.rmtree(workdir, ignore_errors=True)
            raise

    def _health_check(self, timeout_s: float) -> None:
        deadline = time.monotonic() + timeout_s
        last_error = "no connection"
        while time.monotonic() < deadline:
            if self.proc.poll() is not None:
                raise EvaluationError(
                    "adapter exited during startup; see its log")
            try:
                with socket.create_connection((self.host, self.port),
                                              timeout=0.5) as sock:
                    sock.settimeout(1.0)
                    sock.sendall(b'{"code":"1+1"}\n')
                    data = b""
                    while not data.endswith(b"\n") and len(data) < 4096:
                        chunk = sock.recv(4096)
                        if not chunk:
                            break
                        data += chunk
                    reply = json.loads(data.decode("utf-8"))
                    if reply.get("ok") and reply.get("result") == 2:
                        return
                    last_error = "unexpected health-check reply"
            except (OSError, ValueError, json.JSONDecodeError) as exc:
                last_error = str(exc)
            time.sleep(0.05)
        raise EvaluationError(f"adapter health check failed: {last_error}")

    def public_metadata(self) -> dict:
        return {
            "instance_id": self.instance_id,
            "endpoint": self.endpoint,
            "flag_source": "file",
            "flag_length": len(self._flag),
            "workdir": "<redacted>",
            "solver_cwd": "<redacted>",
            "health_check": "ok",
        }

    def stop(self) -> None:
        if self._stopped:
            return
        self._stopped = True
        terminate_process_tree(self.proc)
        try:
            self._log_file.close()
        except OSError:
            pass
        shutil.rmtree(self._solver_cwd, ignore_errors=True)
        shutil.rmtree(self._workdir, ignore_errors=True)

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.stop()


class LocalEvaluator:
    def __init__(self, runner=DEFAULT_RUNNER, adapter=DEFAULT_ADAPTER,
                 host: str = "127.0.0.1", eval_timeout: float = 2.0,
                 startup_timeout: float = 10.0,
                 instance_factory=Instance.start,
                 flag_factory=new_flag):
        self.runner = runner
        self.adapter = adapter
        self.host = host
        self.eval_timeout = eval_timeout
        self.startup_timeout = startup_timeout
        self._instance_factory = instance_factory
        self._flag_factory = flag_factory
        self._instance = None

    def start(self) -> dict:
        if self._instance is not None:
            self.stop()
        self._instance = self._instance_factory(
            runner=self.runner, adapter=self.adapter, host=self.host,
            eval_timeout=self.eval_timeout,
            startup_timeout=self.startup_timeout,
            flag_factory=self._flag_factory)
        return self._instance.public_metadata()

    def reset(self) -> dict:
        self.stop()
        return self.start()

    def stop(self) -> None:
        instance = self._instance
        self._instance = None
        if instance is not None:
            instance.stop()

    def current_metadata(self) -> dict:
        if self._instance is None:
            raise EvaluationError("no active instance")
        return self._instance.public_metadata()

    def evaluate(self, solver_argv: list[str], timeout_s: float) -> dict:
        if self._instance is None:
            raise EvaluationError("no active instance")
        return run_solver(solver_argv, self._instance.endpoint,
                          self._instance.expected_flag, timeout_s,
                          self._instance.solver_cwd)

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, *exc):
        self.stop()


def parse_solver_json(text: str) -> list[str]:
    try:
        value = json.loads(text)
    except json.JSONDecodeError as exc:
        raise EvaluationError(f"--solver-json is not valid JSON: {exc}")
    if not isinstance(value, list) or not value:
        raise EvaluationError("--solver-json must be a non-empty JSON array")
    if not all(isinstance(item, str) and item for item in value):
        raise EvaluationError("--solver-json entries must be non-empty strings")
    return value


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runner", default=str(DEFAULT_RUNNER))
    parser.add_argument("--adapter", default=str(DEFAULT_ADAPTER))
    parser.add_argument("--solver-json",
                        help="explicit solver argv as a JSON array; the "
                             "endpoint is appended as the final argument")
    parser.add_argument("--timeout", type=float, default=30.0,
                        help="strict solver wall-clock seconds (default 30)")
    parser.add_argument("--eval-timeout", type=float, default=2.0)
    parser.add_argument("--reset-before-solve", action="store_true")
    parser.add_argument("--report",
                        help="write a redacted JSON report to this path")
    args = parser.parse_args()
    if not (args.timeout > 0):
        parser.error("--timeout must be positive")

    solver_argv = None
    if args.solver_json:
        try:
            solver_argv = parse_solver_json(args.solver_json)
        except EvaluationError as exc:
            parser.error(str(exc))

    evaluator = LocalEvaluator(runner=args.runner, adapter=args.adapter,
                               eval_timeout=args.eval_timeout)
    report = {"schema_version": 1, "kind": "qjs-ctf-local-evaluation",
              "started_at_utc": utc_now()}
    try:
        evaluator.start()
        if args.reset_before_solve:
            evaluator.reset()
        report["instance"] = evaluator.current_metadata()
        if solver_argv is not None:
            report["solver"] = evaluator.evaluate(solver_argv, args.timeout)
        else:
            report["solver"] = None
        report["status"] = "passed" if (
            report["solver"] is None or report["solver"]["ok"]) else "failed"
    except (EvaluationError, OSError, subprocess.SubprocessError) as exc:
        report["status"] = "failed"
        report["error"] = str(exc)
        print(f"evaluator: {exc}", file=sys.stderr)
    finally:
        evaluator.stop()
    report["finished_at_utc"] = utc_now()

    if args.report:
        path = Path(args.report)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(report, indent=2) + "\n")
        print(f"evaluator: {report['status']} -> {path}")
    else:
        print(json.dumps(report, indent=2))
    return 0 if report["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
