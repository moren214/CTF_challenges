"""Docker-backed target/solver controller for Phase 3A.

The trusted controller owns one fresh flag per target instance.  The target
and solver run in separate containers on one uniquely named internal bridge
network.  No target port is published.  The solver receives only the target
endpoint as its final argv element and has no flag mount, no flag environment
variable, no controller environment, no Docker socket, and no host PID or
network namespace.

This is a controlled CTF evaluation boundary, not a security proof.  Both
containers share the host kernel.  An internal Docker bridge alone does not
prove endpoint-only egress; the boundary command reports that gate as pending
unless strict filtering is independently implemented and verified.

The pre-existing evaluator/controller.py remains the same-user local
development helper.  This module requires a container engine, prebuilt target
and solver images, and never downloads images implicitly.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform as host_platform
import re
import secrets
import shutil
import signal
import socket
import subprocess
import sys
import tempfile
import threading
import time
from datetime import datetime, timezone
from pathlib import Path

EVALUATOR_DIR = Path(__file__).resolve().parent
if str(EVALUATOR_DIR) not in sys.path:
    sys.path.insert(0, str(EVALUATOR_DIR))
import controller as local_controller  # noqa: E402
import egress_policy  # noqa: E402

ROOT = EVALUATOR_DIR.parent
DEFAULT_REPORT = ROOT / "reports" / "container-evaluation-report.json"
ENGINE_CANDIDATES = ("docker", "podman", "nerdctl")
LABEL_INSTANCE = "qjsctf.instance"
LABEL_ROLE = "qjsctf.role"
FLAG_ENV_NAME = "QJS_CTF_FLAG"
CONTROLLER_ENV_SENTINEL = "QJS_CTF_CONTROLLER_ENV_SENTINEL"
TARGET_FLAG_PATH = "/run/secrets/qjs_ctf_flag"
TARGET_ALIAS = "target"
TARGET_PORT = 8000
TARGET_ENDPOINT = f"{TARGET_ALIAS}:{TARGET_PORT}"
SANDBOX_TMPFS = "/tmp:rw,noexec,nosuid,nodev,size=16m"
SOLVER_OUTPUT_LIMIT = local_controller.SOLVER_OUTPUT_LIMIT
BoundedReader = local_controller.BoundedReader
EGRESS_MODES = ("strict", "legacy")
ROLE_HOLDER = "holder"
ROLE_CONTROL_PROBE = "control-probe"
ROLE_STRICT_PROBE = "strict-probe"
HOLDER_IDLE_SCRIPT = "import time; time.sleep(86400)"
POLICY_TIMEOUT = 30.0
POLICY_DIAGNOSTIC_LIMIT = 2048
_FLAG_LITERAL_RE = re.compile(
    r"(?i)(?:FLAG|TPCTF)\{[^}\r\n]*\}")
_DYNAMIC_FD_RE = re.compile(r"/proc/self/fd/\d+")


class ContainerError(RuntimeError):
    pass


class ShutdownRequested(Exception):
    pass


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def new_flag() -> str:
    return "FLAG{" + secrets.token_hex(16) + "}"


def validate_flag(flag: str) -> None:
    if not isinstance(flag, str) or not flag:
        raise ContainerError("flag factory returned an unsafe value")
    if "\x00" in flag or "\n" in flag or "\r" in flag:
        raise ContainerError("flag factory returned an unsafe value")


def _bounded_policy_diagnostic(text: str | None, secret: str | None,
                               limit: int = POLICY_DIAGNOSTIC_LIMIT) -> dict:
    """Return bounded, redacted command diagnostics safe for public reports."""
    raw = text or ""
    safe = raw.replace("\x00", "\\0")
    if secret:
        safe = safe.replace(secret, "[REDACTED_FLAG]")
    safe = _FLAG_LITERAL_RE.sub("[REDACTED_FLAG]", safe)
    safe = _DYNAMIC_FD_RE.sub("/proc/self/fd/<fd>", safe)
    encoded = safe.encode("utf-8", errors="replace")
    retained = encoded[:limit]
    return {
        "text": retained.decode("utf-8", errors="replace"),
        "bytes": len(encoded),
        "retained_bytes": len(retained),
        "truncated": len(encoded) > len(retained),
    }


def _policy_process_record(proc: subprocess.CompletedProcess, *,
                           secret: str | None,
                           batch: str | None = None) -> dict:
    """Summarize a policy subprocess without exporting stdout or argv."""
    stderr = _bounded_policy_diagnostic(proc.stderr, secret)
    stdout = (proc.stdout or "").encode("utf-8", errors="replace")
    record = {
        "attempted": True,
        "returncode": proc.returncode,
        "stderr": stderr["text"],
        "stderr_bytes": stderr["bytes"],
        "stderr_retained_bytes": stderr["retained_bytes"],
        "stderr_truncated": stderr["truncated"],
        "stdout_bytes": len(stdout),
    }
    if batch is not None:
        record.update(_policy_batch_metadata(batch))
    return record


def _policy_batch_metadata(batch: str) -> dict:
    return {
        "batch_sha256": hashlib.sha256(
            batch.encode("utf-8")).hexdigest(),
        "rule_count": sum(
            1 for line in batch.splitlines()
            if line.startswith("-A ")),
    }


# ---------------------------------------------------------------------------
# Container engine wrapper

def find_engine(explicit: str | None) -> tuple[str | None, str]:
    candidates = []
    if explicit:
        candidates.append(explicit)
    else:
        env_engine = os.environ.get("CONTAINER_ENGINE")
        if env_engine:
            candidates.append(env_engine)
        candidates.extend(ENGINE_CANDIDATES)
    seen = set()
    diagnostics = []
    for candidate in candidates:
        if not candidate or candidate in seen:
            continue
        seen.add(candidate)
        path = shutil.which(candidate)
        if not path:
            diagnostics.append(f"{candidate}: not found on PATH")
            continue
        try:
            probe = subprocess.run([path, "info"], capture_output=True,
                                   text=True, timeout=60)
        except (OSError, subprocess.SubprocessError) as exc:
            diagnostics.append(
                f"{candidate}: info failed ({safe_error_text(exc)})")
            continue
        if probe.returncode == 0:
            return path, "; ".join(diagnostics)
        diagnostics.append(
            f"{candidate}: engine info failed ({probe.stderr.strip()[:200]})")
    return None, "; ".join(diagnostics)


class Engine:
    def __init__(self, path: str, default_timeout: float = 300.0):
        self.path = path
        self.default_timeout = default_timeout
        self.calls: list[dict] = []
        self._call_index: dict[tuple, dict] = {}

    def run(self, argv: list[str], timeout: float | None = None,
            env: dict | None = None) -> subprocess.CompletedProcess:
        argv_list = list(argv)
        key = tuple(argv_list)
        call = self._call_index.get(key)
        if call is None:
            call = {"argv": argv_list, "returncode": None}
            self.calls.append(call)
            self._call_index[key] = call
        try:
            proc = subprocess.run(
                argv, capture_output=True, text=True,
                timeout=timeout if timeout is not None else self.default_timeout,
                env=env)
        except subprocess.TimeoutExpired:
            call["returncode"] = None
            call["error"] = "timeout"
            raise
        call["returncode"] = proc.returncode
        call.pop("error", None)
        return proc

    def require(self, argv: list[str], name: str,
                timeout: float | None = None,
                env: dict | None = None) -> subprocess.CompletedProcess:
        proc = self.run(argv, timeout=timeout, env=env)
        if proc.returncode != 0:
            raise ContainerError(
                f"{name} failed with exit code {proc.returncode}")
        return proc

    def image_exists(self, reference: str) -> bool:
        proc = self.run([self.path, "image", "inspect", reference],
                        timeout=60)
        return proc.returncode == 0

    def version(self) -> str:
        try:
            proc = self.run([self.path, "version"], timeout=60)
        except (OSError, subprocess.SubprocessError):
            return "unknown"
        if proc.returncode == 0:
            lines = (proc.stdout or proc.stderr).strip().splitlines()
            return lines[0] if lines else "unknown"
        return "unknown"


# ---------------------------------------------------------------------------
# Pure command builders (unit-tested)

def sandbox_args(user: str, cpus: float, memory: str,
                 pids_limit: int) -> list[str]:
    return [
        "--user", user,
        "--cap-drop", "ALL",
        "--security-opt", "no-new-privileges:true",
        "--read-only",
        "--tmpfs", SANDBOX_TMPFS,
        "--cpus", f"{cpus:g}",
        "--memory", memory,
        "--pids-limit", str(pids_limit),
    ]


def network_create_argv(engine: str, name: str,
                        instance_id: str) -> list[str]:
    return [
        engine, "network", "create",
        "--internal",
        "--driver", "bridge",
        "--label", f"{LABEL_INSTANCE}={instance_id}",
        "--label", f"{LABEL_ROLE}=network",
        name,
    ]


def network_inspect_argv(engine: str, name: str) -> list[str]:
    return [engine, "network", "inspect", "--format", "{{json .}}", name]


def network_remove_argv(engine: str, name: str) -> list[str]:
    return [engine, "network", "rm", name]


def target_run_argv(engine: str, name: str, image: str, network: str,
                    instance_id: str, flag_host_path: str, *,
                    user: str, cpus: float, memory: str, pids_limit: int,
                    platform: str) -> list[str]:
    argv = [
        engine, "run", "-d",
        "--name", name,
        "--platform", platform,
        "--pull=never",
        "--network", network,
        "--network-alias", TARGET_ALIAS,
        "--label", f"{LABEL_INSTANCE}={instance_id}",
        "--label", f"{LABEL_ROLE}=target",
        *sandbox_args(user, cpus, memory, pids_limit),
        "--mount",
        f"type=bind,source={flag_host_path},target={TARGET_FLAG_PATH},readonly",
        "--env", "LC_ALL=C",
        "--env", "LANG=C",
        "--env", "PYTHONDONTWRITEBYTECODE=1",
        image,
        "python3", "/app/adapter/server.py",
        "--host", "0.0.0.0", "--port", str(TARGET_PORT),
        "--runner", "/app/build/qjs_runner",
        "--flag-file", TARGET_FLAG_PATH,
    ]
    return argv


def holder_container_argv(engine: str, name: str, image: str,
                          network: str, instance_id: str, *,
                          user: str, cpus: float, memory: str,
                          pids_limit: int, platform: str) -> list[str]:
    """Trusted idle network-holder container.

    The holder owns the network namespace that the solver later joins.  It
    carries no flag mount, no solver content, no network service, no extra
    capability and bounded resources.  It only sleeps.
    """
    return [
        engine, "run", "-d",
        "--name", name,
        "--platform", platform,
        "--pull=never",
        "--network", network,
        "--label", f"{LABEL_INSTANCE}={instance_id}",
        "--label", f"{LABEL_ROLE}={ROLE_HOLDER}",
        # A baked HEALTHCHECK is arbitrary image code.  The holder is a
        # pre-policy helper, so it must never run image-supplied commands.
        "--no-healthcheck",
        *sandbox_args(user, cpus, memory, pids_limit),
        "--log-driver", "none",
        "--workdir", "/tmp",
        "--env", "HOME=/tmp",
        "--env", "LC_ALL=C",
        "--env", "LANG=C",
        "--env", "PYTHONDONTWRITEBYTECODE=1",
        "--entrypoint", "python3",
        image, "-c", HOLDER_IDLE_SCRIPT,
    ]


def solver_container_argv(engine: str, name: str, image: str,
                          network: str, instance_id: str,
                          solver_argv: list[str] | None, *,
                          user: str, cpus: float, memory: str,
                          pids_limit: int, platform: str,
                          create: bool = False,
                          endpoint: str = TARGET_ENDPOINT) -> list[str]:
    argv = [
        engine, "create" if create else "run",
        "--name", name,
        "--platform", platform,
        "--pull=never",
        "--network", network,
        # The client-side capture is bounded, but an unbounded engine log
        # driver could still spool unlimited solver output on the daemon.
        "--log-driver", "none",
        "--label", f"{LABEL_INSTANCE}={instance_id}",
        "--label", f"{LABEL_ROLE}=solver",
        *sandbox_args(user, cpus, memory, pids_limit),
        "--workdir", "/tmp",
        "--env", "HOME=/tmp",
        "--env", "LC_ALL=C",
        "--env", "LANG=C",
        "--env", "PYTHONDONTWRITEBYTECODE=1",
        image,
    ]
    if solver_argv:
        argv.extend(solver_argv)
        argv.append(endpoint)
    return argv


def probe_container_argv(engine: str, name: str, image: str, network: str,
                         instance_id: str, *, user: str, cpus: float,
                         memory: str, pids_limit: int,
                         platform: str, role: str = "probe") -> list[str]:
    return [
        engine, "run", "-d",
        "--name", name,
        "--platform", platform,
        "--pull=never",
        "--network", network,
        "--label", f"{LABEL_INSTANCE}={instance_id}",
        "--label", f"{LABEL_ROLE}={role}",
        # Probes are helpers regardless of policy state; a baked
        # HEALTHCHECK would run arbitrary image code outside the probe
        # command.  Never allow that.
        "--no-healthcheck",
        *sandbox_args(user, cpus, memory, pids_limit),
        "--workdir", "/tmp",
        "--env", "HOME=/tmp",
        "--env", "LC_ALL=C",
        "--env", "LANG=C",
        "--env", "PYTHONDONTWRITEBYTECODE=1",
        "--entrypoint", "python3",
        image,
        "-c", "import time; time.sleep(300)",
    ]


def sentinel_container_argv(engine: str, name: str, image: str,
                            network: str, instance_id: str, port: int, *,
                            user: str, platform: str,
                            udp_port: int | None = None) -> list[str]:
    argv = [
        engine, "run", "-d",
        "--name", name,
        "--platform", platform,
        "--pull=never",
        "--network", network,
        "--label", f"{LABEL_INSTANCE}={instance_id}",
        "--label", f"{LABEL_ROLE}=sentinel",
        # The sentinel is a pre-policy helper; image HEALTHCHECKs are
        # arbitrary code and must not execute here.
        "--no-healthcheck",
        "--user", user,
        "--cap-drop", "ALL",
        "--security-opt", "no-new-privileges:true",
        "--read-only",
        "--tmpfs", SANDBOX_TMPFS,
        "--cpus", "1",
        "--memory", "256m",
        "--pids-limit", "64",
        "--entrypoint", "python3",
        image,
        "-c", sentinel_script(), str(port),
    ]
    if udp_port is not None:
        argv.append(str(udp_port))
    return argv


def container_inspect_argv(engine: str, reference: str) -> list[str]:
    return [engine, "inspect", "--format", "{{json .}}", reference]


def exec_argv(engine: str, container: str,
              command: list[str]) -> list[str]:
    return [engine, "exec", container, *command]


def remove_argv(engine: str, reference: str) -> list[str]:
    # -v removes anonymous volumes attached by an image-declared
    # VOLUME; named operator volumes are never removed.
    return [engine, "rm", "-f", "-v", reference]


def image_volumes_argv(engine: str, reference: str) -> list[str]:
    return [engine, "image", "inspect", "--format",
            "{{json .Config.Volumes}}", reference]


def parse_image_volumes(stdout: str) -> list[str]:
    """Return image-declared VOLUME paths; an engine null means none.

    Image VOLUMEs create writable anonymous volumes even with --read-only, so
    the caller refuses to run such images instead of claiming a full read-only
    filesystem boundary.
    """
    text = (stdout or "").strip()
    if text in ("", "null"):
        return []
    try:
        value = json.loads(text)
    except json.JSONDecodeError as exc:
        raise ContainerError(
            f"image volume inspect returned invalid JSON: {exc}") from exc
    if value is None:
        return []
    if not isinstance(value, dict):
        raise ContainerError("image volume inspect returned a non-object")
    return sorted(str(path) for path in value)


def inspect_image_volumes(engine: "Engine", reference: str) -> list[str]:
    proc = engine.run(image_volumes_argv(engine.path, reference), timeout=60)
    if proc.returncode != 0:
        raise ContainerError(
            f"could not inspect image volumes for {reference}: "
            f"{(proc.stderr or '').strip()[:200]}")
    return parse_image_volumes(proc.stdout)


# ---------------------------------------------------------------------------
# Probe scripts

def health_script() -> str:
    return (
        "import json, socket\n"
        "s = socket.create_connection(('127.0.0.1', 8000), 3)\n"
        "s.sendall(b'{\"code\":\"1+1\"}\\n')\n"
        "line = s.makefile('rb').readline()\n"
        "r = json.loads(line)\n"
        "print('HEALTH_OK' if r.get('ok') and r.get('result') == 2 "
        "else 'HEALTH_BAD')\n"
    )


def namespace_script() -> str:
    return (
        "import json, os\n"
        "print(json.dumps({\n"
        "  'pid_ns': os.readlink('/proc/self/ns/pid'),\n"
        "  'mnt_ns': os.readlink('/proc/self/ns/mnt'),\n"
        "  'uid': os.getuid(),\n"
        "  'gid': os.getgid(),\n"
        "}))\n"
    )


def boundary_probe_script() -> str:
    return r'''
import json, os, socket, sys

def connect(host, port, timeout=2.0):
    try:
        sock = socket.create_connection((host, port), timeout)
        sock.close()
        return True
    except OSError:
        return False

def target_health(endpoint):
    try:
        host, port = endpoint.rsplit(":", 1)
        sock = socket.create_connection((host, int(port)), 5)
        sock.sendall(b'{"code":"1+1"}\n')
        line = sock.makefile('rb').readline()
        sock.close()
        import json as _json
        reply = _json.loads(line)
        return bool(reply.get("ok")) and reply.get("result") == 2
    except Exception:
        return False

gateway_ip = sys.argv[1]
gateway_port = int(sys.argv[2])
sentinel_ip = sys.argv[3]
sentinel_port = int(sys.argv[4])
sentinel_env_name = sys.argv[5]
endpoint = sys.argv[6]

env = dict(os.environ)
root_write_blocked = False
try:
    with open("/.qjs-boundary-write", "w") as handle:
        handle.write("probe")
except OSError:
    root_write_blocked = True

try:
    pid_ns = os.readlink("/proc/self/ns/pid")
    mnt_ns = os.readlink("/proc/self/ns/mnt")
except OSError:
    pid_ns = ""
    mnt_ns = ""

docker_socket_paths = ["/var/run/docker.sock", "/run/docker.sock"]
print(json.dumps({
    "uid": os.getuid(),
    "gid": os.getgid(),
    "pid_ns": pid_ns,
    "mnt_ns": mnt_ns,
    "secret_file_exists": os.path.exists(
        "/run/secrets/qjs_ctf_flag"),
    "docker_socket_exists": any(
        os.path.exists(path) for path in docker_socket_paths),
    "flag_env_variable_present": "QJS_CTF_FLAG" in env,
    "controller_env_sentinel_present": sentinel_env_name in env,
    "root_write_blocked": root_write_blocked,
    "target_reachable": connect(
        endpoint.rsplit(":", 1)[0],
        int(endpoint.rsplit(":", 1)[1])),
    "target_health": target_health(endpoint),
    "host_gateway_reachable": connect(gateway_ip, gateway_port),
    "host_docker_internal_reachable": connect(
        "host.docker.internal", gateway_port),
    "second_network_reachable": connect(sentinel_ip, sentinel_port),
    "external_1_1_1_1_53_reachable": connect("1.1.1.1", 53),
    "external_8_8_8_8_53_reachable": connect("8.8.8.8", 53),
}))
'''


def sentinel_script() -> str:
    return r'''
import os, socket, sys, threading

tcp_port = int(sys.argv[1])
udp_port = int(sys.argv[2]) if len(sys.argv) > 2 else None
base = "/tmp/qjs-sentinel"
tcp_count = [0]
udp_count = [0]

def serve_tcp():
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind(("0.0.0.0", tcp_port))
    sock.listen(16)
    open(base + ".tcp-ready", "w").write("1")
    while True:
        connection, _ = sock.accept()
        tcp_count[0] += 1
        try:
            open(base + ".tcp", "w").write(str(tcp_count[0]))
        except OSError:
            pass
        connection.close()

def serve_udp():
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.bind(("0.0.0.0", udp_port))
    open(base + ".udp-ready", "w").write("1")
    while True:
        sock.recvfrom(2048)
        udp_count[0] += 1
        try:
            open(base + ".udp", "w").write(str(udp_count[0]))
        except OSError:
            pass

if udp_port is not None:
    threading.Thread(target=serve_udp, daemon=True).start()
serve_tcp()
'''


def target_other_listener_script() -> str:
    return r'''
import socket, sys
port = int(sys.argv[1])
ready = sys.argv[2]
countfile = sys.argv[3]
open(countfile, "w").write("0")
sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
sock.bind(("0.0.0.0", port))
sock.listen(16)
open(ready, "w").write("1")
count = 0
while True:
    connection, _ = sock.accept()
    count += 1
    try:
        open(countfile, "w").write(str(count))
    except OSError:
        pass
    connection.close()
'''


def egress_probe_script() -> str:
    return r'''
import ctypes, json, os, socket, subprocess, sys, threading, time

config = json.loads(sys.argv[1])
mode = config["mode"]

def tcp_probe(host, port, timeout=1.5):
    try:
        sock = socket.create_connection((host, int(port)), timeout)
        sock.close()
        return {"connected": True, "error": None, "errno": None}
    except OSError as exc:
        return {"connected": False, "error": type(exc).__name__,
                "errno": getattr(exc, "errno", None)}

def tcp_connect(host, port, timeout=1.5):
    return bool(tcp_probe(host, port, timeout)["connected"])

def tcp_call(code, timeout=5.0):
    try:
        sock = socket.create_connection(
            (config["target_ip"], int(config["target_port"])), timeout)
        reader = sock.makefile("rb")
        sock.sendall((json.dumps({"code": code}) + "\n").encode("utf-8"))
        line = reader.readline()
        sock.close()
        if not line:
            return {"ok": False, "reason": "closed"}
        return json.loads(line)
    except Exception as exc:
        return {"ok": False, "reason": type(exc).__name__}

def udp_send(host, port, payload, count=3):
    """Send UDP probes and report the kernel outcome.

    A UDP socket in the holder namespace has no connection state, so the
    packet path only surfaces through the send result and the owned
    listener receive counters.  A DROP rule installed in the OUTPUT chain
    makes the kernel reject a locally generated UDP datagram with EPERM on
    this platform; both "sent with zero receives" and "EPERM" are rejection
    observations, while the pre-policy controls prove the probe path was
    live before enforcement.
    """
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        for _ in range(count):
            sock.sendto(payload, (host, int(port)))
        sock.close()
        return {"sent": True, "error": None, "errno": None}
    except OSError as exc:
        return {"sent": False, "error": type(exc).__name__,
                "errno": getattr(exc, "errno", None)}

def dns_query(name):
    tid = b"\x12\x34"
    flags = b"\x01\x00"
    counts = b"\x00\x01\x00\x00\x00\x00\x00\x00"
    qname = b"".join(
        bytes([len(part)]) + part.encode("ascii")
        for part in name.split(".")) + b"\x00"
    return tid + flags + counts + qname + b"\x00\x01\x00\x01"

def udp_dns(server, name):
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.settimeout(1.5)
        sock.sendto(dns_query(name), (server, 53))
        data, _ = sock.recvfrom(1024)
        sock.close()
        return {"ok": len(data) >= 12 and bool(data[2] & 0x80),
                "error": None, "errno": None}
    except OSError as exc:
        return {"ok": False, "error": type(exc).__name__,
                "errno": getattr(exc, "errno", None)}

def tcp_dns(server, name):
    try:
        sock = socket.create_connection((server, 53), 1.5)
        query = dns_query(name)
        sock.sendall(len(query).to_bytes(2, "big") + query)
        header = sock.recv(2)
        if len(header) < 2:
            sock.close()
            return {"ok": False, "error": "short_header", "errno": None}
        length = int.from_bytes(header, "big")
        data = b""
        while len(data) < length:
            chunk = sock.recv(length - len(data))
            if not chunk:
                break
            data += chunk
        sock.close()
        return {"ok": len(data) >= 12 and bool(data[2] & 0x80),
                "error": None, "errno": None}
    except OSError as exc:
        return {"ok": False, "error": type(exc).__name__,
                "errno": getattr(exc, "errno", None)}

class LoopbackListener:
    def __init__(self, family, address, port):
        self.accepts = 0
        self.error = None
        self.sock = socket.socket(family, socket.SOCK_STREAM)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            if family == socket.AF_INET6:
                self.sock.setsockopt(socket.IPPROTO_IPV6,
                                     socket.IPV6_V6ONLY, 1)
            self.sock.bind((address, int(port)))
            self.sock.listen(8)
            self.sock.settimeout(0.2)
        except OSError as exc:
            self.error = type(exc).__name__
            try:
                self.sock.close()
            except OSError:
                pass
            self.sock = None
        self.stop = threading.Event()
        self.thread = threading.Thread(target=self._serve, daemon=True)

    def _serve(self):
        while not self.stop.is_set():
            try:
                connection, _ = self.sock.accept()
            except socket.timeout:
                continue
            except OSError:
                return
            self.accepts += 1
            connection.close()

    def start(self):
        if self.sock is not None:
            self.thread.start()
        return self

    def close(self):
        self.stop.set()
        if self.sock is not None:
            try:
                self.sock.close()
            except OSError:
                pass
        if self.thread.is_alive():
            self.thread.join(timeout=1)

class UdpListener:
    def __init__(self, family, address, port):
        self.received = 0
        self.error = None
        self.sock = socket.socket(family, socket.SOCK_DGRAM)
        try:
            if family == socket.AF_INET6:
                self.sock.setsockopt(socket.IPPROTO_IPV6,
                                     socket.IPV6_V6ONLY, 1)
            self.sock.bind((address, int(port)))
            self.sock.settimeout(0.05)
        except OSError as exc:
            self.error = type(exc).__name__
            try:
                self.sock.close()
            except OSError:
                pass
            self.sock = None
        self.stop = threading.Event()
        self.thread = threading.Thread(target=self._serve, daemon=True)

    def _serve(self):
        while not self.stop.is_set():
            try:
                self.sock.recvfrom(2048)
            except socket.timeout:
                continue
            except OSError:
                return
            self.received += 1

    def start(self):
        if self.sock is not None:
            self.thread.start()
        return self

    def close(self):
        self.stop.set()
        if self.sock is not None:
            try:
                self.sock.close()
            except OSError:
                pass
        if self.thread.is_alive():
            self.thread.join(timeout=1)

def loopback_check(family, address, port):
    listener = LoopbackListener(family, address, port).start()
    available = listener.sock is not None
    probe = {"connected": False, "error": None, "errno": None}
    if available:
        for _ in range(5):
            probe = tcp_probe(address, port, 0.5)
            if probe["connected"]:
                deadline = time.monotonic() + 0.5
                while (time.monotonic() < deadline
                       and listener.accepts == 0):
                    time.sleep(0.01)
                break
            time.sleep(0.05)
    listener.close()
    return {
        "listener_available": available,
        "connect_allowed": bool(probe["connected"]),
        "connect_error": probe["error"],
        "accepts": listener.accepts,
        "listener_error": listener.error,
    }

def udp_loopback_check(family, address, port, payload=b"qjs-udp"):
    listener = UdpListener(family, address, port).start()
    available = listener.sock is not None
    sent = False
    send_error = None
    if available:
        sender = socket.socket(family, socket.SOCK_DGRAM)
        try:
            sender.sendto(payload, (address, int(port)))
            sent = True
        except OSError as exc:
            send_error = type(exc).__name__
        deadline = time.monotonic() + 0.5
        while time.monotonic() < deadline and listener.received == 0:
            time.sleep(0.02)
        sender.close()
    listener.close()
    return {
        "listener_available": available,
        "sent": sent,
        "received": listener.received,
        "send_error": send_error,
        "listener_error": listener.error,
    }

def capability_check():
    uid = os.getuid()
    caps = 0
    with open("/proc/self/status", encoding="ascii",
              errors="replace") as handle:
        for line in handle:
            if line.startswith("CapEff:"):
                caps = int(line.split()[1], 16)
                break
    libc = ctypes.CDLL(None, use_errno=True)
    clone_newnet = 0x40000000
    ctypes.set_errno(0)
    unshare_rc = libc.unshare(clone_newnet)
    unshare_errno = ctypes.get_errno()
    setns_denied = None
    setns_errno = None
    try:
        fd = os.open("/proc/1/ns/net", os.O_RDONLY)
        ctypes.set_errno(0)
        setns_rc = libc.setns(fd, clone_newnet)
        setns_errno = ctypes.get_errno()
        os.close(fd)
        setns_denied = (setns_rc == -1)
    except OSError:
        setns_denied = None
    mutation = {"attempted": False, "denied": None, "binary": None,
                "returncode": None, "error": None}
    for binary in ("iptables-legacy", "iptables"):
        try:
            proc = subprocess.run(
                [binary, "-A", "OUTPUT", "-j", "ACCEPT"],
                capture_output=True, text=True, timeout=5)
        except FileNotFoundError:
            continue
        except OSError as exc:
            mutation["error"] = type(exc).__name__
            continue
        mutation.update(
            attempted=True, binary=binary, returncode=proc.returncode,
            denied=not (proc.returncode == 0))
        break
    return {
        "uid": uid,
        "cap_effective": caps,
        "no_cap_net_admin": not bool(caps & (1 << 12)),
        "no_cap_sys_admin": not bool(caps & (1 << 21)),
        "unshare_netns_denied": unshare_rc == -1,
        "unshare_errno": unshare_errno,
        "setns_netns_denied": setns_denied,
        "setns_errno": setns_errno,
        "firewall_mutation": mutation,
    }

target_ip = config["target_ip"]
target_port = int(config["target_port"])
other_port = int(config["target_other_port"])
gateway_ip = config["gateway_ip"]
host_tcp_port = int(config["host_tcp_port"])
host_udp_port = int(config["host_udp_port"])
sentinel_ip = config["sentinel_ip"]
sentinel_tcp_port = int(config["sentinel_tcp_port"])
sentinel_udp_port = int(config["sentinel_udp_port"])
dns_name = config["dns_name"]
default_probe_ip = config["default_probe_ip"]
default_probe_port = int(config["default_probe_port"])
test_address = config["ipv6_test_address"]

large_length = 20000
large_source = ("var large = '" + ("a" * large_length)
                + "'; large.length")
health = tcp_call("1+1")
repeated = [tcp_call("1+1") for _ in range(3)]
large = tcp_call(large_source, timeout=10.0)
js_capabilities = {
    "json": tcp_call('JSON.stringify({a:[1,2,3]})'),
    "typed_array": tcp_call("new Uint8Array([1,2,3]).join(',')"),
    "string": tcp_call("'abc'.toUpperCase()"),
    "callback": tcp_call(
        "[1,2,3].map(function(x){return x*2;}).join(',')"),
}

loop4_tcp = loopback_check(
    socket.AF_INET, "127.0.0.1", int(config["loopback_tcp_port"]))
loop4_udp = udp_loopback_check(
    socket.AF_INET, "127.0.0.1", int(config["loopback_udp_port"]))
loop6_tcp = loopback_check(
    socket.AF_INET6, "::1", int(config["ipv6_loopback_tcp_port"]))
loop6_udp = udp_loopback_check(
    socket.AF_INET6, "::1", int(config["ipv6_loopback_udp_port"]))
test6_tcp = loopback_check(
    socket.AF_INET6, test_address, int(config["ipv6_test_tcp_port"]))
test6_udp = udp_loopback_check(
    socket.AF_INET6, test_address, int(config["ipv6_test_udp_port"]))

result = {
    "mode": mode,
    "uid": os.getuid(),
    "gid": os.getgid(),
    "target_health": bool(health.get("ok")) and health.get("result") == 2,
    "target_repeated": bool(
        len(repeated) == 3 and
        all(item.get("ok") and item.get("result") == 2
            for item in repeated)),
    "target_large_request": bool(
        large.get("ok") and large.get("result") == large_length),
    "target_large_request_source_bytes": len(
        large_source.encode("utf-8")),
    "js_capabilities": {
        name: bool(value.get("ok") and value.get("result") == expected)
        for name, value, expected in (
            ("json", js_capabilities["json"], '{"a":[1,2,3]}'),
            ("typed_array", js_capabilities["typed_array"], "1,2,3"),
            ("string", js_capabilities["string"], "ABC"),
            ("callback", js_capabilities["callback"], "2,4,6"),
        )
    },
    "target_other_port": tcp_probe(target_ip, other_port),
    "host_tcp": tcp_probe(gateway_ip, host_tcp_port),
    "host_udp_send": udp_send(
        gateway_ip, host_udp_port, b"qjs-egress-probe"),
    "second_network_tcp": tcp_probe(sentinel_ip, sentinel_tcp_port),
    "second_network_udp_send": udp_send(
        sentinel_ip, sentinel_udp_port, b"qjs-egress-probe"),
    "default_probe_tcp": tcp_probe(
        default_probe_ip, default_probe_port),
    "default_probe_send": udp_send(
        default_probe_ip, default_probe_port, b"qjs-default-probe"),
    "docker_dns_udp": udp_dns("127.0.0.11", dns_name),
    "docker_dns_tcp": tcp_dns("127.0.0.11", dns_name),
    "loopback_ipv4": {"tcp": loop4_tcp, "udp": loop4_udp},
    "loopback_ipv6": {"tcp": loop6_tcp, "udp": loop6_udp},
    "ipv6_test_address": {
        "address": test_address,
        "tcp": test6_tcp,
        "udp": test6_udp,
    },
    "mapped_forbidden_ipv4": tcp_probe(
        "::ffff:" + gateway_ip, host_tcp_port),
    "secret_file_exists": os.path.exists(
        "/run/secrets/qjs_ctf_flag"),
    "docker_socket_exists": any(
        os.path.exists(path)
        for path in ("/var/run/docker.sock", "/run/docker.sock")),
    "flag_env_variable_present": "QJS_CTF_FLAG" in os.environ,
    "controller_env_sentinel_present": config.get(
        "controller_env_sentinel", "<unset>") in os.environ,
    "root_write_blocked": False,
    "capabilities": capability_check(),
    "namespaces": {
        "pid_ns": os.readlink("/proc/self/ns/pid"),
        "mnt_ns": os.readlink("/proc/self/ns/mnt"),
        "net_ns": os.readlink("/proc/self/ns/net"),
    },
}
try:
    with open("/.qjs-boundary-write", "w") as handle:
        handle.write("probe")
except OSError:
    result["root_write_blocked"] = True
print(json.dumps(result))
'''


# ---------------------------------------------------------------------------
# Judging and bounded solver execution

def validate_solver_argv(solver_argv, expected_flag: str | None = None) -> list[str]:
    if not isinstance(solver_argv, (list, tuple)) or not solver_argv:
        raise ContainerError("solver command must be a non-empty argv list")
    if isinstance(solver_argv, str):
        raise ContainerError("solver command must not be a shell string")
    argv = []
    for part in solver_argv:
        if not isinstance(part, str) or not part:
            raise ContainerError("solver argv entries must be non-empty strings")
        if "\x00" in part:
            raise ContainerError("solver argv contains a NUL byte")
        if expected_flag and expected_flag in part:
            raise ContainerError("solver argv must not contain the flag")
        argv.append(part)
    return argv


def parse_solver_json(text: str) -> list[str]:
    try:
        value = json.loads(text)
    except json.JSONDecodeError as exc:
        raise ContainerError(f"--solver-json is not valid JSON: {exc}")
    return validate_solver_argv(value)


def judge_execution(result: dict, expected_flag: str) -> dict:
    if result["timed_out"]:
        reason = "timeout"
    elif result["stdout_truncated"]:
        reason = "output_limit"
    else:
        reason = local_controller.judge_output(
            result["stdout"], expected_flag, result["returncode"])
    return {
        "ok": reason == "match",
        "reason": reason,
        "timed_out": result["timed_out"],
        "returncode": result["returncode"],
        "duration_s": result["duration_s"],
        "stdout_bytes": result["stdout_bytes"],
        "stdout_retained_bytes": result["stdout_retained_bytes"],
        "stdout_truncated": result["stdout_truncated"],
        "stderr_bytes": result["stderr_bytes"],
        "stderr_truncated": result["stderr_truncated"],
        "stdout_limit_bytes": SOLVER_OUTPUT_LIMIT,
    }


def execute_solver(argv: list[str], timeout_s: float,
                   on_timeout=None) -> dict:
    """Run the solver container CLI with bounded capture and strict time."""
    if not (timeout_s > 0):
        raise ContainerError("solver timeout must be positive")
    proc = subprocess.Popen(
        argv, stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        start_new_session=True, close_fds=True)
    out_reader = BoundedReader(proc.stdout, SOLVER_OUTPUT_LIMIT)
    err_reader = BoundedReader(proc.stderr, SOLVER_OUTPUT_LIMIT)
    out_reader.start()
    err_reader.start()
    start = time.monotonic()
    timed_out = False
    timeout_cleanup_error = False
    try:
        try:
            proc.wait(timeout=timeout_s)
        except subprocess.TimeoutExpired:
            timed_out = True
            if on_timeout is not None:
                try:
                    on_timeout()
                except Exception:
                    timeout_cleanup_error = True
            try:
                os.killpg(proc.pid, signal.SIGKILL)
            except (ProcessLookupError, PermissionError, OSError):
                try:
                    proc.kill()
                except (ProcessLookupError, PermissionError):
                    pass
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                pass
    finally:
        duration = round(time.monotonic() - start, 3)
        if proc.poll() is None:
            try:
                os.killpg(proc.pid, signal.SIGKILL)
            except (ProcessLookupError, PermissionError, OSError):
                try:
                    proc.kill()
                except (ProcessLookupError, PermissionError):
                    pass
        out_reader.join(timeout=5)
        err_reader.join(timeout=5)
    return {
        "stdout": out_reader.data.decode("utf-8", errors="replace"),
        "stdout_bytes": out_reader.total,
        "stdout_retained_bytes": len(out_reader.data),
        "stdout_truncated": out_reader.truncated,
        "stderr_bytes": err_reader.total,
        "stderr_truncated": err_reader.truncated,
        "returncode": proc.returncode,
        "timed_out": timed_out,
        "timeout_cleanup_error": timeout_cleanup_error,
        "duration_s": duration,
    }


# ---------------------------------------------------------------------------
# Host-side sentinel

class HostSentinel:
    """Test-owned TCP listener used to probe host/gateway reachability."""

    def __init__(self):
        self._sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            self._sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self._sock.bind(("0.0.0.0", 0))
            self._sock.listen(8)
            self._sock.settimeout(0.2)
        except OSError:
            self._sock.close()
            raise
        self.port = self._sock.getsockname()[1]
        self.accepted = 0
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._serve, daemon=True)

    def _serve(self) -> None:
        while not self._stop.is_set():
            try:
                connection, _ = self._sock.accept()
            except socket.timeout:
                continue
            except OSError:
                return
            self.accepted += 1
            connection.close()

    def start(self) -> "HostSentinel":
        self._thread.start()
        return self

    def stop(self) -> None:
        self._stop.set()
        try:
            self._sock.close()
        except OSError:
            pass
        self._thread.join(timeout=2)


class HostUdpSentinel:
    """Test-owned UDP listener used to prove gateway UDP reachability."""

    def __init__(self):
        self._sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            self._sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self._sock.bind(("0.0.0.0", 0))
            self._sock.settimeout(0.2)
        except OSError:
            self._sock.close()
            raise
        self.port = self._sock.getsockname()[1]
        self.received = 0
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._serve, daemon=True)

    def _serve(self) -> None:
        while not self._stop.is_set():
            try:
                self._sock.recvfrom(2048)
            except socket.timeout:
                continue
            except OSError:
                return
            self.received += 1

    def start(self) -> "HostUdpSentinel":
        self._thread.start()
        return self

    def stop(self) -> None:
        self._stop.set()
        try:
            self._sock.close()
        except OSError:
            pass
        self._thread.join(timeout=2)


# ---------------------------------------------------------------------------
# One target instance

class ContainerInstance:
    def __init__(self, engine: Engine, instance_id: str, token: str,
                 target_image: str, solver_image: str, probe_image: str,
                 network_name: str, target_name: str, target_id: str,
                 flag: str, secret_dir: Path, *, platform: str,
                 target_user: str, solver_user: str,
                 target_limits: dict, solver_limits: dict,
                 startup_timeout: float, name_prefix: str,
                 egress_mode: str = "legacy",
                 holder_image: str | None = None,
                 holder_limits: dict | None = None,
                 policy_timeout: float = POLICY_TIMEOUT):
        if egress_mode not in EGRESS_MODES:
            raise ContainerError("invalid egress mode")
        if egress_mode == "strict" and not holder_image:
            raise ContainerError(
                "strict egress requires an explicit trusted holder image")
        self.engine = engine
        self.instance_id = instance_id
        self.token = token
        self.target_image = target_image
        self.solver_image = solver_image
        self.probe_image = probe_image
        self.network_name = network_name
        self.target_name = target_name
        self.target_id = target_id
        self._flag = flag
        self.secret_dir = secret_dir
        self.platform = platform
        self.target_user = target_user
        self.solver_user = solver_user
        self.target_limits = target_limits
        self.solver_limits = solver_limits
        self.startup_timeout = startup_timeout
        self.name_prefix = name_prefix
        self.egress_mode = egress_mode
        self.holder_image = holder_image
        self.holder_limits = holder_limits or {
            "cpus": 0.5, "memory": "128m", "pids_limit": 32}
        self._stopped = False
        self._cleanup_result = None
        self._active_solver_name = None
        self._remaining_solver_names: list[str] = []
        self._target_removed = False
        self._network_removed = False
        # Boundary helper ownership is recorded before each create/start so
        # cleanup can be retried even if the engine response was lost.
        self._solver_config_name: str | None = None
        self._probe_name: str | None = None
        self._sentinel_name: str | None = None
        self._sentinel_network_name: str | None = None
        # Strict-egress ownership is recorded before each mutating operation.
        self._holder_name: str | None = None
        self._holder_id: str | None = None
        self._holder_pid: int | None = None
        self._holder_ip: str | None = None
        self._target_ip: str | None = None
        self._policy_marker: str | None = None
        self._policy_handle = None
        self._policy_installed = False
        self._policy_removed = False
        self._policy_readback: dict | None = None
        self._policy_readback_results: dict = {}
        self._policy_runtime = egress_policy.PolicyRuntime(
            timeout=policy_timeout)
        self._policy_gateway_ip: str | None = None
        self._policy_extra_deny_ip: str | None = None
        self._policy_ipv6_test_address = egress_policy.IPV6_TEST_ADDRESS
        self._policy_install_attempted = False
        self._policy_install_results: dict = {}
        self._egress_error: str | None = None
        self._holder_removed = False
        self._holder_extra_networks: set[str] = set()
        self._image_ids: dict[str, str] = {}
        self._control_probe_name: str | None = None
        self._strict_probe_name: str | None = None
        self._target_other_port: int | None = None
        self._target_other_ready: str | None = None
        self._target_other_count: str | None = None
        self._host_firewall_before: str | None = None
        self._host_firewall_after: str | None = None
        self._host_firewall_unchanged: bool | None = None
        self._host_marker_present_before: bool | None = None
        self._host_marker_present_after: bool | None = None
        self._ipv6_test_address_configured: bool | None = None
        self._ipv6_test_address_error: str | None = None

    @property
    def expected_flag(self) -> str:
        """Internal judging value; never place this in a public report."""
        return self._flag

    @classmethod
    def start(cls, engine: Engine, target_image: str, solver_image: str,
              *, probe_image: str | None = None,
              platform: str = "linux/amd64",
              target_user: str = "10001:10001",
              solver_user: str = "10001:10001",
              target_cpus: float = 2.0, target_memory: str = "2g",
              target_pids: int = 64, solver_cpus: float = 1.0,
              solver_memory: str = "1g", solver_pids: int = 128,
              startup_timeout: float = 20.0,
              name_prefix: str = "qjs-ctf",
              egress_mode: str = "strict",
              holder_image: str | None = None,
              holder_cpus: float = 0.5,
              holder_memory: str = "128m",
              holder_pids: int = 32,
              defer_egress: bool = False,
              flag_factory=new_flag,
              on_provisional=None) -> "ContainerInstance":
        if egress_mode not in EGRESS_MODES:
            raise ContainerError("invalid egress mode")
        if egress_mode == "strict" and not holder_image:
            raise ContainerError(
                "strict egress requires an explicit trusted holder image")
        for label, image in (("target", target_image),
                             ("solver", solver_image)):
            if not engine.image_exists(image):
                raise ContainerError(
                    f"{label} image is not available locally: {image}; "
                    "Phase 3A does not download images implicitly")
        probe_image = probe_image or target_image
        if not engine.image_exists(probe_image):
            raise ContainerError(
                f"probe image is not available locally: {probe_image}")
        if egress_mode == "strict" and not engine.image_exists(holder_image):
            raise ContainerError(
                f"holder image is not available locally: {holder_image}; "
                "strict egress never falls back to another image")
        if not _is_nonroot(target_user):
            raise ContainerError("target user must be non-root")
        if not _is_nonroot(solver_user):
            raise ContainerError("solver user must be non-root")

        # An image-declared VOLUME is mounted writable even with --read-only.
        # Reject it before any secret is created or container is started
        # instead of producing a false read-only-filesystem claim.
        checked_images: dict[str, list[str]] = {}
        image_checks = [("target", target_image), ("solver", solver_image),
                        ("probe", probe_image)]
        if egress_mode == "strict":
            image_checks.append(("holder", holder_image))
        for label, image in image_checks:
            if image in checked_images:
                continue
            volumes = inspect_image_volumes(engine, image)
            checked_images[image] = volumes
            if volumes:
                raise ContainerError(
                    f"{label} image declares writable VOLUME paths "
                    f"{volumes}; --read-only does not cover them")

        instance_id = secrets.token_hex(8)
        token = secrets.token_hex(6)
        network_name = f"{name_prefix}-net-{token}"
        target_name = f"{name_prefix}-target-{token}"
        secret_dir = Path(tempfile.mkdtemp(prefix="qjs-ctf-secret-"))
        try:
            os.chmod(secret_dir, 0o700)
            flag = flag_factory()
            validate_flag(flag)
            flag_path = secret_dir / "instance-flag"
            flag_path.write_bytes((flag + "\n").encode("utf-8"))
            os.chmod(flag_path, 0o444)
            # Construct the instance before any create/start so its owned
            # names remain recoverable even if the engine response is lost.
            instance = cls(
                engine, instance_id, token, target_image, solver_image,
                probe_image, network_name, target_name, target_name, flag,
                secret_dir, platform=platform, target_user=target_user,
                solver_user=solver_user,
                target_limits={"cpus": target_cpus, "memory": target_memory,
                               "pids_limit": target_pids},
                solver_limits={"cpus": solver_cpus, "memory": solver_memory,
                               "pids_limit": solver_pids},
                startup_timeout=startup_timeout, name_prefix=name_prefix,
                egress_mode=egress_mode, holder_image=holder_image,
                holder_limits={"cpus": holder_cpus,
                               "memory": holder_memory,
                               "pids_limit": holder_pids})
        except BaseException:
            shutil.rmtree(secret_dir, ignore_errors=True)
            raise
        try:
            # Hand the caller the provisional instance as soon as it exists.
            # If startup fails, its owned names and labels remain reachable
            # for a cleanup retry outside this failed stack frame.
            if on_provisional is not None:
                on_provisional(instance)
            engine.require(
                network_create_argv(engine.path, network_name, instance_id),
                "create internal network", timeout=120)
            proc = engine.require(
                target_run_argv(
                    engine.path, target_name, target_image, network_name,
                    instance_id, str(flag_path), user=target_user,
                    cpus=target_cpus, memory=target_memory,
                    pids_limit=target_pids, platform=platform),
                "start target container", timeout=300)
            instance.target_id = (proc.stdout or "").strip() or target_name
            instance._wait_health()
            if egress_mode == "strict":
                instance._start_strict_holder()
                if not defer_egress:
                    instance._activate_egress_policy()
            return instance
        except BaseException as exc:
            # Best effort per resource; a successful create with a lost
            # response is still owned by its unique name.  Do not discard
            # the cleanup outcome: retain it on the instance and attach the
            # provisional owner to the original exception so an outer
            # stop() can expose and retry any remaining resources.
            try:
                cleanup = instance.stop()
            except BaseException as cleanup_exc:  # noqa: BLE001
                cleanup = {
                    "ok": False,
                    "errors": [{
                        "role": "startup",
                        "reference": "<provisional-instance>",
                        "error": safe_error_text(cleanup_exc)[:300],
                    }],
                }
                instance._cleanup_result = cleanup
                # Secret removal must not depend on engine cleanup success.
                if instance.secret_dir is not None:
                    shutil.rmtree(instance.secret_dir, ignore_errors=True)
                    if not instance.secret_dir.exists():
                        instance.secret_dir = None
            try:
                exc.provisional_instance = instance
                exc.cleanup_result = cleanup
            except (AttributeError, TypeError):
                pass
            raise

    # -- health and metadata -------------------------------------------------

    def _wait_health(self) -> None:
        deadline = time.monotonic() + self.startup_timeout
        last = "no probe"
        while time.monotonic() < deadline:
            proc = self.engine.run(
                exec_argv(self.engine.path, self.target_name,
                          ["python3", "-c", health_script()]), timeout=15)
            if proc.returncode == 0 and "HEALTH_OK" in (proc.stdout or ""):
                return
            state = self.engine.run(
                container_inspect_argv(self.engine.path, self.target_name),
                timeout=15)
            if state.returncode == 0:
                try:
                    data = json.loads(state.stdout)
                except json.JSONDecodeError:
                    data = {}
                if not (data.get("State") or {}).get("Running", False):
                    exit_code = (data.get("State") or {}).get("ExitCode")
                    last = f"target exited with code {exit_code}"
                    break
            if proc.returncode == 0 and "HEALTH_BAD" in (proc.stdout or ""):
                last = "health probe returned an unexpected reply"
            else:
                last = "health probe did not succeed"
            time.sleep(0.1)
        raise ContainerError(f"target health check failed: {last}")

    # -- strict egress holder and policy -----------------------------------

    def _solver_network_mode(self) -> str:
        if self.egress_mode == "strict":
            if not self._holder_id:
                raise ContainerError("strict egress has no holder container")
            return f"container:{self._holder_id}"
        return self.network_name

    def _solver_endpoint(self) -> str:
        if self.egress_mode == "strict":
            if not self._target_ip:
                raise ContainerError("strict egress has no numeric target IP")
            return f"{self._target_ip}:{TARGET_PORT}"
        return TARGET_ENDPOINT

    def _inspect_holder(self) -> dict:
        if not self._holder_name:
            raise ContainerError("strict egress has no holder name")
        proc = self.engine.require(
            container_inspect_argv(self.engine.path, self._holder_name),
            "inspect network holder", timeout=60)
        data = json.loads(proc.stdout)
        container_id = data.get("Id")
        config = data.get("Config") or {}
        host = data.get("HostConfig") or {}
        labels = config.get("Labels") or {}
        state = data.get("State") or {}
        if not (labels.get(LABEL_INSTANCE) == self.instance_id):
            raise ContainerError("holder ownership label mismatch")
        if not (labels.get(LABEL_ROLE) == ROLE_HOLDER):
            raise ContainerError("holder role label mismatch")
        if not container_id:
            raise ContainerError("holder has no container ID")
        if not state.get("Running"):
            raise ContainerError("holder is not running")
        pid = state.get("Pid")
        if not isinstance(pid, int) or pid <= 0:
            raise ContainerError("holder has no usable running PID")
        networks = (data.get("NetworkSettings") or {}).get("Networks") or {}
        entry = networks.get(self.network_name) or {}
        extra_networks = set(networks) - {self.network_name}
        if not (extra_networks <= self._holder_extra_networks):
            raise ContainerError(
                "holder is attached to an unexpected network")
        try:
            ip = egress_policy.validate_ipv4(entry.get("IPAddress"))
        except egress_policy.EgressPolicyError as exc:
            raise ContainerError(
                "holder has no numeric IPv4 address on the instance network"
            ) from exc
        if not (host.get("NetworkMode") == self.network_name):
            raise ContainerError(
                "holder primary network is not the instance network")
        image_id = data.get("Image")
        expected_image = self._image_ids.get("holder")
        if expected_image and not (image_id == expected_image):
            raise ContainerError("holder image identity mismatch")
        if host.get("Privileged"):
            raise ContainerError("holder must not be privileged")
        if (host.get("PortBindings") or {}):
            raise ContainerError("holder must not publish ports")
        if not host.get("ReadonlyRootfs"):
            raise ContainerError("holder root filesystem must be read-only")
        if "ALL" not in (host.get("CapDrop") or []):
            raise ContainerError("holder must drop all capabilities")
        allowed_mounts = {"/tmp",
                          "/etc/hosts", "/etc/hostname", "/etc/resolv.conf"}
        disallowed = [
            mount for mount in (data.get("Mounts") or [])
            if mount.get("Destination") not in allowed_mounts
            or mount.get("Destination") == TARGET_FLAG_PATH
        ]
        if disallowed:
            raise ContainerError(
                "holder must not mount flag or solver content")
        if any(entry.startswith(FLAG_ENV_NAME + "=")
               for entry in (config.get("Env") or [])):
            raise ContainerError("holder must not carry a flag environment")
        return {
            "id": container_id,
            "pid": pid,
            "ip": ip,
            "running": True,
            "network_mode": host.get("NetworkMode"),
            "image_id": image_id,
            "extra_networks": sorted(extra_networks),
        }

    def _target_ip_on_network(self) -> str:
        proc = self.engine.require(
            container_inspect_argv(self.engine.path, self.target_name),
            "inspect target endpoint", timeout=60)
        data = json.loads(proc.stdout)
        networks = (data.get("NetworkSettings") or {}).get("Networks") or {}
        entry = networks.get(self.network_name) or {}
        try:
            ip = egress_policy.validate_ipv4(entry.get("IPAddress"))
        except egress_policy.EgressPolicyError as exc:
            raise ContainerError(
                "target has no numeric IPv4 endpoint on the instance "
                "network") from exc
        self._target_ip = ip
        return ip

    def _start_strict_holder(self) -> None:
        if self.egress_mode != "strict":
            return
        if not self.holder_image:
            raise ContainerError(
                "strict egress requires an explicit trusted holder image")
        if "holder" not in self._image_ids:
            self._image_ids["holder"] = self._image_id(self.holder_image)
        if "solver" not in self._image_ids:
            self._image_ids["solver"] = self._image_id(self.solver_image)
        holder_image_id = self._image_ids["holder"]
        if self._holder_name is None:
            self._holder_name = (
                f"{self.name_prefix}-holder-{self.token}")
        try:
            self.engine.require(
                holder_container_argv(
                    self.engine.path, self._holder_name, holder_image_id,
                    self.network_name, self.instance_id,
                    user=self.solver_user,
                    cpus=self.holder_limits["cpus"],
                    memory=self.holder_limits["memory"],
                    pids_limit=self.holder_limits["pids_limit"],
                    platform=self.platform),
                "start network holder", timeout=120)
            info = self._inspect_holder()
            self._holder_id = info["id"]
            self._holder_pid = info["pid"]
            self._holder_ip = info["ip"]
            self._target_ip_on_network()
            self._policy_marker = egress_policy.policy_marker(
                self.instance_id)
            handle = egress_policy.open_network_namespace(info["pid"])
            self._policy_handle = handle
            # Recheck after opening the FD to close the PID-reuse window.
            recheck = self._inspect_holder()
            if not (recheck["id"] == info["id"]
                    and recheck["pid"] == info["pid"]
                    and recheck["running"]):
                raise ContainerError(
                    "holder identity changed while opening its network "
                    "namespace")
            if not egress_policy.namespace_matches_pid(handle, info["pid"]):
                raise ContainerError(
                    "network namespace FD does not match the running holder")
            if not handle.distinct_from_host:
                raise ContainerError(
                    "holder network namespace is the host namespace")
        except BaseException:
            handle = self._policy_handle
            if handle is not None:
                handle.close()
                self._policy_handle = None
            self._egress_error = "strict holder setup failed"
            raise

    def _image_id(self, reference: str) -> str:
        proc = self.engine.run(
            [self.engine.path, "image", "inspect", "--format", "{{.Id}}",
             reference], timeout=60)
        if not (proc.returncode == 0):
            raise ContainerError(
                f"could not read immutable image identity for {reference}")
        value = (proc.stdout or "").strip()
        if not value:
            raise ContainerError(
                f"image identity for {reference} is empty")
        return value

    def _validate_owned_internal_network(self, name: str) -> None:
        proc = self.engine.require(
            network_inspect_argv(self.engine.path, name),
            "inspect owned second network", timeout=60)
        data = json.loads(proc.stdout)
        labels = data.get("Labels") or {}
        if not (labels.get(LABEL_INSTANCE) == self.instance_id
                and labels.get(LABEL_ROLE) == "network"):
            raise ContainerError(
                "second network ownership label mismatch")
        if not data.get("Internal"):
            raise ContainerError("second network is not internal")
        if not (data.get("Driver") == "bridge"):
            raise ContainerError("second network is not a bridge network")

    def _connect_holder_to_network(self, name: str) -> None:
        """Attach the trusted holder to a second owned internal network.

        This fixture makes the pre-policy second-network positive control
        genuinely reachable from the holder namespace.  The extra network is
        allowed in identity inspection only after ownership/Internal checks.
        """
        if not self._holder_name:
            raise ContainerError("strict egress has no holder name")
        self._validate_owned_internal_network(name)
        self._holder_extra_networks.add(name)
        proc = self.engine.require(
            [self.engine.path, "network", "connect", name,
             self._holder_name],
            "connect holder to second network", timeout=60)
        info = self._inspect_holder()
        if not (info["running"] and self._holder_id == info["id"]
                and self._holder_pid == info["pid"]):
            raise ContainerError(
                "holder identity changed while connecting the second network")
        if not egress_policy.namespace_matches_pid(
                self._policy_handle, info["pid"]):
            raise ContainerError(
                "holder namespace changed while connecting the second "
                "network")
        return proc

    def _disconnect_holder_from_network(self, name: str) -> list[dict]:
        if not self._holder_name:
            self._holder_extra_networks.discard(name)
            return []
        try:
            proc = self.engine.run(
                [self.engine.path, "network", "disconnect", name,
                 self._holder_name], timeout=60)
        except (OSError, subprocess.SubprocessError) as exc:
            return [{
                "role": "sentinel-network",
                "reference": name,
                "error": f"holder disconnect failed: {safe_error_text(exc)}"[:300],
            }]
        not_connected = "not connected" in (proc.stderr or "").lower()
        if (not (proc.returncode == 0)
                and not _is_missing(proc.stderr)
                and not not_connected):
            return [{
                "role": "sentinel-network",
                "reference": name,
                "returncode": proc.returncode,
                "error": "holder disconnect failed",
            }]
        self._holder_extra_networks.discard(name)
        return []

    def _configure_ipv6_test_address(self) -> None:
        if self._policy_handle is None:
            self._ipv6_test_address_configured = False
            self._ipv6_test_address_error = "policy namespace FD is absent"
            return
        address = self._policy_ipv6_test_address
        try:
            proc = self._policy_runtime.configure_ipv6_address(
                self._policy_handle, address)
            if not (proc.returncode == 0):
                self._ipv6_test_address_configured = False
                self._ipv6_test_address_error = (
                    "namespace-local IPv6 address setup failed")
                return
            readback = self._policy_runtime.readback_ipv6_address(
                self._policy_handle)
            if not (readback.returncode == 0):
                self._ipv6_test_address_configured = False
                self._ipv6_test_address_error = (
                    "namespace-local IPv6 address readback failed")
                return
            configured = egress_policy.validate_ipv6(address) in (
                readback.stdout or "")
            self._ipv6_test_address_configured = configured
            self._ipv6_test_address_error = (
                None if configured
                else "namespace-local IPv6 address is not present")
        except (OSError, subprocess.SubprocessError,
                egress_policy.EgressPolicyError):
            self._ipv6_test_address_configured = False
            self._ipv6_test_address_error = (
                "namespace-local IPv6 address setup raised")

    def _host_firewall_state(self) -> dict:
        try:
            v4 = self._policy_runtime.host_readback_v4()
            v6 = self._policy_runtime.host_readback_v6()
        except (OSError, subprocess.SubprocessError) as exc:
            raise ContainerError(
                "host firewall readback is unavailable; strict egress "
                "fails closed") from exc
        if not (v4.returncode == 0 and v6.returncode == 0):
            raise ContainerError(
                "host firewall readback is unavailable; strict egress "
                "fails closed")
        marker = self._policy_marker
        return {
            "digest": egress_policy.firewall_digest(v4.stdout, v6.stdout),
            "marker_present": bool(
                marker and (
                    egress_policy.marker_present(v4.stdout, marker)
                    or egress_policy.marker_present(v6.stdout, marker))),
            "ipv4_readback": True,
            "ipv6_readback": True,
        }

    def _host_marker_present(self) -> bool | None:
        if not self._policy_marker:
            return False
        try:
            state = self._host_firewall_state()
        except ContainerError:
            return None
        return bool(state["marker_present"])

    def _readback_egress_policy(self) -> dict:
        if self._policy_handle is None or self._policy_marker is None:
            return {"ok": False, "errors": ["policy is not installed"],
                    "counters": {}}
        if not self._target_ip:
            return {"ok": False, "errors": ["target IP is unavailable"],
                    "counters": {}}
        processes: dict[str, subprocess.CompletedProcess] = {}
        self._policy_readback_results = {}
        for family, action in (
                ("ipv4", self._policy_runtime.readback_v4),
                ("ipv6", self._policy_runtime.readback_v6)):
            try:
                proc = action(self._policy_handle)
                processes[family] = proc
                self._policy_readback_results[family] = (
                    _policy_process_record(proc, secret=self._flag))
            except (OSError, subprocess.SubprocessError):
                self._policy_readback_results[family] = {
                    "attempted": True,
                    "returncode": None,
                    "error": "readback command failed or timed out",
                }
        errors: list[str] = []
        v4 = processes.get("ipv4")
        v6 = processes.get("ipv6")
        if v4 is None or not (v4.returncode == 0):
            errors.append("ipv4 policy readback failed")
        if v6 is None or not (v6.returncode == 0):
            errors.append("ipv6 policy readback failed")
        view = egress_policy.validate_readback(
            v4.stdout if v4 is not None and v4.returncode == 0 else "",
            v6.stdout if v6 is not None and v6.returncode == 0 else "",
            self._policy_marker, self._target_ip,
            gateway_ip=self._policy_gateway_ip,
            sentinel_ip=self._policy_extra_deny_ip,
            ipv6_test_address=self._policy_ipv6_test_address)
        if errors:
            view["ok"] = False
            view["errors"] = errors + list(view.get("errors") or [])
        self._policy_readback = view
        return view

    def _activate_egress_policy(self, *, extra_deny_ip: str | None = None,
                                require_gateway: bool = True) -> None:
        if self.egress_mode != "strict":
            return
        if self._policy_installed:
            self._ensure_egress_active()
            return
        if self._policy_handle is None or self._policy_marker is None:
            raise ContainerError(
                "cannot install strict egress policy without a holder "
                "network namespace")
        if not self._target_ip:
            self._target_ip = self._target_ip_on_network()
        gateway_ip, gateway_error = self._network_gateway()
        if not gateway_ip and require_gateway:
            raise ContainerError(
                "could not determine the instance gateway for strict egress")
        self._policy_gateway_ip = gateway_ip or None
        self._policy_extra_deny_ip = extra_deny_ip or None
        v4_batch = egress_policy.render_ipv4_policy(
            self._policy_marker, self._target_ip,
            gateway_ip=self._policy_gateway_ip,
            sentinel_ip=self._policy_extra_deny_ip)
        v6_batch = egress_policy.render_ipv6_policy(
            self._policy_marker,
            test_address=self._policy_ipv6_test_address)
        before = self._host_firewall_state()
        self._host_marker_present_before = bool(before["marker_present"])
        self._host_firewall_before = before["digest"]
        if before["marker_present"]:
            self._egress_error = (
                "egress marker is already present on the host firewall")
            raise ContainerError(
                "strict egress policy marker is present on the host "
                "firewall; failing closed")
        self._policy_install_attempted = True
        self._policy_install_results = {}
        for family, action, batch in (
                ("ipv4", self._policy_runtime.install_v4, v4_batch),
                ("ipv6", self._policy_runtime.install_v6, v6_batch)):
            try:
                proc = action(self._policy_handle, batch)
                self._policy_install_results[family] = (
                    _policy_process_record(
                        proc, secret=self._flag, batch=batch))
            except (OSError, subprocess.SubprocessError):
                self._policy_install_results[family] = {
                    "attempted": True,
                    "returncode": None,
                    "error": "install command failed or timed out",
                    **_policy_batch_metadata(batch),
                }
        install_failures = sorted(
            family for family, result in self._policy_install_results.items()
            if result.get("returncode") not in (0,))
        view = self._readback_egress_policy()
        if install_failures:
            self._egress_error = (
                "strict egress policy install failed for "
                + ", ".join(install_failures))
            raise ContainerError(
                "strict egress policy install failed; solver will not start")
        if not view.get("ok"):
            self._egress_error = "strict egress policy readback failed"
            raise ContainerError(
                "strict egress policy readback failed; solver will not start")
        info = self._inspect_holder()
        if not (self._holder_id == info["id"]
                and self._holder_pid == info["pid"]
                and info["running"]):
            self._egress_error = "holder identity changed during policy install"
            raise ContainerError(
                "holder identity changed during policy install")
        if self._policy_handle is None or not \
                egress_policy.namespace_matches_pid(
                    self._policy_handle, info["pid"]):
            self._egress_error = "holder namespace changed during install"
            raise ContainerError(
                "holder network namespace changed during policy install")
        after = self._host_firewall_state()
        self._host_marker_present_after = bool(after["marker_present"])
        self._host_firewall_after = after["digest"]
        if after["marker_present"]:
            self._host_firewall_unchanged = False
            self._egress_error = "policy operation wrote the host firewall"
            raise ContainerError(
                "strict egress policy operation changed the host firewall")
        if not (self._host_firewall_before == self._host_firewall_after):
            self._host_firewall_unchanged = False
            self._egress_error = "policy operation changed host firewall"
            raise ContainerError(
                "strict egress policy operation changed the host firewall")
        self._host_firewall_unchanged = True
        self._policy_installed = True
        self._egress_error = None

    def _ensure_egress_active(self) -> None:
        if self.egress_mode != "strict":
            return
        if not self._policy_installed or self._policy_handle is None:
            raise ContainerError(
                "strict egress policy is not installed; refusing to start "
                "an untrusted solver or probe")
        view = self._readback_egress_policy()
        if not view.get("ok"):
            self._egress_error = "strict egress policy revalidation failed"
            raise ContainerError(
                "strict egress policy revalidation failed; refusing to start "
                "an untrusted solver or probe")
        info = self._inspect_holder()
        if not (self._holder_id == info["id"]
                and self._holder_pid == info["pid"]
                and info["running"]):
            raise ContainerError(
                "holder identity changed; refusing to start an untrusted "
                "solver or probe")
        if not egress_policy.namespace_matches_pid(
                self._policy_handle, info["pid"]):
            raise ContainerError(
                "holder namespace FD changed; refusing to start an untrusted "
                "solver or probe")
        expected_target = self._target_ip
        current_target = self._target_ip_on_network()
        if not (current_target == expected_target):
            raise ContainerError(
                "target numeric endpoint changed after policy install; "
                "refusing to start an untrusted solver or probe")

    def _close_policy_handle(self) -> None:
        handle = self._policy_handle
        if handle is not None:
            handle.close()
            self._policy_handle = None

    def _holder_presence(self) -> bool | None:
        """True only when the holder is explicitly stopped or absent.

        ``None`` means the engine answer is unknown (timeout, transport,
        malformed inspect, or an ownership mismatch).  Callers must retain the
        namespace FD and retryable policy state in that case.
        """
        if not self._holder_name:
            return True
        try:
            proc = self.engine.run(
                container_inspect_argv(self.engine.path, self._holder_name),
                timeout=60)
        except (OSError, subprocess.SubprocessError):
            return None
        if not (proc.returncode == 0):
            return True if _is_missing(proc.stderr) else None
        try:
            data = json.loads(proc.stdout)
        except json.JSONDecodeError:
            return None
        labels = ((data.get("Config") or {}).get("Labels") or {})
        if not (labels.get(LABEL_INSTANCE) == self.instance_id
                and labels.get(LABEL_ROLE) == ROLE_HOLDER):
            return None
        state = data.get("State") or {}
        return not bool(state.get("Running"))

    def _remove_egress_policy(self) -> list[dict]:
        """Retire policy state without weakening a live holder namespace.

        Deny policy is kept until the holder (the last container sharing the
        namespace) is gone.  Only an explicit stopped/absent holder can
        establish that the namespace and its policy are gone.  An engine
        timeout or transport failure is unknown and keeps the FD plus
        retryable ownership state.
        """
        if self.egress_mode != "strict" or self._policy_removed:
            return []
        errors: list[dict] = []
        if self._policy_marker is None or not self._policy_install_attempted:
            self._policy_removed = True
            self._policy_installed = False
            self._close_policy_handle()
            return errors
        presence = self._holder_presence()
        if presence is None:
            errors.append({
                "role": "egress-policy",
                "reference": self._policy_marker,
                "error": "holder state unknown; policy, namespace FD and "
                         "ownership retained for retry",
            })
            return errors
        if presence is False:
            errors.append({
                "role": "egress-policy",
                "reference": self._policy_marker,
                "error": "holder is still running; deny policy retained",
            })
            return errors
        # The holder is explicitly gone/stopped.  Its network namespace (and
        # therefore the whole filter policy) is destroyed when the last FD is
        # closed; the held FD is that last reference here.
        self._close_policy_handle()
        self._policy_installed = False
        self._policy_removed = True
        return errors

    def _egress_public_metadata(self) -> dict:
        handle = self._policy_handle
        readback = self._policy_readback or {}
        return {
            "mode": self.egress_mode,
            "strict": self.egress_mode == "strict",
            "formal_gate_eligible": self.egress_mode == "strict",
            "backend": egress_policy.BACKEND,
            "binaries": dict(egress_policy.LEGACY_BINARIES),
            "holder": {
                "container_name": self._holder_name,
                "container_id": self._holder_id,
                "pid": self._holder_pid,
                "ipv4": self._holder_ip,
                "image": self.holder_image,
                "image_id": self._image_ids.get("holder"),
                "limits": self.holder_limits,
                "extra_networks": sorted(self._holder_extra_networks),
                "flag_mount": False,
                "solver_content": False,
                "network_service": False,
            } if self._holder_name else None,
            "target_numeric_endpoint": (
                f"{self._target_ip}:{TARGET_PORT}"
                if self._target_ip else None),
            "namespace": {
                "fd_held": bool(handle is not None and not handle.closed),
                "namespace_inode": handle.inode if handle else None,
                "host_namespace_inode": handle.host_inode if handle else None,
                "distinct_from_host": bool(
                    handle and handle.distinct_from_host),
                "entered_mount_user_pid_namespaces": False,
            },
            "policy": {
                "marker": self._policy_marker,
                "installed": self._policy_installed,
                "removed": self._policy_removed,
                "validated": bool(readback.get("ok")),
                "install_results": self._policy_install_results,
                "readback_results": self._policy_readback_results,
                "family_state": {
                    family: {
                        "readback_ok": bool(
                            ((readback.get("families") or {}).get(family)
                             or {}).get("ok")),
                    }
                    for family in ("ipv4", "ipv6")
                },
                "atomicity": egress_policy.atomicity_property(),
                "error": self._egress_error,
                "last_readback": self._policy_readback,
                "host_firewall_unchanged": self._host_firewall_unchanged,
                "host_marker_present_before": (
                    self._host_marker_present_before),
                "host_marker_present_after": (
                    self._host_marker_present_after),
                "ipv6_test_address": self._policy_ipv6_test_address,
            },
            "legacy_reports_are_non_accepting": (
                self.egress_mode == "legacy"),
        }

    # -- trusted listener/control helpers ----------------------------------

    def _read_container_count(self, container: str,
                              path: str) -> int | None:
        script = ("import sys\n"
                  "try:\n"
                  "    print(open(sys.argv[1]).read().strip())\n"
                  "except OSError:\n"
                  "    print(0)\n")
        proc = self.engine.run(
            exec_argv(self.engine.path, container,
                      ["python3", "-c", script, path]), timeout=15)
        if proc.returncode != 0:
            return None
        try:
            return int((proc.stdout or "").strip() or "0")
        except ValueError:
            return None

    def _wait_count_increase(self, container: str, path: str,
                             baseline: int, timeout: float = 2.0) -> int:
        deadline = time.monotonic() + timeout
        value = baseline
        while time.monotonic() < deadline:
            current = self._read_container_count(container, path)
            if current is not None:
                value = current
            if value > baseline:
                return value
            time.sleep(0.05)
        return value

    @staticmethod
    def _wait_value_increase(getter, baseline: int,
                             timeout: float = 2.0) -> int:
        deadline = time.monotonic() + timeout
        value = baseline
        while time.monotonic() < deadline:
            current = getter()
            if isinstance(current, int):
                value = current
            if value > baseline:
                return value
            time.sleep(0.05)
        return value

    def _wait_container_file(self, container: str, path: str,
                             timeout: float = 10.0) -> None:
        script = ("import os, sys\n"
                  "raise SystemExit(0 if os.path.exists(sys.argv[1]) "
                  "else 1)\n")
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            proc = self.engine.run(
                exec_argv(self.engine.path, container,
                          ["python3", "-c", script, path]), timeout=10)
            if proc.returncode == 0:
                return
            time.sleep(0.1)
        raise ContainerError("owned listener did not become ready")

    def _start_target_other_listener(self, port: int) -> tuple[str, str]:
        ready = f"/tmp/qjs-target-other-ready-{self.token}"
        count = f"/tmp/qjs-target-other-count-{self.token}"
        self.engine.require(
            [self.engine.path, "exec", "-d", self.target_name,
             "python3", "-c", target_other_listener_script(),
             str(port), ready, count],
            "start owned target listener (detached)", timeout=30)
        self._wait_container_file(self.target_name, ready)
        self._target_other_port = port
        self._target_other_ready = ready
        self._target_other_count = count
        return ready, count

    def _run_egress_probe(self, container: str, mode: str,
                          config: dict, timeout: float) -> dict:
        proc = self.engine.require(
            exec_argv(self.engine.path, container,
                      ["python3", "-c", egress_probe_script(),
                       json.dumps(config)]),
            f"{mode} egress probe", timeout=timeout)
        try:
            return json.loads(proc.stdout)
        except json.JSONDecodeError as exc:
            raise ContainerError("egress probe returned invalid JSON") from exc

    def public_metadata(self) -> dict:
        return {
            "instance_id": self.instance_id,
            "target_endpoint": TARGET_ENDPOINT,
            "solver_argv_endpoint": (
                f"{self._target_ip}:{TARGET_PORT}"
                if self.egress_mode == "strict" and self._target_ip
                else TARGET_ENDPOINT),
            "egress": self._egress_public_metadata(),
            "network": {
                "name": self.network_name,
                "internal": True,
                "target_alias": TARGET_ALIAS,
            },
            "target": {
                "container_name": self.target_name,
                "image": self.target_image,
                "user": self.target_user,
                "limits": self.target_limits,
                "flag_source": "file",
                "flag_length": len(self._flag),
                "secret_dir_mode": "0700",
                "flag_file_mode": "0444",
                "port_published": False,
            },
            "solver": {
                "image": self.solver_image,
                "user": self.solver_user,
                "limits": self.solver_limits,
                "secret_mount": False,
            },
            "health_check": "ok",
        }

    # -- cleanup -------------------------------------------------------------

    def _remove_container(self, reference: str, role: str) -> list[dict]:
        """Best-effort owned container removal; never raises for engine APIs."""
        errors: list[dict] = []
        inspect_error = None
        target_ref = reference
        try:
            inspect = self.engine.run(
                container_inspect_argv(self.engine.path, reference),
                timeout=30)
        except (OSError, subprocess.SubprocessError) as exc:
            inspect = None
            inspect_error = {
                "role": role, "reference": reference,
                "error": f"inventory inspect failed: {safe_error_text(exc)}"[:300],
            }
        if inspect is not None:
            if inspect.returncode == 0:
                try:
                    data = json.loads(inspect.stdout)
                except json.JSONDecodeError:
                    data = {}
                labels = ((data.get("Config") or {}).get("Labels") or {})
                owner = labels.get(LABEL_INSTANCE)
                if owner and owner != self.instance_id:
                    return [{
                        "role": role,
                        "reference": reference,
                        "error": "ownership label mismatch; refusing to remove",
                    }]
                target_ref = data.get("Id") or reference
            elif _is_missing(inspect.stderr):
                # Confirmed absent; nothing to remove.
                return errors
            else:
                inspect_error = {
                    "role": role, "reference": reference,
                    "error": f"inventory inspect failed: "
                             f"{(inspect.stderr or '')[-300:]}",
                }
        try:
            proc = self.engine.run(
                remove_argv(self.engine.path, target_ref), timeout=60)
        except (OSError, subprocess.SubprocessError) as exc:
            if inspect_error is not None:
                errors.append(inspect_error)
            errors.append({
                "role": role, "reference": reference,
                "error": f"remove failed: {safe_error_text(exc)}"[:300],
            })
            return errors
        if proc.returncode != 0 and not _is_missing(proc.stderr):
            if inspect_error is not None:
                errors.append(inspect_error)
            errors.append({
                "role": role,
                "reference": reference,
                "returncode": proc.returncode,
                "error": f"remove failed: {(proc.stderr or '')[-300:]}",
            })
        return errors

    def _remove_network(self, name: str, role: str) -> list[dict]:
        """Best-effort owned network removal; never raises for engine APIs."""
        errors: list[dict] = []
        inspect_error = None
        try:
            inspect = self.engine.run(
                network_inspect_argv(self.engine.path, name), timeout=30)
        except (OSError, subprocess.SubprocessError) as exc:
            inspect = None
            inspect_error = {
                "role": role, "reference": name,
                "error": f"inventory inspect failed: {safe_error_text(exc)}"[:300],
            }
        if inspect is not None:
            if inspect.returncode == 0:
                try:
                    data = json.loads(inspect.stdout)
                except json.JSONDecodeError:
                    data = {}
                labels = data.get("Labels") or {}
                owner = labels.get(LABEL_INSTANCE)
                if owner and owner != self.instance_id:
                    return [{
                        "role": role,
                        "reference": name,
                        "error": "ownership label mismatch; refusing to remove",
                    }]
            elif _is_missing(inspect.stderr):
                return errors
            else:
                inspect_error = {
                    "role": role, "reference": name,
                    "error": f"inventory inspect failed: "
                             f"{(inspect.stderr or '')[-300:]}",
                }
        try:
            proc = self.engine.run(
                network_remove_argv(self.engine.path, name), timeout=60)
        except (OSError, subprocess.SubprocessError) as exc:
            if inspect_error is not None:
                errors.append(inspect_error)
            errors.append({
                "role": role, "reference": name,
                "error": f"remove failed: {safe_error_text(exc)}"[:300],
            })
            return errors
        if proc.returncode != 0 and not _is_missing(proc.stderr):
            if inspect_error is not None:
                errors.append(inspect_error)
            errors.append({
                "role": role,
                "reference": name,
                "returncode": proc.returncode,
                "error": f"remove failed: {(proc.stderr or '')[-300:]}",
            })
        return errors

    def _attempt_container(self, name: str | None, role: str,
                           errors: list[dict]) -> bool:
        if not name:
            return True
        try:
            found = self._remove_container(name, role)
        except Exception as exc:  # noqa: BLE001 - cleanup is best effort
            found = [{"role": role, "reference": name,
                      "error": safe_error_text(exc)[:300]}]
        if found:
            errors.extend(found)
            return False
        return True

    def _attempt_network(self, name: str | None, role: str,
                         errors: list[dict]) -> bool:
        if not name:
            return True
        try:
            found = self._remove_network(name, role)
        except Exception as exc:  # noqa: BLE001 - cleanup is best effort
            found = [{"role": role, "reference": name,
                      "error": safe_error_text(exc)[:300]}]
        if found:
            errors.extend(found)
            return False
        return True

    def stop(self) -> dict:
        # A successful stop is cached; a failed one is retryable.
        if self._cleanup_result is not None and \
                self._cleanup_result.get("ok"):
            return self._cleanup_result
        self._stopped = True
        errors: list[dict] = []

        # Phase 1: stop every untrusted solver/probe before touching the
        # network policy.  A failed removal retains ownership and defers all
        # policy/holder/network teardown so a live process never loses its
        # filtering namespace underneath it.
        if self._active_solver_name:
            if self._attempt_container(
                    self._active_solver_name, "solver", errors):
                self._active_solver_name = None
        for solver_name in list(self._remaining_solver_names):
            if self._attempt_container(solver_name, "solver", errors):
                self._remaining_solver_names.remove(solver_name)
        if self._probe_name:
            if self._attempt_container(self._probe_name, "probe", errors):
                self._probe_name = None
        if self._control_probe_name:
            if self._attempt_container(
                    self._control_probe_name, "control-probe", errors):
                self._control_probe_name = None
        if self._strict_probe_name:
            if self._attempt_container(
                    self._strict_probe_name, "strict-probe", errors):
                self._strict_probe_name = None
        if self._sentinel_name:
            if self._attempt_container(
                    self._sentinel_name, "sentinel", errors):
                self._sentinel_name = None
        if self._solver_config_name:
            if self._attempt_container(
                    self._solver_config_name, "solver-config", errors):
                self._solver_config_name = None

        untrusted_remaining = any((
            self._active_solver_name,
            self._remaining_solver_names,
            self._probe_name,
            self._control_probe_name,
            self._strict_probe_name,
            self._sentinel_name,
            self._solver_config_name,
        ))

        if self.egress_mode == "strict":
            if untrusted_remaining:
                errors.append({
                    "role": "egress-policy",
                    "reference": self._policy_marker or "<strict-policy>",
                    "error": "policy teardown deferred: an untrusted "
                             "container could not be removed",
                })
            else:
                # Keep deny policy until the holder, the last container
                # sharing the namespace, is gone.  Removing the holder
                # destroys the namespace and every in-namespace rule.
                if not self._holder_removed:
                    if self._holder_name is None:
                        self._holder_removed = True
                    elif self._attempt_container(
                            self._holder_name, "holder", errors):
                        self._holder_removed = True
                        self._holder_extra_networks.clear()
                if self._holder_removed:
                    policy_errors = self._remove_egress_policy()
                    errors.extend(policy_errors)
                    if not policy_errors:
                        if not self._target_removed:
                            if self._attempt_container(
                                    self.target_name, "target", errors):
                                self._target_removed = True
                        if self._sentinel_network_name:
                            if self._attempt_network(
                                    self._sentinel_network_name,
                                    "sentinel-network", errors):
                                self._sentinel_network_name = None
                        if not self._network_removed:
                            if self._attempt_network(
                                    self.network_name, "network", errors):
                                self._network_removed = True
        else:
            # Legacy development mode preserves the prior best-effort order.
            if not self._target_removed:
                if self._attempt_container(self.target_name, "target",
                                           errors):
                    self._target_removed = True
            if self._sentinel_network_name:
                if self._attempt_network(
                        self._sentinel_network_name, "sentinel-network",
                        errors):
                    self._sentinel_network_name = None
            if not self._network_removed:
                if self._attempt_network(self.network_name, "network",
                                         errors):
                    self._network_removed = True
        # Local secret removal always happens, regardless of engine state.
        if self.secret_dir is not None:
            try:
                shutil.rmtree(self.secret_dir, ignore_errors=True)
            except OSError as exc:
                errors.append({
                    "role": "secret",
                    "reference": "<secret-directory>",
                    "error": f"secret removal error: {exc}"[:300],
                })
            if self.secret_dir.exists():
                errors.append({
                    "role": "secret",
                    "reference": "<secret-directory>",
                    "error": "secret directory still exists",
                })
            else:
                self.secret_dir = None
        self._cleanup_result = {"ok": not errors, "errors": errors}
        return self._cleanup_result

    # -- solver evaluation ---------------------------------------------------

    @staticmethod
    def _no_new_privileges_enabled(value) -> bool:
        """Require the entire SecurityOpt allowlist to be exactly NNP=true."""
        if not isinstance(value, list) or len(value) != 1:
            return False
        normalized = str(value[0]).strip().lower()
        return normalized in {
            "no-new-privileges:true",
            "no-new-privileges=true",
        }

    def _solver_config_from_inspect(self, data: dict) -> dict:
        config = data.get("Config") or {}
        host = data.get("HostConfig") or {}
        mounts = data.get("Mounts") or []
        env = config.get("Env") or []
        cmd = json.dumps(config.get("Cmd") or [])
        entrypoint = json.dumps(config.get("Entrypoint") or [])
        return {
            "user": config.get("User"),
            "non_root_user": _is_nonroot(config.get("User")),
            "image_id": data.get("Image"),
            "limit_cpu": host.get("NanoCpus"),
            "limit_memory": host.get("Memory"),
            "limit_pids": host.get("PidsLimit"),
            "readonly_rootfs": bool(host.get("ReadonlyRootfs")),
            "cap_drop_all": "ALL" in (host.get("CapDrop") or []),
            "security_opt": host.get("SecurityOpt"),
            "no_new_privileges": self._no_new_privileges_enabled(
                host.get("SecurityOpt")),
            "network_mode": host.get("NetworkMode"),
            "pid_mode": host.get("PidMode"),
            "ipc_mode": host.get("IpcMode"),
            "privileged": bool(host.get("Privileged")),
            "port_bindings": host.get("PortBindings") or {},
            # Keep the complete host-side mount/capability/device config.
            # Docker represents --tmpfs separately from the top-level
            # effective Mounts view and commonly encodes empty lists as null.
            "tmpfs": host.get("Tmpfs"),
            "binds": host.get("Binds"),
            "host_mounts": host.get("Mounts"),
            "volumes_from": host.get("VolumesFrom"),
            "cap_add": host.get("CapAdd"),
            "devices": host.get("Devices"),
            "device_requests": host.get("DeviceRequests"),
            "device_cgroup_rules": host.get("DeviceCgroupRules"),
            "mounts": [
                {"destination": m.get("Destination"),
                 "rw": m.get("RW"), "type": m.get("Type")}
                for m in mounts
            ],
            "secret_mount": any(
                m.get("Destination") == TARGET_FLAG_PATH for m in mounts),
            "docker_socket_mount": any(
                str(m.get("Destination") or "").endswith("docker.sock")
                for m in mounts),
            "flag_env_present": any(
                entry.startswith(FLAG_ENV_NAME + "=") for entry in env),
            "flag_value_in_env": any(self._flag in entry for entry in env),
            "flag_value_in_command": self._flag in (cmd + entrypoint),
        }

    def _inspect_created_container(self, name: str, purpose: str) -> dict:
        proc = self.engine.require(
            container_inspect_argv(self.engine.path, name),
            purpose, timeout=60)
        try:
            data = json.loads(proc.stdout)
        except json.JSONDecodeError as exc:
            raise ContainerError(f"{purpose} returned invalid JSON") from exc
        if not isinstance(data, dict):
            raise ContainerError(f"{purpose} returned a non-object")
        return self._solver_config_from_inspect(data)

    @staticmethod
    def _empty_engine_sequence(value) -> bool:
        """Accept only the engine's two canonical empty-list encodings."""
        return value is None or (isinstance(value, list) and not value)

    @staticmethod
    def _sandbox_tmpfs_exact(value) -> bool:
        """Match the required /tmp tmpfs by semantics, not option order."""
        if not isinstance(value, dict) or set(value) != {"/tmp"}:
            return False
        raw_options = value.get("/tmp")
        if not isinstance(raw_options, str):
            return False
        tokens = [token.strip().lower()
                  for token in raw_options.split(",") if token.strip()]
        if len(tokens) != 5 or len(set(tokens)) != len(tokens):
            return False
        flags = {token for token in tokens if "=" not in token}
        size_tokens = [token.split("=", 1)[1] for token in tokens
                       if token.startswith("size=")]
        keyed = [token for token in tokens if "=" in token]
        return (
            flags == {"rw", "noexec", "nosuid", "nodev"}
            and len(keyed) == 1
            and len(size_tokens) == 1
            and parse_memory_bytes(size_tokens[0]) == 16 * 1024 ** 2
        )

    @staticmethod
    def _effective_mounts_allowlisted(value) -> bool:
        """Allow no effective user mount, or only the expected /tmp tmpfs."""
        if not isinstance(value, list) or len(value) > 1:
            return False
        if not value:
            return True
        mount = value[0]
        return bool(
            isinstance(mount, dict)
            and str(mount.get("type") or "").lower() == "tmpfs"
            and mount.get("destination") == "/tmp"
            and mount.get("rw") is True
        )

    def _strict_solver_config_problems(self, config: dict) -> list[str]:
        if self.egress_mode != "strict":
            return []
        problems = []
        expected_image = self._image_ids.get("solver")
        if not expected_image or not (
                config.get("image_id") == expected_image):
            problems.append("image_identity_mismatch")
        if not (config.get("network_mode") == self._solver_network_mode()):
            problems.append("not_on_holder_network_namespace")
        if config.get("port_bindings"):
            problems.append("published_ports")
        if not config.get("non_root_user"):
            problems.append("root_user")
        if not (config.get("user") == self.solver_user):
            problems.append("user_identity_mismatch")
        if not config.get("readonly_rootfs"):
            problems.append("writable_rootfs")
        if not config.get("cap_drop_all"):
            problems.append("capabilities_not_dropped")
        if not config.get("no_new_privileges"):
            problems.append("no_new_privileges_missing")
        if config.get("privileged"):
            problems.append("privileged")
        if config.get("pid_mode") not in ("", "private"):
            problems.append("pid_namespace_not_private")
        if not (config.get("ipc_mode") == "private"):
            problems.append("ipc_namespace_not_private")
        if not self._sandbox_tmpfs_exact(config.get("tmpfs")):
            problems.append("tmpfs_not_exact")
        if not self._empty_engine_sequence(config.get("binds")):
            problems.append("host_binds")
        if not self._empty_engine_sequence(config.get("host_mounts")):
            problems.append("host_mounts")
        if not self._empty_engine_sequence(config.get("volumes_from")):
            problems.append("volumes_from")
        if not self._effective_mounts_allowlisted(config.get("mounts")):
            problems.append("unexpected_mounts")
        if not self._empty_engine_sequence(config.get("cap_add")):
            problems.append("capabilities_added")
        if not self._empty_engine_sequence(config.get("devices")):
            problems.append("devices")
        if not self._empty_engine_sequence(config.get("device_requests")):
            problems.append("device_requests")
        if not self._empty_engine_sequence(
                config.get("device_cgroup_rules")):
            problems.append("device_cgroup_rules")
        if config.get("secret_mount"):
            problems.append("secret_mount")
        if config.get("docker_socket_mount"):
            problems.append("docker_socket_mount")
        if config.get("flag_env_present") or config.get("flag_value_in_env"):
            problems.append("flag_environment")
        if config.get("flag_value_in_command"):
            problems.append("flag_command")
        if not self._limits_match(config, self.solver_limits, prefix="limit_"):
            problems.append("resource_limits")
        return problems

    def evaluate(self, timeout_s: float) -> dict:
        if self._stopped:
            raise ContainerError("instance is stopped")
        if not (timeout_s > 0):
            raise ContainerError("solver timeout must be positive")
        solver_argv = validate_solver_argv(
            getattr(self, "_solver_argv", None), self._flag)
        if not solver_argv:
            raise ContainerError("no solver argv configured")
        if self.egress_mode == "strict":
            self._ensure_egress_active()
        name = f"{self.name_prefix}-solver-{secrets.token_hex(4)}"
        # Create the actual solver once.  The same container is inspected and
        # then started with ``start -a``; no dummy config container is used.
        argv = solver_container_argv(
            self.engine.path, name, self.solver_image,
            self._solver_network_mode(), self.instance_id, solver_argv,
            user=self.solver_user,
            cpus=self.solver_limits["cpus"],
            memory=self.solver_limits["memory"],
            pids_limit=self.solver_limits["pids_limit"],
            platform=self.platform, create=True,
            endpoint=self._solver_endpoint())
        self._solver_config_name = name
        config = None
        try:
            self.engine.require(argv, "create solver container", timeout=120)
            try:
                config = self._inspect_created_container(
                    name, "inspect solver container")
            except ContainerError:
                if self.egress_mode == "strict":
                    raise
                # Legacy mode is explicitly non-accepting; an unavailable
                # inspect does not prevent the operator-supplied run.
                config = None
            if self.egress_mode == "strict":
                problems = self._strict_solver_config_problems(config)
                if problems:
                    raise ContainerError(
                        "solver container configuration was rejected: "
                        + ", ".join(problems))
                # The interval between the initial policy check and the
                # actual start includes a container create and inspect.  Check
                # the live policy, holder/netns identity and target endpoint
                # again immediately before start; failure removes the created
                # container without ever executing it.
                self._ensure_egress_active()
        except BaseException:
            cleanup_errors = self._remove_container(name, "solver")
            if cleanup_errors:
                if name not in self._remaining_solver_names:
                    self._remaining_solver_names.append(name)
            else:
                self._solver_config_name = None
            self._active_solver_name = None
            raise
        self._solver_config_name = None
        self._active_solver_name = name
        start_argv = [self.engine.path, "start", "-a", name]

        def timeout_cleanup():
            self.engine.run(remove_argv(self.engine.path, name), timeout=60)

        cleanup_errors: list[dict] = []
        try:
            result = execute_solver(start_argv, timeout_s, timeout_cleanup)
        finally:
            try:
                cleanup_errors = self._remove_container(name, "solver")
            except Exception as exc:  # noqa: BLE001 - keep ownership
                cleanup_errors = [{
                    "role": "solver", "reference": name,
                    "error": safe_error_text(exc)[:300],
                }]
            if cleanup_errors:
                # Keep the owned name so a later stop() can retry it.  The
                # failure is also reported in the verdict, but a match verdict
                # stays distinct from overall cleanup success.
                if name not in self._remaining_solver_names:
                    self._remaining_solver_names.append(name)
                self._active_solver_name = None
            else:
                self._active_solver_name = None
        verdict = judge_execution(result, self._flag)
        verdict["timeout_cleanup_error"] = result["timeout_cleanup_error"]
        verdict["container_cleanup"] = {
            "ok": not cleanup_errors,
            "errors": cleanup_errors,
        }
        if config is not None:
            verdict["created_container_inspected_before_start"] = True
            verdict["solver_image_id"] = config.get("image_id")
        return verdict

    # -- strict boundary check ---------------------------------------------

    def _inspect_security_config(self, name: str,
                                 expected_network_mode: str) -> dict:
        config = self._inspect_created_container(
            name, "inspect strict probe configuration")
        config["network_mode_expected"] = expected_network_mode
        return config

    def _default_probe_ip(self, target_ip: str,
                          exclude: set[str]) -> str:
        prefix = target_ip.rsplit(".", 1)[0]
        for last in range(2, 255):
            candidate = f"{prefix}.{last}"
            if candidate in exclude:
                continue
            return candidate
        return "192.0.2.123"

    @staticmethod
    def _counter_packets(counters: dict, key: str) -> int:
        value = counters.get(key)
        if not isinstance(value, dict):
            return 0
        packets = value.get("packets")
        return packets if isinstance(packets, int) else 0

    def _strict_boundary_check(self, timeout_s: float = 60.0) -> dict:
        if self.egress_mode != "strict":
            raise ContainerError("strict boundary requires strict egress")
        if not self._holder_id or not self._target_ip:
            raise ContainerError(
                "strict boundary requires an installed holder and numeric "
                "target endpoint")
        if self._policy_installed:
            raise ContainerError(
                "strict boundary requires a deferred egress policy so the "
                "pre-policy controls run in the holder namespace before "
                "enforcement; refusing to weaken a live policy")
        if self._policy_handle is None or self._policy_marker is None:
            raise ContainerError(
                "strict boundary requires a held holder network namespace")

        # Every pre-policy control helper runs from the explicit trusted
        # holder image.  Operator-supplied solver/probe references are never
        # trust roots: overriding an entrypoint cannot make an untrusted
        # image's python3 (or its startup hooks) safe to execute before both
        # policy families are installed.
        trusted_pre_policy_image_ref = self.holder_image
        if not trusted_pre_policy_image_ref:
            raise ContainerError(
                "strict boundary requires an explicit trusted holder image "
                "for pre-policy execution")
        if "holder" not in self._image_ids:
            self._image_ids["holder"] = self._image_id(
                trusted_pre_policy_image_ref)
        if "solver" not in self._image_ids:
            self._image_ids["solver"] = self._image_id(self.solver_image)
        trusted_pre_policy_image_id = self._image_ids["holder"]

        def tcp_ok(entry) -> bool:
            return bool(entry and entry.get("connected"))

        def tcp_timeout(entry) -> bool:
            return bool(entry and not entry.get("connected")
                        and entry.get("error") == "TimeoutError")

        def loop_tcp_ok(entry) -> bool:
            return bool(entry and entry.get("listener_available")
                        and entry.get("connect_allowed")
                        and entry.get("accepts", 0) > 0)

        def loop_tcp_timeout(entry) -> bool:
            return bool(entry and entry.get("listener_available")
                        and not entry.get("connect_allowed")
                        and entry.get("connect_error") == "TimeoutError"
                        and entry.get("accepts", 0) == 0)

        def loop_udp_ok(entry) -> bool:
            return bool(entry and entry.get("listener_available")
                        and entry.get("sent")
                        and entry.get("received", 0) > 0)

        def udp_rejected(entry) -> bool:
            if not isinstance(entry, dict):
                return False
            if entry.get("sent") is True:
                return True
            return bool(entry.get("error") == "PermissionError"
                        and entry.get("errno") == 1)

        def loop_udp_timeout(entry) -> bool:
            return bool(entry and entry.get("listener_available")
                        and entry.get("received", 0) == 0
                        and (entry.get("sent") is True
                             or entry.get("send_error") == "PermissionError"))

        def dns_ok(entry) -> bool:
            return bool(entry and entry.get("ok"))

        def dns_timeout(entry) -> bool:
            return bool(entry and not entry.get("ok")
                        and entry.get("error") in (
                            "TimeoutError", "PermissionError"))

        def js_ok(probe: dict) -> bool:
            values = probe.get("js_capabilities") or {}
            return bool(values) and all(values.values())

        limitations = [
            "Containers share the host kernel; these probes do not prove "
            "resistance to kernel escape.",
            "IPv4 and IPv6 filter restores are each atomic, but the "
            "two-family install sequence is not atomic. The safety property "
            "is that only the fixed trusted idle holder exists in the "
            "namespace until both families are installed and read back.",
            "The second-network positive control uses a holder interface "
            "attached to the second owned internal network before "
            "enforcement; the same reachable sentinel is denied after policy.",
            "IPv6 test-address rejection is accepted only when a "
            "namespace-local address and live listener were available before "
            "enforcement; an unroutable or absent address is not a pass.",
            "Every executable boundary helper (sentinel, control probe and "
            "post-policy strict probe) runs only the explicitly configured "
            "trusted holder image. The operator-supplied probe image is not "
            "used in strict mode, and the solver image is never started by "
            "the boundary check.",
            "The actual solver image is audited only through a create, exact "
            "inspect and remove sequence. Runtime filesystem/PID/capability "
            "observations come from the trusted holder probe; they are not "
            "presented as self-reported execution evidence from the solver "
            "image.",
        ]
        errors: list[dict] = []
        cleanup_errors: list[dict] = []
        host_tcp = None
        host_udp = None
        sentinel_name = f"{self.name_prefix}-sentinel-{self.token}"
        sentinel_network = f"{self.name_prefix}-net2-{self.token}"
        control_name = f"{self.name_prefix}-control-{self.token}"
        strict_name = f"{self.name_prefix}-strict-{self.token}"
        solver_config_name = (
            f"{self.name_prefix}-solver-config-{self.token}")
        state: dict = {}
        try:
            host_tcp = HostSentinel().start()
            host_udp = HostUdpSentinel().start()
            other_port = 18000 + (int(self.token[:4], 16) % 1000)
            if other_port == TARGET_PORT:
                other_port += 1
            self._start_target_other_listener(other_port)

            gateway_ip, gateway_error = self._network_gateway()
            if not gateway_ip:
                raise ContainerError(
                    "strict boundary requires a numeric instance gateway")
            if gateway_error:
                limitations.append(gateway_error)

            # Create the second owned internal network and its sentinel.
            self._sentinel_network_name = sentinel_network
            self.engine.require(
                network_create_argv(
                    self.engine.path, sentinel_network, self.instance_id),
                "create second-network sentinel", timeout=120)
            self._validate_owned_internal_network(sentinel_network)
            sentinel_tcp_port = 18000 + (
                int(self.token[-4:], 16) % 1000)
            sentinel_udp_port = sentinel_tcp_port + 1
            self._sentinel_name = sentinel_name
            self.engine.require(
                sentinel_container_argv(
                    self.engine.path, sentinel_name,
                    trusted_pre_policy_image_id,
                    sentinel_network, self.instance_id, sentinel_tcp_port,
                    user=self.solver_user, platform=self.platform,
                    udp_port=sentinel_udp_port),
                "start second-network sentinel", timeout=120)
            sentinel_ip = self._container_ip(sentinel_name)
            sentinel_image_id = self._inspect_container_image(
                sentinel_name, "second-network sentinel")
            if not (trusted_pre_policy_image_id
                    and sentinel_image_id == trusted_pre_policy_image_id):
                raise ContainerError(
                    "second-network sentinel is not running the explicit "
                    "trusted holder image")
            sentinel_pre_policy = not self._policy_installed
            self._wait_container_file(
                sentinel_name, "/tmp/qjs-sentinel.tcp-ready")
            self._wait_container_file(
                sentinel_name, "/tmp/qjs-sentinel.udp-ready")
            sentinel_tcp_start = self._read_container_count(
                sentinel_name, "/tmp/qjs-sentinel.tcp") or 0
            sentinel_udp_start = self._read_container_count(
                sentinel_name, "/tmp/qjs-sentinel.udp") or 0
            target_other_start = (
                self._read_container_count(
                    self.target_name, self._target_other_count or "") or 0)

            # Make the second-network control genuinely reachable from the
            # holder namespace before enforcement.  This is a documented
            # test fixture owned by this instance and is validated above.
            self._connect_holder_to_network(sentinel_network)
            self._configure_ipv6_test_address()
            if self._ipv6_test_address_configured is not True:
                limitations.append(
                    "The namespace-local IPv6 test address was not "
                    "configured; IPv6 test-address checks are reported as "
                    "failed rather than as policy-proven rejection.")

            base_port = 22000 + (int(self.token[:4], 16) % 2000)
            config = {
                "mode": "control",
                "target_ip": self._target_ip,
                "target_port": TARGET_PORT,
                "target_other_port": other_port,
                "gateway_ip": gateway_ip,
                "host_tcp_port": host_tcp.port,
                "host_udp_port": host_udp.port,
                "sentinel_ip": sentinel_ip,
                "sentinel_tcp_port": sentinel_tcp_port,
                "sentinel_udp_port": sentinel_udp_port,
                "loopback_tcp_port": base_port,
                "loopback_udp_port": base_port + 1,
                "ipv6_loopback_tcp_port": base_port + 2,
                "ipv6_loopback_udp_port": base_port + 3,
                "ipv6_test_tcp_port": base_port + 4,
                "ipv6_test_udp_port": base_port + 5,
                "ipv6_test_address": self._policy_ipv6_test_address,
                "dns_name": TARGET_ALIAS,
                "default_probe_ip": self._default_probe_ip(
                    self._target_ip,
                    {self._target_ip, gateway_ip, egress_policy.DOCKER_DNS,
                     self._holder_ip or ""}),
                "default_probe_port": base_port + 6,
            }
            # Do not copy the controller environment into the engine
            # client.  Only a harmless PATH plus a unique canary name are
            # supplied; the container must not inherit that canary.
            env_sentinel = secrets.token_hex(8)
            probe_env = {
                "PATH": os.environ.get(
                    "PATH",
                    "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:"
                    "/sbin:/bin"),
                "LC_ALL": "C",
                "HOME": "/tmp",
                CONTROLLER_ENV_SENTINEL: env_sentinel,
            }
            # The probe checks the canary variable *name* in the container
            # environment; the random value stays only in the engine client.
            config["controller_env_sentinel"] = CONTROLLER_ENV_SENTINEL

            # Pre-policy positive control in the holder namespace.
            self._control_probe_name = control_name
            control_pre_policy = not self._policy_installed
            self.engine.require(
                probe_container_argv(
                    self.engine.path, control_name,
                    trusted_pre_policy_image_id,
                    f"container:{self._holder_id}", self.instance_id,
                    user=self.solver_user,
                    cpus=self.holder_limits["cpus"],
                    memory=self.holder_limits["memory"],
                    pids_limit=self.holder_limits["pids_limit"],
                    platform=self.platform, role=ROLE_CONTROL_PROBE),
                "start trusted control probe", timeout=120,
                env=probe_env)
            control_config = self._inspect_security_config(
                control_name, f"container:{self._holder_id}")
            control_image_id = control_config.get("image_id")
            if not (trusted_pre_policy_image_id
                    and control_image_id == trusted_pre_policy_image_id):
                raise ContainerError(
                    "control probe is not running the explicit trusted "
                    "holder image")
            control = self._run_egress_probe(
                control_name, "control", config, timeout_s)
            control_host_tcp = self._wait_value_increase(
                lambda: host_tcp.accepted, 0)
            control_host_udp = self._wait_value_increase(
                lambda: host_udp.received, 0)
            sentinel_tcp_control = self._wait_count_increase(
                sentinel_name, "/tmp/qjs-sentinel.tcp",
                sentinel_tcp_start)
            sentinel_udp_control = self._wait_count_increase(
                sentinel_name, "/tmp/qjs-sentinel.udp",
                sentinel_udp_start)
            target_other_control = self._wait_count_increase(
                self.target_name, self._target_other_count or "",
                target_other_start)
            control_errors: list[dict] = []
            control_removed = self._attempt_container(
                control_name, "control-probe", control_errors)
            if control_removed:
                self._control_probe_name = None
            else:
                errors.extend(control_errors)
                raise ContainerError(
                    "trusted control probe could not be stopped; refusing to "
                    "activate or probe strict policy")
            if not (
                    tcp_ok(control.get("target_other_port"))
                    and tcp_ok(control.get("host_tcp"))
                    and tcp_ok(control.get("second_network_tcp"))
                    and loop_tcp_ok(
                        (control.get("loopback_ipv4") or {}).get("tcp"))
                    and loop_tcp_ok(
                        (control.get("loopback_ipv6") or {}).get("tcp"))
                    and loop_tcp_ok(
                        (control.get("ipv6_test_address") or {}).get("tcp"))):
                limitations.append(
                    "At least one pre-policy positive control was not "
                    "reachable; the corresponding post-policy rejection is "
                    "not accepted as policy-proven.")

            # Install and validate both families only after the trusted
            # control helper has exited the holder namespace.
            self._activate_egress_policy(
                extra_deny_ip=sentinel_ip, require_gateway=True)
            before_view = self._readback_egress_policy()
            if not before_view.get("ok"):
                raise ContainerError(
                    "strict egress readback failed before the strict probe")
            counters_before = before_view.get("counters") or {}

            # Audit the actual solver container configuration without ever
            # starting that image.  This helper performs create, exact inspect
            # and remove only; a bad identity or sandbox configuration makes
            # full isolation pending but cannot influence the trusted runtime
            # probe below.
            actual_solver_config = self._inspect_solver_config(
                solver_config_name, cleanup_errors)
            actual_solver_problems = self._strict_solver_config_problems(
                actual_solver_config)

            # Revalidate the complete live boundary immediately before the
            # trusted post-policy probe is started.  The earlier policy
            # readback alone does not recheck holder identity, the held netns,
            # or the target's current numeric endpoint.
            self._ensure_egress_active()

            # The strict runtime probe uses only the trusted holder image.
            # The untrusted solver and optional probe images are never started
            # by boundary mode and therefore cannot forge runtime evidence.
            strict_probe_started_after_policy = bool(
                self._policy_installed and before_view.get("ok"))
            if not strict_probe_started_after_policy:
                raise ContainerError(
                    "refusing to start the trusted strict probe before both "
                    "policy families are installed and read back")
            self._strict_probe_name = strict_name
            self.engine.require(
                probe_container_argv(
                    self.engine.path, strict_name,
                    trusted_pre_policy_image_id,
                    f"container:{self._holder_id}", self.instance_id,
                    user=self.solver_user,
                    cpus=self.holder_limits["cpus"],
                    memory=self.holder_limits["memory"],
                    pids_limit=self.holder_limits["pids_limit"],
                    platform=self.platform, role=ROLE_STRICT_PROBE),
                "start trusted strict probe", timeout=120,
                env=probe_env)
            strict_config = self._inspect_security_config(
                strict_name, f"container:{self._holder_id}")
            strict_image_id = strict_config.get("image_id")
            if not (trusted_pre_policy_image_id
                    and strict_image_id == trusted_pre_policy_image_id):
                raise ContainerError(
                    "strict probe is not running the explicit trusted "
                    "holder image")
            strict_payload = dict(config)
            strict_payload["mode"] = "strict"
            strict = self._run_egress_probe(
                strict_name, "strict", strict_payload, timeout_s)
            strict_errors: list[dict] = []
            strict_removed = self._attempt_container(
                strict_name, "strict-probe", strict_errors)
            if strict_removed:
                self._strict_probe_name = None
            else:
                errors.extend(strict_errors)

            time.sleep(0.2)
            strict_host_tcp = host_tcp.accepted
            strict_host_udp = host_udp.received
            sentinel_tcp_strict = self._read_container_count(
                sentinel_name, "/tmp/qjs-sentinel.tcp") or 0
            sentinel_udp_strict = self._read_container_count(
                sentinel_name, "/tmp/qjs-sentinel.udp") or 0
            target_other_strict = (
                self._read_container_count(
                    self.target_name, self._target_other_count or "") or 0)

            after_view = self._readback_egress_policy()
            counters_after = after_view.get("counters") or {}
            deltas = {
                key: (self._counter_packets(counters_after, key)
                      - self._counter_packets(counters_before, key))
                for key in set(counters_before) | set(counters_after)
            }

            try:
                target_ns = self._container_namespaces(self.target_name)
            except (ContainerError, OSError, subprocess.SubprocessError,
                    json.JSONDecodeError):
                target_ns = {}
            try:
                holder_ns = self._container_namespaces(self._holder_name)
            except (ContainerError, OSError, subprocess.SubprocessError,
                    json.JSONDecodeError):
                holder_ns = {}

            state = {
                "control": control,
                "strict": strict,
                "control_config": control_config,
                "strict_config": strict_config,
                "actual_solver_config": actual_solver_config,
                "actual_solver_problems": actual_solver_problems,
                "pre_policy": {
                    "trusted_image": trusted_pre_policy_image_ref,
                    "trusted_image_id": trusted_pre_policy_image_id,
                    "solver_image": self.solver_image,
                    "solver_image_id": self._image_ids.get("solver"),
                    "probe_image": self.probe_image,
                    "control_image_id": control_image_id,
                    "sentinel_image_id": sentinel_image_id,
                    "strict_probe_image_id": strict_image_id,
                    "control_started_before_policy": control_pre_policy,
                    "sentinel_started_before_policy": sentinel_pre_policy,
                    "strict_probe_started_after_policy": (
                        strict_probe_started_after_policy),
                    "actual_solver_config_inspected": True,
                    "actual_solver_container_started": False,
                    "helper_healthchecks_disabled": True,
                },
                "gateway_ip": gateway_ip,
                "sentinel_ip": sentinel_ip,
                "target_ns": target_ns,
                "holder_ns": holder_ns,
                "before_view": before_view,
                "after_view": after_view,
                "counters_before": counters_before,
                "counters_after": counters_after,
                "deltas": deltas,
                "host_marker_present": self._host_marker_present_after,
                "host_firewall_unchanged": (
                    self._host_firewall_unchanged is True),
                "receive_counts": {
                    "host_tcp": {
                        "control": control_host_tcp,
                        "after_strict": strict_host_tcp},
                    "host_udp": {
                        "control": control_host_udp,
                        "after_strict": strict_host_udp},
                    "second_network_tcp": {
                        "before": sentinel_tcp_start,
                        "control": sentinel_tcp_control,
                        "after_strict": sentinel_tcp_strict},
                    "second_network_udp": {
                        "before": sentinel_udp_start,
                        "control": sentinel_udp_control,
                        "after_strict": sentinel_udp_strict},
                    "target_other_port": {
                        "before": target_other_start,
                        "control": target_other_control,
                        "after_strict": target_other_strict},
                },
            }
        finally:
            if self._control_probe_name:
                if self._attempt_container(
                        self._control_probe_name, "control-probe",
                        cleanup_errors):
                    self._control_probe_name = None
            if self._strict_probe_name:
                if self._attempt_container(
                        self._strict_probe_name, "strict-probe",
                        cleanup_errors):
                    self._strict_probe_name = None
            if self._sentinel_name:
                if self._attempt_container(
                        self._sentinel_name, "sentinel",
                        cleanup_errors):
                    self._sentinel_name = None
            if self._sentinel_network_name:
                if not self._holder_removed:
                    cleanup_errors.extend(
                        self._disconnect_holder_from_network(
                            self._sentinel_network_name))
                if self._attempt_network(
                        self._sentinel_network_name,
                        "sentinel-network", cleanup_errors):
                    self._sentinel_network_name = None
            if host_tcp is not None:
                host_tcp.stop()
            if host_udp is not None:
                host_udp.stop()

        if not state:
            raise ContainerError("strict boundary probe did not complete")

        control = state["control"]
        strict = state["strict"]
        control_config = state["control_config"]
        strict_config = state["strict_config"]
        actual_solver_config = state["actual_solver_config"]
        actual_solver_problems = state["actual_solver_problems"]
        pre_policy = state["pre_policy"]
        before_view = state["before_view"]
        after_view = state["after_view"]
        counters_before = state["counters_before"]
        counters_after = state["counters_after"]
        deltas = state["deltas"]
        receive = state["receive_counts"]
        target_ns = state["target_ns"]
        holder_ns = state["holder_ns"]
        handle = self._policy_handle
        probe_namespaces = strict.get("namespaces") or {}
        control_namespaces = control.get("namespaces") or {}
        probe_pid_ns = probe_namespaces.get("pid_ns")
        probe_mnt_ns = probe_namespaces.get("mnt_ns")
        probe_net_ns = probe_namespaces.get("net_ns")
        control_net_ns = control_namespaces.get("net_ns")
        target_pid_ns = target_ns.get("pid_ns")
        target_mnt_ns = target_ns.get("mnt_ns")
        holder_pid_ns = holder_ns.get("pid_ns")
        holder_mnt_ns = holder_ns.get("mnt_ns")
        caps = strict.get("capabilities") or {}
        mutation = caps.get("firewall_mutation") or {}
        expected_solver_image = self._image_ids.get("solver")
        strict_probe_image_is_holder = bool(
            trusted_pre_policy_image_id
            and strict_config.get("image_id")
            == trusted_pre_policy_image_id)

        control_loop4 = (control.get("loopback_ipv4") or {})
        control_loop6 = (control.get("loopback_ipv6") or {})
        control_test6 = (control.get("ipv6_test_address") or {})
        strict_loop4 = (strict.get("loopback_ipv4") or {})
        strict_loop6 = (strict.get("loopback_ipv6") or {})
        strict_test6 = (strict.get("ipv6_test_address") or {})
        checks: dict[str, bool] = {
            # Pre-policy positive controls.
            "control_target_health": bool(control.get("target_health")),
            "control_target_repeated": bool(control.get("target_repeated")),
            "control_target_large_request": bool(
                control.get("target_large_request")),
            "control_js_capabilities": js_ok(control),
            "control_target_other_port": tcp_ok(
                control.get("target_other_port")),
            "control_host_tcp": tcp_ok(control.get("host_tcp")),
            "control_host_udp_received": receive["host_udp"]["control"] > 0,
            "control_second_network_tcp_received": (
                receive["second_network_tcp"]["control"]
                > receive["second_network_tcp"]["before"]),
            "control_second_network_udp_received": (
                receive["second_network_udp"]["control"]
                > receive["second_network_udp"]["before"]),
            "control_target_other_port_received": (
                receive["target_other_port"]["control"]
                > receive["target_other_port"]["before"]),
            "control_docker_dns_udp": dns_ok(control.get("docker_dns_udp")),
            "control_docker_dns_tcp": dns_ok(control.get("docker_dns_tcp")),
            "control_loopback_ipv4_tcp": loop_tcp_ok(control_loop4.get("tcp")),
            "control_loopback_ipv4_udp": loop_udp_ok(control_loop4.get("udp")),
            "control_loopback_ipv6_tcp": loop_tcp_ok(control_loop6.get("tcp")),
            "control_loopback_ipv6_udp": loop_udp_ok(control_loop6.get("udp")),
            "control_ipv6_test_address_tcp": loop_tcp_ok(
                control_test6.get("tcp")),
            "control_ipv6_test_address_udp": loop_udp_ok(
                control_test6.get("udp")),
            "control_mapped_forbidden_ipv4": tcp_ok(
                control.get("mapped_forbidden_ipv4")),
            # Pre-policy execution identity and ordering.  Untrusted
            # solver/probe references must never run before enforcement.
            "control_probe_pre_policy": bool(
                pre_policy["control_started_before_policy"]),
            "sentinel_pre_policy": bool(
                pre_policy["sentinel_started_before_policy"]),
            "control_probe_image_is_holder_image": bool(
                trusted_pre_policy_image_id
                and pre_policy["control_image_id"]
                == trusted_pre_policy_image_id),
            "sentinel_image_is_holder_image": bool(
                trusted_pre_policy_image_id
                and pre_policy["sentinel_image_id"]
                == trusted_pre_policy_image_id),
            # Strict positive endpoint path.
            "strict_target_health": bool(strict.get("target_health")),
            "strict_target_repeated": bool(strict.get("target_repeated")),
            "strict_target_large_request": bool(
                strict.get("target_large_request")),
            "strict_js_capabilities": js_ok(strict),
            # Strict negative path; only a timeout after a live pre-policy
            # control is accepted as policy-proven rejection.
            "strict_target_other_port_rejected": tcp_timeout(
                strict.get("target_other_port")),
            "strict_host_tcp_rejected": tcp_timeout(strict.get("host_tcp")),
            "strict_second_network_tcp_rejected": tcp_timeout(
                strict.get("second_network_tcp")),
            "strict_docker_dns_udp_rejected": dns_timeout(
                strict.get("docker_dns_udp")),
            "strict_docker_dns_tcp_rejected": dns_timeout(
                strict.get("docker_dns_tcp")),
            "strict_loopback_ipv4_tcp_rejected": loop_tcp_timeout(
                strict_loop4.get("tcp")),
            "strict_loopback_ipv4_udp_rejected": loop_udp_timeout(
                strict_loop4.get("udp")),
            "strict_loopback_ipv6_tcp_rejected": loop_tcp_timeout(
                strict_loop6.get("tcp")),
            "strict_loopback_ipv6_udp_rejected": loop_udp_timeout(
                strict_loop6.get("udp")),
            "strict_ipv6_test_address_tcp_rejected": loop_tcp_timeout(
                strict_test6.get("tcp")),
            "strict_ipv6_test_address_udp_rejected": loop_udp_timeout(
                strict_test6.get("udp")),
            "strict_mapped_forbidden_ipv4_rejected": tcp_timeout(
                strict.get("mapped_forbidden_ipv4")),
            "strict_default_probe_tcp_rejected": tcp_timeout(
                strict.get("default_probe_tcp")),
            "strict_default_probe_send": udp_rejected(
                strict.get("default_probe_send")),
            # Owned listener receive counts did not move during strict probe.
            "receive_counts_unchanged": bool(
                receive["host_tcp"]["after_strict"]
                == receive["host_tcp"]["control"]
                and receive["host_udp"]["after_strict"]
                == receive["host_udp"]["control"]
                and receive["second_network_tcp"]["after_strict"]
                == receive["second_network_tcp"]["control"]
                and receive["second_network_udp"]["after_strict"]
                == receive["second_network_udp"]["control"]
                and receive["target_other_port"]["after_strict"]
                == receive["target_other_port"]["control"]),
            # Kernel counters.
            "policy_readback_valid": bool(after_view.get("ok")),
            "policy_allow_counter_positive": deltas.get(
                "output_allow", 0) > 0,
            "policy_input_counter_positive": deltas.get(
                "input_established", 0) > 0,
            "policy_target_other_counter_positive": deltas.get(
                "output_target_other_port", 0) > 0,
            "policy_gateway_counter_positive": deltas.get(
                "output_gateway", 0) > 0,
            "policy_second_network_counter_positive": deltas.get(
                "output_second_network", 0) > 0,
            "policy_dns_counter_positive": deltas.get(
                "output_docker_dns", 0) > 0,
            "policy_loopback_counter_positive": deltas.get(
                "output_loopback", 0) > 0,
            "policy_udp_counter_positive": deltas.get(
                "output_udp", 0) > 0,
            "policy_default_counter_positive": deltas.get(
                "output_default", 0) > 0,
            "policy_ipv6_loopback_counter_positive": deltas.get(
                "output_v6_loopback", 0) > 0,
            "policy_ipv6_test_counter_positive": deltas.get(
                "output_v6_test_address", 0) > 0,
            # Namespace, image and host-firewall identity.
            "holder_netns_distinct_from_host": bool(
                handle is not None and handle.distinct_from_host),
            "holder_policy_absent_from_host_namespace": (
                state["host_marker_present"] is False),
            "host_firewall_unchanged": state["host_firewall_unchanged"],
            "control_probe_net_namespace_is_holder": bool(
                handle is not None and control_net_ns
                and control_net_ns == f"net:[{handle.inode}]"),
            "strict_probe_net_namespace_is_holder": bool(
                handle is not None and probe_net_ns
                and probe_net_ns == f"net:[{handle.inode}]"),
            "strict_probe_pid_namespace_distinct_target": bool(
                probe_pid_ns and target_pid_ns
                and not (probe_pid_ns == target_pid_ns)),
            "strict_probe_mount_namespace_distinct_target": bool(
                probe_mnt_ns and target_mnt_ns
                and not (probe_mnt_ns == target_mnt_ns)),
            "strict_probe_pid_namespace_distinct_holder": bool(
                probe_pid_ns and holder_pid_ns
                and not (probe_pid_ns == holder_pid_ns)),
            "strict_probe_mount_namespace_distinct_holder": bool(
                probe_mnt_ns and holder_mnt_ns
                and not (probe_mnt_ns == holder_mnt_ns)),
            "strict_probe_image_is_holder_image": (
                strict_probe_image_is_holder),
            "strict_probe_started_after_policy": bool(
                pre_policy["strict_probe_started_after_policy"]),
            # Trusted runtime-boundary evidence.  These observations come
            # from the explicit holder image, never from the solver image.
            "trusted_probe_uid_nonroot": strict.get("uid") not in (None, 0),
            "trusted_probe_secret_file_absent": not strict.get(
                "secret_file_exists", True),
            "trusted_probe_flag_env_absent": not strict.get(
                "flag_env_variable_present", True),
            "trusted_probe_controller_env_absent": not strict.get(
                "controller_env_sentinel_present", True),
            "trusted_probe_docker_socket_absent": not strict.get(
                "docker_socket_exists", True),
            "trusted_probe_rootfs_readonly": bool(
                strict.get("root_write_blocked")),
            "trusted_probe_no_cap_net_admin": bool(
                caps.get("no_cap_net_admin")),
            "trusted_probe_no_cap_sys_admin": bool(
                caps.get("no_cap_sys_admin")),
            "trusted_probe_unshare_netns_denied": bool(
                caps.get("unshare_netns_denied")),
            "trusted_probe_setns_netns_denied": (
                caps.get("setns_netns_denied") is True),
            "trusted_probe_firewall_mutation_denied": bool(
                caps.get("no_cap_net_admin")
                or (mutation.get("attempted")
                    and mutation.get("denied"))),
            "trusted_probe_config_non_root": bool(
                strict_config.get("non_root_user")),
            "trusted_probe_config_user_exact": bool(
                strict_config.get("user") == self.solver_user),
            "trusted_probe_config_readonly": bool(
                strict_config.get("readonly_rootfs")),
            "trusted_probe_config_cap_drop_all": bool(
                strict_config.get("cap_drop_all")),
            "trusted_probe_config_no_new_privileges": bool(
                strict_config.get("no_new_privileges")),
            "trusted_probe_config_not_privileged": not bool(
                strict_config.get("privileged")),
            "trusted_probe_config_network_mode_holder": bool(
                strict_config.get("network_mode")
                == f"container:{self._holder_id}"),
            "trusted_probe_config_pid_namespace_private": bool(
                strict_config.get("pid_mode") in ("", "private")),
            "trusted_probe_config_ipc_namespace_private": bool(
                strict_config.get("ipc_mode") == "private"),
            "trusted_probe_config_no_ports": not bool(
                strict_config.get("port_bindings")),
            "trusted_probe_config_tmpfs_exact": (
                self._sandbox_tmpfs_exact(strict_config.get("tmpfs"))),
            "trusted_probe_config_no_binds": (
                self._empty_engine_sequence(strict_config.get("binds"))),
            "trusted_probe_config_no_host_mounts": (
                self._empty_engine_sequence(
                    strict_config.get("host_mounts"))),
            "trusted_probe_config_no_volumes_from": (
                self._empty_engine_sequence(
                    strict_config.get("volumes_from"))),
            "trusted_probe_config_mount_allowlist": (
                self._effective_mounts_allowlisted(
                    strict_config.get("mounts"))),
            "trusted_probe_config_no_cap_add": (
                self._empty_engine_sequence(strict_config.get("cap_add"))),
            "trusted_probe_config_no_devices": (
                self._empty_engine_sequence(strict_config.get("devices"))),
            "trusted_probe_config_no_device_requests": (
                self._empty_engine_sequence(
                    strict_config.get("device_requests"))),
            "trusted_probe_config_no_device_cgroup_rules": (
                self._empty_engine_sequence(
                    strict_config.get("device_cgroup_rules"))),
            "trusted_probe_config_limits": bool(
                self._limits_match(strict_config, self.holder_limits,
                                   prefix="limit_")),
            # Exact create/inspect-only audit of the actual solver container.
            "actual_solver_config_image_identity": bool(
                expected_solver_image
                and actual_solver_config.get("image_id")
                == expected_solver_image),
            "actual_solver_config_network_mode_holder": bool(
                actual_solver_config.get("network_mode")
                == f"container:{self._holder_id}"),
            "actual_solver_config_no_ports": not bool(
                actual_solver_config.get("port_bindings")),
            "actual_solver_config_non_root": bool(
                actual_solver_config.get("non_root_user")),
            "actual_solver_config_user_exact": bool(
                actual_solver_config.get("user") == self.solver_user),
            "actual_solver_config_readonly": bool(
                actual_solver_config.get("readonly_rootfs")),
            "actual_solver_config_cap_drop_all": bool(
                actual_solver_config.get("cap_drop_all")),
            "actual_solver_config_no_new_privileges": bool(
                actual_solver_config.get("no_new_privileges")),
            "actual_solver_config_not_privileged": not bool(
                actual_solver_config.get("privileged")),
            "actual_solver_config_pid_namespace_private": bool(
                actual_solver_config.get("pid_mode") in ("", "private")),
            "actual_solver_config_ipc_namespace_private": bool(
                actual_solver_config.get("ipc_mode") == "private"),
            "actual_solver_config_tmpfs_exact": (
                self._sandbox_tmpfs_exact(
                    actual_solver_config.get("tmpfs"))),
            "actual_solver_config_no_binds": (
                self._empty_engine_sequence(
                    actual_solver_config.get("binds"))),
            "actual_solver_config_no_host_mounts": (
                self._empty_engine_sequence(
                    actual_solver_config.get("host_mounts"))),
            "actual_solver_config_no_volumes_from": (
                self._empty_engine_sequence(
                    actual_solver_config.get("volumes_from"))),
            # Keep the existing result key for compatibility; it now means
            # no effective bind/volume/other mount beyond the expected /tmp
            # tmpfs declared exactly above.
            "actual_solver_config_no_mounts": (
                self._effective_mounts_allowlisted(
                    actual_solver_config.get("mounts"))),
            "actual_solver_config_no_cap_add": (
                self._empty_engine_sequence(
                    actual_solver_config.get("cap_add"))),
            "actual_solver_config_no_devices": (
                self._empty_engine_sequence(
                    actual_solver_config.get("devices"))),
            "actual_solver_config_no_device_requests": (
                self._empty_engine_sequence(
                    actual_solver_config.get("device_requests"))),
            "actual_solver_config_no_device_cgroup_rules": (
                self._empty_engine_sequence(
                    actual_solver_config.get("device_cgroup_rules"))),
            "actual_solver_config_no_secret_mount": not bool(
                actual_solver_config.get("secret_mount")),
            "actual_solver_config_no_docker_socket": not bool(
                actual_solver_config.get("docker_socket_mount")),
            "actual_solver_config_no_flag_env": not bool(
                actual_solver_config.get("flag_env_present")
                or actual_solver_config.get("flag_value_in_env")),
            "actual_solver_config_no_flag_command": not bool(
                actual_solver_config.get("flag_value_in_command")),
            "actual_solver_config_limits": bool(
                self._limits_match(actual_solver_config, self.solver_limits,
                                   prefix="limit_")),
            "actual_solver_config_allowlist": not actual_solver_problems,
            "actual_solver_container_never_started": bool(
                pre_policy["actual_solver_config_inspected"]
                and not pre_policy["actual_solver_container_started"]),
            "control_probe_config_non_root": bool(
                control_config.get("non_root_user")),
            "control_probe_config_readonly": bool(
                control_config.get("readonly_rootfs")),
            "control_probe_config_network_mode_holder": bool(
                control_config.get("network_mode")
                == f"container:{self._holder_id}"),
        }

        egress_checks = [
            "control_target_health", "control_target_repeated",
            "control_target_large_request", "control_js_capabilities",
            "control_target_other_port", "control_host_tcp",
            "control_host_udp_received",
            "control_second_network_tcp_received",
            "control_second_network_udp_received",
            "control_target_other_port_received",
            "control_docker_dns_udp", "control_docker_dns_tcp",
            "control_loopback_ipv4_tcp", "control_loopback_ipv4_udp",
            "control_loopback_ipv6_tcp", "control_loopback_ipv6_udp",
            "control_ipv6_test_address_tcp",
            "control_ipv6_test_address_udp",
            "control_mapped_forbidden_ipv4",
            "control_probe_pre_policy", "sentinel_pre_policy",
            "control_probe_image_is_holder_image",
            "sentinel_image_is_holder_image",
            "strict_target_health", "strict_target_repeated",
            "strict_target_large_request", "strict_js_capabilities",
            "strict_target_other_port_rejected", "strict_host_tcp_rejected",
            "strict_second_network_tcp_rejected",
            "strict_docker_dns_udp_rejected",
            "strict_docker_dns_tcp_rejected",
            "strict_loopback_ipv4_tcp_rejected",
            "strict_loopback_ipv4_udp_rejected",
            "strict_loopback_ipv6_tcp_rejected",
            "strict_loopback_ipv6_udp_rejected",
            "strict_ipv6_test_address_tcp_rejected",
            "strict_ipv6_test_address_udp_rejected",
            "strict_mapped_forbidden_ipv4_rejected",
            "strict_default_probe_tcp_rejected",
            "strict_default_probe_send",
            "receive_counts_unchanged",
            "policy_readback_valid", "policy_allow_counter_positive",
            "policy_input_counter_positive",
            "policy_target_other_counter_positive",
            "policy_gateway_counter_positive",
            "policy_second_network_counter_positive",
            "policy_dns_counter_positive",
            "policy_loopback_counter_positive",
            "policy_udp_counter_positive",
            "policy_default_counter_positive",
            "policy_ipv6_loopback_counter_positive",
            "policy_ipv6_test_counter_positive",
            "holder_netns_distinct_from_host",
            "holder_policy_absent_from_host_namespace",
            "host_firewall_unchanged",
            "control_probe_net_namespace_is_holder",
            "strict_probe_net_namespace_is_holder",
            "strict_probe_pid_namespace_distinct_target",
            "strict_probe_mount_namespace_distinct_target",
            "strict_probe_pid_namespace_distinct_holder",
            "strict_probe_mount_namespace_distinct_holder",
            "strict_probe_image_is_holder_image",
            "strict_probe_started_after_policy",
        ]
        security_checks = [
            "trusted_probe_uid_nonroot", "trusted_probe_secret_file_absent",
            "trusted_probe_flag_env_absent",
            "trusted_probe_controller_env_absent",
            "trusted_probe_docker_socket_absent",
            "trusted_probe_rootfs_readonly",
            "trusted_probe_no_cap_net_admin",
            "trusted_probe_no_cap_sys_admin",
            "trusted_probe_unshare_netns_denied",
            "trusted_probe_setns_netns_denied",
            "trusted_probe_firewall_mutation_denied",
            "trusted_probe_config_non_root",
            "trusted_probe_config_user_exact",
            "trusted_probe_config_readonly",
            "trusted_probe_config_cap_drop_all",
            "trusted_probe_config_no_new_privileges",
            "trusted_probe_config_not_privileged",
            "trusted_probe_config_network_mode_holder",
            "trusted_probe_config_pid_namespace_private",
            "trusted_probe_config_ipc_namespace_private",
            "trusted_probe_config_no_ports",
            "trusted_probe_config_tmpfs_exact",
            "trusted_probe_config_no_binds",
            "trusted_probe_config_no_host_mounts",
            "trusted_probe_config_no_volumes_from",
            "trusted_probe_config_mount_allowlist",
            "trusted_probe_config_no_cap_add",
            "trusted_probe_config_no_devices",
            "trusted_probe_config_no_device_requests",
            "trusted_probe_config_no_device_cgroup_rules",
            "trusted_probe_config_limits",
            "actual_solver_config_image_identity",
            "actual_solver_config_network_mode_holder",
            "actual_solver_config_no_ports",
            "actual_solver_config_non_root",
            "actual_solver_config_user_exact",
            "actual_solver_config_readonly",
            "actual_solver_config_cap_drop_all",
            "actual_solver_config_no_new_privileges",
            "actual_solver_config_not_privileged",
            "actual_solver_config_pid_namespace_private",
            "actual_solver_config_ipc_namespace_private",
            "actual_solver_config_tmpfs_exact",
            "actual_solver_config_no_binds",
            "actual_solver_config_no_host_mounts",
            "actual_solver_config_no_volumes_from",
            "actual_solver_config_no_mounts",
            "actual_solver_config_no_cap_add",
            "actual_solver_config_no_devices",
            "actual_solver_config_no_device_requests",
            "actual_solver_config_no_device_cgroup_rules",
            "actual_solver_config_no_secret_mount",
            "actual_solver_config_no_docker_socket",
            "actual_solver_config_no_flag_env",
            "actual_solver_config_no_flag_command",
            "actual_solver_config_limits",
            "actual_solver_config_allowlist",
            "actual_solver_container_never_started",
            "control_probe_config_non_root",
            "control_probe_config_readonly",
            "control_probe_config_network_mode_holder",
        ]
        helpers_ok = not cleanup_errors and not any((
            self._control_probe_name,
            self._strict_probe_name,
            self._sentinel_name,
            self._sentinel_network_name,
            self._solver_config_name,
        ))
        egress_failures = [name for name in egress_checks
                           if not checks.get(name)]
        if not helpers_ok:
            egress_failures.append("boundary_helper_cleanup_failed")
        security_failures = [name for name in security_checks
                             if not checks.get(name)]
        egress_ok = not egress_failures
        security_ok = not security_failures
        if egress_ok and security_ok:
            status = "passed"
            isolation_status = "passed"
        elif egress_ok:
            status = "partial"
            isolation_status = "pending"
        else:
            status = "failed"
            isolation_status = "pending"
        trusted_evidence_checks = {
            name: bool(checks.get(name))
            for name in security_checks
            if not name.startswith("actual_solver_")
        }
        actual_solver_config_checks = {
            name: bool(checks.get(name))
            for name in security_checks
            if name.startswith("actual_solver_")
        }
        trusted_evidence_status = (
            "passed" if all(trusted_evidence_checks.values()) else "failed")
        actual_solver_status = (
            "passed" if all(actual_solver_config_checks.values())
            else "failed")
        filesystem_status = "passed" if security_ok else "failed"
        actual_solver_checks = {
            "status": actual_solver_status,
            "solver_image": self.solver_image,
            "image_id": actual_solver_config.get("image_id"),
            "expected_solver_image_id": expected_solver_image,
            "execution": "not-started",
            "inspection": "create-inspect-remove",
            "configuration_problems": list(actual_solver_problems),
            "checks": actual_solver_config_checks,
        }
        trusted_runtime_evidence = {
            "status": trusted_evidence_status,
            "image": trusted_pre_policy_image_ref,
            "image_id": strict_config.get("image_id"),
            "expected_holder_image_id": trusted_pre_policy_image_id,
            "trust": "explicit-holder-image",
            "checks": trusted_evidence_checks,
        }
        failures = sorted(set(egress_failures + security_failures))
        result = {
            "status": status,
            "mode": "strict",
            "formal_gate_eligible": True,
            "backend": egress_policy.BACKEND,
            "failures": failures,
            "egress_failures": sorted(set(egress_failures)),
            "security_failures": sorted(set(security_failures)),
            "pending_isolation_checks": sorted(set(security_failures)),
            "checks": checks,
            "endpoint": {
                "target_numeric": self._solver_endpoint(),
                "target_ipv4": self._target_ip,
                "port": TARGET_PORT,
                "solver_network_mode": f"container:{self._holder_id}",
                "second_network_sentinel_ip": state["sentinel_ip"],
                "gateway_ip": state["gateway_ip"],
            },
            "identities": {
                "holder_container_name": self._holder_name,
                "holder_container_id": self._holder_id,
                "holder_pid": self._holder_pid,
                "holder_ipv4": self._holder_ip,
                "holder_image_id": self._image_ids.get("holder"),
                "network": self.network_name,
                "policy_marker": self._policy_marker,
                "namespace_inode": handle.inode if handle else None,
                "host_namespace_inode": (
                    handle.host_inode if handle else None),
                "holder_netns_distinct_from_host": bool(
                    handle is not None and handle.distinct_from_host),
                "host_policy_marker_present": state["host_marker_present"],
                "control_netns": "holder_pre_policy",
                "strict_netns": "holder_post_policy",
                "pre_policy_image": pre_policy["trusted_image"],
                "pre_policy_image_id": pre_policy["trusted_image_id"],
                "control_image_id": pre_policy["control_image_id"],
                "sentinel_image_id": pre_policy["sentinel_image_id"],
                "strict_probe_image_id": pre_policy[
                    "strict_probe_image_id"],
                "actual_solver_config_image_id": (
                    actual_solver_config.get("image_id")),
                "second_network": sentinel_network,
                "holder_extra_networks": sorted(self._holder_extra_networks),
            },
            "policy": {
                "backend": egress_policy.BACKEND,
                "binaries": dict(egress_policy.LEGACY_BINARIES),
                "marker": self._policy_marker,
                "readback_ok": bool(after_view.get("ok")),
                "readback_errors": after_view.get("errors") or [],
                "families": after_view.get("families") or {},
                "atomicity": egress_policy.atomicity_property(),
                "install_results": self._policy_install_results,
                "counters_before": counters_before,
                "counters_after": counters_after,
                "counter_deltas": deltas,
                "host_firewall_before_sha256": self._host_firewall_before,
                "host_firewall_after_sha256": self._host_firewall_after,
                "host_firewall_unchanged": state["host_firewall_unchanged"],
                "host_marker_present_after": state["host_marker_present"],
                "ipv6_test_address": self._policy_ipv6_test_address,
                "ipv6_test_address_configured": (
                    self._ipv6_test_address_configured is True),
                "ipv6_test_address_error": self._ipv6_test_address_error,
            },
            "receive_counts": receive,
            "execution_order": pre_policy,
            "probes": {
                "trusted_control": control,
                "trusted_strict": strict,
            },
            "trusted_probe_capabilities": caps,
            "trusted_strict_probe_config": strict_config,
            "control_probe_config": control_config,
            "actual_solver_config": actual_solver_config,
            "trusted_runtime_evidence": trusted_runtime_evidence,
            "filesystem_pid_separation": {
                "status": filesystem_status,
                "scope": (
                    "Runtime observations are from the trusted holder probe; "
                    "the actual solver contributes configuration evidence "
                    "only and was not executed."),
                "evidence_model": (
                    "trusted-holder-runtime-plus-actual-solver-config"),
                "trusted_probe_image": trusted_pre_policy_image_ref,
                "solver_image": self.solver_image,
                "solver_image_executed": False,
                "trusted_runtime_evidence": trusted_runtime_evidence,
                "actual_solver_checks": actual_solver_checks,
            },
            "actual_solver_checks": actual_solver_checks,
            "boundary_cleanup": {
                "ok": helpers_ok,
                "errors": cleanup_errors,
            },
            "errors": errors,
            "limitations": limitations,
            "endpoint_only_egress": {
                "status": "passed" if egress_ok else "failed",
                "reason": (
                    "Legacy iptables/ip6tables policy was installed and read "
                    "back for both families, the endpoint allow and every "
                    "required deny counter were exercised, pre-policy "
                    "controls were reachable, and owned listeners observed "
                    "zero receives from the trusted strict probe."
                    if egress_ok else
                    "Strict egress did not satisfy every positive, negative, "
                    "counter, identity, pre-policy-control or cleanup check."),
            },
            "isolation_gate": {
                "status": isolation_status,
                "reason": (
                    "The full boundary passed using runtime evidence from the "
                    "explicit trusted holder probe plus an exact, non-"
                    "executing configuration audit of the actual solver "
                    "container. The solver image did not self-report or run "
                    "during boundary mode."
                    if isolation_status == "passed" else
                    "Full isolation is not proven. Only the precisely "
                    "verified properties above are reported; the formal "
                    "isolation gate remains pending."
                    if egress_ok else
                    "Strict egress itself is not proven, so full isolation "
                    "remains pending and the boundary has failed."),
            },
        }
        return result

    # -- boundary check ------------------------------------------------------

    def boundary_check(self, timeout_s: float = 60.0) -> dict:
        if self._stopped:
            raise ContainerError("instance is stopped")
        if self.egress_mode == "strict":
            return self._strict_boundary_check(timeout_s)
        return self._legacy_boundary_check(timeout_s)

    def _legacy_boundary_check(self, timeout_s: float = 60.0) -> dict:
        same_image = self.probe_image == self.solver_image
        limitations = [
            "Containers share the host kernel; these probes do not prove "
            "resistance to kernel escape.",
            "An internal Docker bridge alone is not proof of endpoint-only "
            "egress. Strict egress filtering is reported as pending unless it "
            "is independently implemented and verified.",
            "Probe results are configuration checks from a few controlled "
            "containers, not a cryptographic or formal security proof.",
        ]
        if same_image:
            limitations.append(
                "The solver-like probe ran in the same image reference as "
                "the configured solver image; filesystem/PID checks describe "
                "that image.")
        else:
            limitations.append(
                "The solver-like probe ran in the operator-supplied probe "
                f"image {self.probe_image}, not the configured solver image "
                f"{self.solver_image}. Actual-solver filesystem/PID checks "
                "remain pending.")
        solver_config_name = f"{self.name_prefix}-solver-config-{self.token}"
        probe_name = f"{self.name_prefix}-probe-{self.token}"
        sentinel_network = f"{self.name_prefix}-net2-{self.token}"
        sentinel_name = f"{self.name_prefix}-sentinel-{self.token}"
        host_sentinel = None
        errors: list[dict] = []
        # Record ownership before every create/start attempt.
        self._solver_config_name = solver_config_name
        self._probe_name = probe_name
        self._sentinel_name = sentinel_name
        self._sentinel_network_name = sentinel_network
        try:
            solver_config = self._inspect_solver_config(
                solver_config_name, errors)
            host_sentinel = HostSentinel().start()
            gateway_ip, gateway_error = self._network_gateway()
            self.engine.require(
                network_create_argv(
                    self.engine.path, sentinel_network, self.instance_id),
                "create second-network sentinel", timeout=120)
            sentinel_port = 18000 + (int(self.token[:4], 16) % 1000)
            self.engine.require(
                sentinel_container_argv(
                    self.engine.path, sentinel_name, self.probe_image,
                    sentinel_network, self.instance_id, sentinel_port,
                    user=self.solver_user, platform=self.platform),
                "start second-network sentinel", timeout=120)
            sentinel_ip = self._container_ip(sentinel_name)
            self._wait_sentinel(sentinel_name, sentinel_port)
            probe_env = dict(os.environ)
            probe_env[CONTROLLER_ENV_SENTINEL] = secrets.token_hex(8)
            self.engine.require(
                probe_container_argv(
                    self.engine.path, probe_name, self.probe_image,
                    self.network_name, self.instance_id,
                    user=self.solver_user,
                    cpus=self.solver_limits["cpus"],
                    memory=self.solver_limits["memory"],
                    pids_limit=self.solver_limits["pids_limit"],
                    platform=self.platform),
                "start solver-like boundary probe", timeout=120,
                env=probe_env)
            probe = self._run_boundary_probe(
                probe_name, gateway_ip, host_sentinel.port, sentinel_ip,
                sentinel_port, timeout_s)
            target_ns = self._container_namespaces(self.target_name)
            target_config = self._inspect_target_config()
            network_info = self._network_info()
            checks = self._boundary_checks(
                solver_config, target_config, network_info, probe,
                target_ns, sentinel_ip, gateway_ip)
            failures = self._boundary_failures(checks, probe)
            status = "failed" if failures else "partial"
            if gateway_error:
                limitations.append(gateway_error)
            probe_only_names = (
                "solver_uid_nonroot",
                "solver_secret_file_absent",
                "controller_env_sentinel_absent",
                "solver_rootfs_readonly",
                "pid_namespaces_distinct",
                "mount_namespaces_distinct",
            )
            probe_checks = {name: bool(checks.get(name))
                            for name in probe_only_names}
            probe_checks_all = all(probe_checks.values())
            if same_image:
                filesystem_status = (
                    "passed" if probe_checks_all else "failed")
                actual_solver_checks = {
                    "status": filesystem_status,
                    "probe_image": self.probe_image,
                    "solver_image": self.solver_image,
                    "images_identical": True,
                }
            else:
                filesystem_status = "pending_actual_solver"
                actual_solver_checks = {
                    "status": "pending",
                    "probe_image": self.probe_image,
                    "solver_image": self.solver_image,
                    "images_identical": False,
                    "probe_image_checks_status": (
                        "passed" if probe_checks_all else "failed"),
                    "reason": "Filesystem/PID probes ran in the probe image, "
                              "not the actual solver image.",
                }
            result = {
                "status": status,
                "mode": "legacy",
                "formal_gate_eligible": False,
                "failures": failures,
                "checks": checks,
                "egress": self._egress_public_metadata(),
                "namespace": {
                    "target": target_ns,
                    "solver_side_probe": {
                        "pid_ns": probe.get("pid_ns"),
                        "mnt_ns": probe.get("mnt_ns"),
                    },
                    "pid_namespaces_distinct": checks[
                        "pid_namespaces_distinct"],
                    "mount_namespaces_distinct": checks[
                        "mount_namespaces_distinct"],
                },
                "network": {
                    "name": self.network_name,
                    "internal": network_info.get("Internal"),
                    "gateway": gateway_ip,
                    "target_endpoint": TARGET_ENDPOINT,
                    "host_gateway_sentinel_port": host_sentinel.port,
                    "second_network": sentinel_network,
                    "second_network_sentinel_ip": sentinel_ip,
                    "host_gateway_sentinel_accepted": host_sentinel.accepted,
                    "external_probes": {
                        "1.1.1.1:53": probe.get(
                            "external_1_1_1_1_53_reachable"),
                        "8.8.8.8:53": probe.get(
                            "external_8_8_8_8_53_reachable"),
                    },
                },
                "solver_config": solver_config,
                "target_config": target_config,
                "probe_image": self.probe_image,
                "solver_image": self.solver_image,
                "probe_image_matches_solver_image": same_image,
                "filesystem_pid_separation": {
                    "status": filesystem_status,
                    "probe_image": self.probe_image,
                    "solver_image": self.solver_image,
                    "images_identical": same_image,
                    "probe_image_checks": probe_checks,
                    "actual_solver_checks": actual_solver_checks,
                },
                "actual_solver_checks": actual_solver_checks,
                "endpoint_only_egress": {
                    "status": "not-accepted-legacy",
                    "reason": "Legacy development mode installs no strict "
                              "endpoint-only egress policy. Sentinel probes "
                              "are evidence about this network configuration "
                              "only and can never satisfy the formal gate.",
                },
                "isolation_gate": {
                    "status": "not-accepted-legacy",
                    "reason": "Legacy development mode is non-accepting. "
                              "The documented formal command uses strict "
                              "mode with an installed and read-back policy.",
                },
                "limitations": limitations,
            }
        finally:
            if self._probe_name:
                if self._attempt_container(self._probe_name, "probe", errors):
                    self._probe_name = None
            if self._sentinel_name:
                if self._attempt_container(
                        self._sentinel_name, "sentinel", errors):
                    self._sentinel_name = None
            if self._sentinel_network_name:
                if self._attempt_network(
                        self._sentinel_network_name,
                        "sentinel-network", errors):
                    self._sentinel_network_name = None
            if host_sentinel is not None:
                host_sentinel.stop()
        if errors:
            result["cleanup"] = {"ok": False, "errors": errors}
            result["status"] = "failed"
            result.setdefault("failures", []).append(
                "boundary_cleanup_failed")
        else:
            result["cleanup"] = {"ok": True, "errors": []}
        return result

    def _inspect_solver_config(self, name: str,
                               errors: list[dict] | None = None) -> dict:
        # docker create needs a command.  In boundary-only mode the operator
        # may not supply solver argv; a harmless placeholder keeps the config
        # probe non-executing.
        solver_argv = getattr(self, "_solver_argv", None) or ["/bin/true"]
        if any(self._flag in part for part in solver_argv):
            raise ContainerError("solver argv must not contain the flag")
        # Record ownership before the create attempt even when this helper is
        # invoked directly rather than through boundary_check().
        if self._solver_config_name is None:
            self._solver_config_name = name
        argv = solver_container_argv(
            self.engine.path, name, self.solver_image,
            self._solver_network_mode(), self.instance_id, solver_argv,
            user=self.solver_user, cpus=self.solver_limits["cpus"],
            memory=self.solver_limits["memory"],
            pids_limit=self.solver_limits["pids_limit"],
            platform=self.platform, create=True,
            endpoint=self._solver_endpoint())
        collected = errors if errors is not None else []
        data = None
        try:
            # The create response may be lost; the unique owned name is
            # recorded before the attempt and removal is always attempted.
            self.engine.require(argv, "create solver config probe",
                                timeout=120)
            proc = self.engine.require(
                container_inspect_argv(self.engine.path, name),
                "inspect solver config", timeout=60)
            data = json.loads(proc.stdout)
        finally:
            if self._attempt_container(name, "solver-config", collected):
                if self._solver_config_name == name:
                    self._solver_config_name = None
            elif errors is None:
                raise ContainerError(
                    "solver config helper cleanup failed")
        if data is None:
            raise ContainerError("solver config inspect returned no data")
        if not isinstance(data, dict):
            raise ContainerError("solver config inspect returned a non-object")
        return self._solver_config_from_inspect(data)

    def _inspect_target_config(self) -> dict:
        proc = self.engine.require(
            container_inspect_argv(self.engine.path, self.target_name),
            "inspect target container", timeout=60)
        data = json.loads(proc.stdout)
        config = data.get("Config") or {}
        host = data.get("HostConfig") or {}
        mounts = data.get("Mounts") or []
        flag_mount = next(
            (m for m in mounts if m.get("Destination") == TARGET_FLAG_PATH),
            None)
        return {
            "user": config.get("User"),
            "non_root_user": _is_nonroot(config.get("User")),
            "network_mode": host.get("NetworkMode"),
            "pid_mode": host.get("PidMode"),
            "privileged": bool(host.get("Privileged")),
            "readonly_rootfs": bool(host.get("ReadonlyRootfs")),
            "cap_drop_all": "ALL" in (host.get("CapDrop") or []),
            "no_new_privileges": any(
                "no-new-privileges" in str(opt)
                for opt in (host.get("SecurityOpt") or [])),
            "memory": host.get("Memory"),
            "nano_cpus": host.get("NanoCpus"),
            "pids_limit": host.get("PidsLimit"),
            "port_bindings": host.get("PortBindings") or {},
            "flag_mount_readonly": bool(flag_mount)
            and flag_mount.get("RW") is False,
        }

    def _network_info(self) -> dict:
        proc = self.engine.require(
            network_inspect_argv(self.engine.path, self.network_name),
            "inspect instance network", timeout=60)
        data = json.loads(proc.stdout)
        return {
            "Name": data.get("Name"),
            "Id": data.get("Id"),
            "Internal": data.get("Internal"),
            "Driver": data.get("Driver"),
            "Labels": data.get("Labels") or {},
        }

    def _network_gateway(self) -> tuple[str, str | None]:
        proc = self.engine.run(
            [self.engine.path, "network", "inspect", "--format",
             "{{json .IPAM.Config}}", self.network_name], timeout=60)
        if proc.returncode != 0:
            return "", "could not read the network gateway"
        try:
            configs = json.loads(proc.stdout)
            gateway = (configs or [{}])[0].get("Gateway") or ""
        except (json.JSONDecodeError, IndexError, AttributeError):
            return "", "could not parse the network gateway"
        if not gateway:
            return "", "the network has no gateway; host gateway probe skipped"
        return gateway, None

    def _container_ip(self, name: str) -> str:
        proc = self.engine.require(
            container_inspect_argv(self.engine.path, name),
            "inspect sentinel container", timeout=60)
        data = json.loads(proc.stdout)
        networks = (data.get("NetworkSettings") or {}).get("Networks") or {}
        for entry in networks.values():
            ip = entry.get("IPAddress")
            if ip:
                return ip
        raise ContainerError("sentinel container has no network address")

    def _inspect_container_image(self, name: str, purpose: str) -> str:
        """Return the immutable image ID a helper actually runs.

        Pre-policy control helpers must be proven to run the explicit
        trusted holder image.  The engine-resolved container image ID is the
        only evidence that an operator-supplied probe or solver reference did
        not silently become the trust root.
        """
        proc = self.engine.require(
            container_inspect_argv(self.engine.path, name),
            f"inspect {purpose} image identity", timeout=60)
        try:
            data = json.loads(proc.stdout)
        except json.JSONDecodeError as exc:
            raise ContainerError(
                f"{purpose} image inspect returned invalid JSON") from exc
        if not isinstance(data, dict):
            raise ContainerError(
                f"{purpose} image inspect returned a non-object")
        image_id = data.get("Image")
        if not isinstance(image_id, str) or not image_id:
            raise ContainerError(
                f"{purpose} has no immutable image identity")
        return image_id

    def _container_namespaces(self, name: str) -> dict:
        proc = self.engine.require(
            exec_argv(self.engine.path, name,
                      ["python3", "-c", namespace_script()]),
            "target namespace probe", timeout=30)
        return json.loads(proc.stdout)

    def _wait_sentinel(self, name: str, port: int) -> None:
        deadline = time.monotonic() + 10.0
        probe = (
            "import socket\n"
            f"socket.create_connection(('127.0.0.1', {port}), 1).close()\n"
            "print('SENTINEL_READY')\n"
        )
        while time.monotonic() < deadline:
            proc = self.engine.run(
                exec_argv(self.engine.path, name,
                          ["python3", "-c", probe]), timeout=10)
            if proc.returncode == 0 and "SENTINEL_READY" in (
                    proc.stdout or ""):
                return
            time.sleep(0.1)
        raise ContainerError("second-network sentinel did not listen")

    def _run_boundary_probe(self, name: str, gateway_ip: str,
                            gateway_port: int, sentinel_ip: str,
                            sentinel_port: int, timeout_s: float) -> dict:
        argv = exec_argv(
            self.engine.path, name,
            ["python3", "-c", boundary_probe_script(),
             gateway_ip, str(gateway_port), sentinel_ip,
             str(sentinel_port), CONTROLLER_ENV_SENTINEL,
             TARGET_ENDPOINT])
        proc = self.engine.require(argv, "solver-like boundary probe",
                                   timeout=timeout_s)
        return json.loads(proc.stdout)

    def _boundary_checks(self, solver: dict, target: dict, network: dict,
                         probe: dict, target_ns: dict, sentinel_ip: str,
                         gateway_ip: str) -> dict:
        pid_distinct = bool(
            target_ns.get("pid_ns") and probe.get("pid_ns")
            and target_ns.get("pid_ns") != probe.get("pid_ns"))
        mnt_distinct = bool(
            target_ns.get("mnt_ns") and probe.get("mnt_ns")
            and target_ns.get("mnt_ns") != probe.get("mnt_ns"))
        return {
            "target_service_reachable": bool(probe.get("target_reachable")),
            "target_health": bool(probe.get("target_health")),
            "solver_uid_nonroot": probe.get("uid") not in (None, 0),
            "solver_secret_file_absent": not probe.get(
                "secret_file_exists", True),
            "solver_flag_env_absent": not probe.get(
                "flag_env_variable_present", True)
            and not solver.get("flag_env_present", True)
            and not solver.get("flag_value_in_env", True),
            "solver_flag_argv_absent": not solver.get(
                "flag_value_in_command", True),
            "controller_env_sentinel_absent": not probe.get(
                "controller_env_sentinel_present", True),
            "docker_socket_absent": not probe.get(
                "docker_socket_exists", True)
            and not solver.get("docker_socket_mount", True),
            "solver_no_secret_mount": not solver.get("secret_mount", True),
            "solver_config_non_root": bool(solver.get("non_root_user")),
            "solver_config_readonly": bool(solver.get("readonly_rootfs")),
            "solver_config_cap_drop_all": bool(solver.get("cap_drop_all")),
            "solver_config_no_new_privileges": bool(
                solver.get("no_new_privileges")),
            "solver_config_no_host_pid": solver.get("pid_mode")
            not in ("host",),
            "solver_config_no_host_ipc": solver.get("ipc_mode")
            not in ("host",),
            "solver_config_not_privileged": not solver.get(
                "privileged", True),
            "solver_config_no_ports": not (solver.get("port_bindings") or {}),
            "solver_config_limits": self._limits_match(
                solver, self.solver_limits, prefix="limit_"),
            "solver_rootfs_readonly": bool(probe.get("root_write_blocked")),
            "pid_namespaces_distinct": pid_distinct,
            "mount_namespaces_distinct": mnt_distinct,
            "network_internal": bool(network.get("Internal")),
            "network_is_instance": network.get("Name")
            == self.network_name,
            "solver_network_is_instance": solver.get("network_mode")
            == self.network_name,
            "target_network_is_instance": target.get("network_mode")
            == self.network_name,
            "target_non_root": bool(target.get("non_root_user")),
            "target_not_privileged": not target.get("privileged", True),
            "target_cap_drop_all": bool(target.get("cap_drop_all")),
            "target_no_new_privileges": bool(
                target.get("no_new_privileges")),
            "target_readonly_rootfs": bool(target.get("readonly_rootfs")),
            "target_flag_mount_readonly": bool(
                target.get("flag_mount_readonly")),
            "target_no_published_ports": not (
                target.get("port_bindings") or {}),
            "target_no_host_pid": target.get("pid_mode") not in ("host",),
            "target_limits": self._limits_match(
                target, self.target_limits),
            "host_gateway_sentinel_unreachable": not probe.get(
                "host_gateway_reachable", True),
            "host_docker_internal_unreachable": not probe.get(
                "host_docker_internal_reachable", True),
            "second_network_sentinel_unreachable": not probe.get(
                "second_network_reachable", True),
            "external_egress_unreachable": not (
                probe.get("external_1_1_1_1_53_reachable")
                or probe.get("external_8_8_8_8_53_reachable")),
            "gateway_probe_configured": bool(gateway_ip),
            "second_network_sentinel_configured": bool(sentinel_ip),
        }

    def _limits_match(self, record: dict, limits: dict,
                      prefix: str = "") -> bool:
        nano_key = prefix + "cpu" if prefix else "nano_cpus"
        memory_key = prefix + "memory" if prefix else "memory"
        pids_key = prefix + "pids" if prefix else "pids_limit"
        memory_bytes = parse_memory_bytes(limits["memory"])
        return (
            record.get(nano_key) == int(limits["cpus"] * 1_000_000_000)
            and record.get(memory_key) == memory_bytes
            and record.get(pids_key) == limits["pids_limit"]
        )

    def _boundary_failures(self, checks: dict, probe: dict) -> list[str]:
        required = (
            "target_service_reachable",
            "target_health",
            "solver_uid_nonroot",
            "solver_secret_file_absent",
            "solver_flag_env_absent",
            "solver_flag_argv_absent",
            "controller_env_sentinel_absent",
            "docker_socket_absent",
            "solver_no_secret_mount",
            "solver_config_non_root",
            "solver_config_readonly",
            "solver_config_cap_drop_all",
            "solver_config_no_new_privileges",
            "solver_config_no_host_pid",
            "solver_config_no_host_ipc",
            "solver_config_not_privileged",
            "solver_config_no_ports",
            "solver_config_limits",
            "solver_rootfs_readonly",
            "pid_namespaces_distinct",
            "mount_namespaces_distinct",
            "network_internal",
            "network_is_instance",
            "solver_network_is_instance",
            "target_network_is_instance",
            "target_non_root",
            "target_not_privileged",
            "target_cap_drop_all",
            "target_no_new_privileges",
            "target_readonly_rootfs",
            "target_flag_mount_readonly",
            "target_no_published_ports",
            "target_no_host_pid",
            "target_limits",
            "host_gateway_sentinel_unreachable",
            "host_docker_internal_unreachable",
            "second_network_sentinel_unreachable",
        )
        failures = [name for name in required if not checks.get(name)]
        if not checks.get("gateway_probe_configured"):
            failures.append("gateway_probe_not_configured")
        if not checks.get("second_network_sentinel_configured"):
            failures.append("second_network_sentinel_not_configured")
        if not checks.get("external_egress_unreachable"):
            failures.append("external_egress_reachable")
        return failures


def _is_missing(stderr: str | None) -> bool:
    text = (stderr or "").lower()
    return "no such" in text or "not found" in text


def _is_nonroot(user: str | None) -> bool:
    if not user:
        return False
    name = user.split(":", 1)[0].strip()
    if name in ("", "root", "0"):
        return False
    if name.isdigit():
        return int(name) != 0
    return True


def parse_memory_bytes(text: str) -> int | None:
    text = text.strip().lower()
    multipliers = {"k": 1024, "m": 1024 ** 2, "g": 1024 ** 3}
    if text and text[-1] in multipliers:
        try:
            return int(float(text[:-1]) * multipliers[text[-1]])
        except ValueError:
            return None
    try:
        return int(text)
    except ValueError:
        return None


# ---------------------------------------------------------------------------
# Public report sanitization

SAFE_ENGINE_SUBCOMMANDS = {
    "build", "run", "create", "rm", "inspect", "network", "image",
    "version", "exec", "logs", "volume", "ps", "start", "stop",
}
SAFE_ENGINE_OPERATIONS = {
    "create", "rm", "inspect", "ls", "prune", "start", "stop",
}


def public_engine_calls(calls: list[dict]) -> list[dict]:
    """Metadata-only view of engine calls for public reports.

    The raw argv can contain private inline solver code or operator
    arguments, so no argument value is exported.
    """
    public = []
    for call in calls:
        argv = call.get("argv") or []
        subcommand = (argv[1] if len(argv) > 1
                      and argv[1] in SAFE_ENGINE_SUBCOMMANDS
                      else "<redacted>")
        operation = None
        if (subcommand in ("network", "image", "volume")
                and len(argv) > 2
                and argv[2] in SAFE_ENGINE_OPERATIONS):
            operation = argv[2]
        public.append({
            "subcommand": subcommand,
            "operation": operation,
            "argument_count": len(argv),
            "returncode": call.get("returncode"),
            "timed_out": call.get("error") == "timeout",
            "arguments_redacted": True,
        })
    return public


# ---------------------------------------------------------------------------
# Evaluator lifecycle

class ContainerEvaluator:
    def __init__(self, engine: Engine, target_image: str,
                 solver_image: str, solver_argv: list[str] | None = None,
                 *, probe_image: str | None = None,
                 platform: str = "linux/amd64",
                 target_user: str = "10001:10001",
                 solver_user: str = "10001:10001",
                 target_cpus: float = 2.0, target_memory: str = "2g",
                 target_pids: int = 64, solver_cpus: float = 1.0,
                 solver_memory: str = "1g", solver_pids: int = 128,
                 startup_timeout: float = 20.0,
                 name_prefix: str = "qjs-ctf", flag_factory=new_flag,
                 egress_mode: str = "strict",
                 holder_image: str | None = None,
                 holder_cpus: float = 0.5,
                 holder_memory: str = "128m",
                 holder_pids: int = 32,
                 defer_egress: bool = False):
        if egress_mode not in EGRESS_MODES:
            raise ContainerError("invalid egress mode")
        if egress_mode == "strict" and not holder_image:
            raise ContainerError(
                "strict egress requires an explicit trusted holder image")
        self.engine = engine
        self.target_image = target_image
        self.solver_image = solver_image
        self.solver_argv = (validate_solver_argv(solver_argv)
                            if solver_argv else [])
        self.probe_image = probe_image
        self.platform = platform
        self.target_user = target_user
        self.solver_user = solver_user
        self.target_cpus = target_cpus
        self.target_memory = target_memory
        self.target_pids = target_pids
        self.solver_cpus = solver_cpus
        self.solver_memory = solver_memory
        self.solver_pids = solver_pids
        self.startup_timeout = startup_timeout
        self.name_prefix = name_prefix
        self.egress_mode = egress_mode
        self.holder_image = holder_image
        self.holder_cpus = holder_cpus
        self.holder_memory = holder_memory
        self.holder_pids = holder_pids
        self.defer_egress = defer_egress
        self._flag_factory = flag_factory
        self._instance = None

    def start(self) -> dict:
        if self._instance is not None:
            result = self.stop()
            if not result.get("ok"):
                raise ContainerError(
                    "previous instance cleanup did not complete; refusing "
                    "to start a second instance")

        def hold_provisional(instance):
            # Retain provisional ownership even if start() raises, so the
            # outer stop() can expose and retry cleanup instead of returning
            # a clean result with resources still on the engine.
            self._instance = instance

        instance = ContainerInstance.start(
            self.engine, self.target_image, self.solver_image,
            probe_image=self.probe_image, platform=self.platform,
            target_user=self.target_user, solver_user=self.solver_user,
            target_cpus=self.target_cpus, target_memory=self.target_memory,
            target_pids=self.target_pids, solver_cpus=self.solver_cpus,
            solver_memory=self.solver_memory, solver_pids=self.solver_pids,
            startup_timeout=self.startup_timeout,
            name_prefix=self.name_prefix, flag_factory=self._flag_factory,
            egress_mode=self.egress_mode,
            holder_image=self.holder_image,
            holder_cpus=self.holder_cpus,
            holder_memory=self.holder_memory,
            holder_pids=self.holder_pids,
            defer_egress=self.defer_egress,
            on_provisional=hold_provisional)
        self._instance = instance
        self._instance._solver_argv = self.solver_argv
        return self._instance.public_metadata()

    def reset(self) -> dict:
        result = self.stop()
        if not result.get("ok"):
            raise ContainerError(
                "reset refused: previous instance cleanup did not complete")
        return self.start()

    def stop(self) -> dict:
        instance = self._instance
        if instance is None:
            return {"ok": True, "errors": []}
        try:
            result = instance.stop()
        except (subprocess.SubprocessError, OSError,
                ContainerError, ShutdownRequested) as exc:
            result = {"ok": False,
                      "errors": [{"role": "controller",
                                  "error": safe_error_text(exc)}]}
        # Retain the instance on failure so ownership metadata allows another
        # cleanup attempt if the engine recovers.
        if result.get("ok"):
            self._instance = None
        return result

    def evaluate(self, timeout_s: float) -> dict:
        if self._instance is None:
            raise ContainerError("no active instance")
        return self._instance.evaluate(timeout_s)

    def boundary_check(self, timeout_s: float = 60.0) -> dict:
        if self._instance is None:
            raise ContainerError("no active instance")
        return self._instance.boundary_check(timeout_s)

    def current_metadata(self) -> dict:
        if self._instance is None:
            raise ContainerError("no active instance")
        return self._instance.public_metadata()

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, *exc):
        self.stop()


def write_report(report: dict, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report, indent=2) + "\n")
    print(f"container-controller: {report['status']} -> {path}")


def safe_error_text(exc: BaseException) -> str:
    """Publicly safe error text: no command line or captured output."""
    if isinstance(exc, subprocess.TimeoutExpired):
        if exc.timeout is None:
            return "engine operation timed out"
        return f"engine operation timed out after {exc.timeout}s"
    if isinstance(exc, subprocess.CalledProcessError):
        return f"engine operation failed with exit code {exc.returncode}"
    # Never propagate an unbounded exception string or a flag-shaped value
    # into stderr/reports.  Engine stdout/stderr is intentionally absent from
    # ContainerError messages, and this is a final public-output guard.
    return _bounded_policy_diagnostic(str(exc), None, limit=512)["text"]


def _signal_handler(signum, frame):
    raise ShutdownRequested(f"signal {signum}")


def main() -> int:
    parser = argparse.ArgumentParser(
        description=__doc__,
        epilog="Exit codes: 0 passed, 1 failed, 2 skipped, 3 partial.")
    parser.add_argument("--engine",
                        help="container engine path/name (docker, podman)")
    parser.add_argument("--target-image", required=True,
                        help="prebuilt target runtime image reference")
    parser.add_argument("--solver-image", required=True,
                        help="prebuilt solver image reference")
    parser.add_argument("--probe-image",
                        help="trusted probe image with python3 (default: "
                             "the target image)")
    parser.add_argument("--egress-mode", choices=EGRESS_MODES,
                        default="strict",
                        help="strict (default, formal) or legacy (explicit "
                             "development mode; reports are non-accepting)")
    parser.add_argument("--holder-image",
                        help="explicit trusted prebuilt image for the strict "
                             "network holder; required in strict mode")
    parser.add_argument("--holder-cpus", type=float, default=0.5)
    parser.add_argument("--holder-memory", default="128m")
    parser.add_argument("--holder-pids", type=int, default=32)
    parser.add_argument("--solver-json",
                        help="explicit solver argv as a JSON array; the "
                             "target endpoint is appended as the final "
                             "argument")
    parser.add_argument("--timeout", type=float, default=30.0,
                        help="strict solver wall-clock seconds")
    parser.add_argument("--boundary-check", action="store_true",
                        help="run the real-engine boundary probes instead of "
                             "a solve attempt")
    parser.add_argument("--boundary-timeout", type=float, default=120.0)
    parser.add_argument("--reset-before-solve", action="store_true")
    parser.add_argument("--platform", default="linux/amd64")
    parser.add_argument("--target-user", default="10001:10001")
    parser.add_argument("--solver-user", default="10001:10001")
    parser.add_argument("--target-cpus", type=float, default=2.0)
    parser.add_argument("--target-memory", default="2g")
    parser.add_argument("--target-pids", type=int, default=64)
    parser.add_argument("--solver-cpus", type=float, default=1.0)
    parser.add_argument("--solver-memory", default="1g")
    parser.add_argument("--solver-pids", type=int, default=128)
    parser.add_argument("--startup-timeout", type=float, default=20.0)
    parser.add_argument("--name-prefix", default="qjs-ctf")
    parser.add_argument("--report", default=str(DEFAULT_REPORT))
    args = parser.parse_args()

    if args.platform != "linux/amd64":
        parser.error("this controller only accepts --platform linux/amd64")
    if args.timeout <= 0:
        parser.error("--timeout must be positive")
    if not _is_nonroot(args.target_user):
        parser.error("--target-user must be non-root")
    if not _is_nonroot(args.solver_user):
        parser.error("--solver-user must be non-root")
    if args.target_cpus <= 0 or args.solver_cpus <= 0:
        parser.error("CPU limits must be positive")
    if args.target_pids < 1 or args.solver_pids < 1:
        parser.error("PID limits must be >= 1")
    if args.holder_cpus <= 0:
        parser.error("--holder-cpus must be positive")
    if args.holder_pids < 1:
        parser.error("--holder-pids must be >= 1")
    if args.egress_mode == "strict" and not args.holder_image:
        parser.error("--holder-image is required for strict egress")
    solver_argv = None
    if args.boundary_check:
        if args.solver_json:
            try:
                solver_argv = parse_solver_json(args.solver_json)
            except ContainerError as exc:
                parser.error(str(exc))
    else:
        if not args.solver_json:
            parser.error("--solver-json is required unless --boundary-check")
        try:
            solver_argv = parse_solver_json(args.solver_json)
        except ContainerError as exc:
            parser.error(str(exc))

    report = {
        "schema_version": 1,
        "kind": "qjs-ctf-container-evaluation",
        "started_at_utc": utc_now(),
        "status": "running",
        "host": {
            "platform": host_platform.system(),
            "release": host_platform.release(),
            "machine": host_platform.machine(),
        },
        "scope": "controlled CTF evaluation boundary; containers share the "
                 "host kernel and this is not proof of resistance to kernel "
                 "escape",
        "requested": {
            "target_image": args.target_image,
            "solver_image": args.solver_image,
            "probe_image": args.probe_image or args.target_image,
            "platform": args.platform,
            "target_limits": {
                "cpus": args.target_cpus, "memory": args.target_memory,
                "pids_limit": args.target_pids},
            "solver_limits": {
                "cpus": args.solver_cpus, "memory": args.solver_memory,
                "pids_limit": args.solver_pids},
            "solver_argv_length": len(solver_argv or []),
            "egress_mode": args.egress_mode,
            "strict_egress": args.egress_mode == "strict",
            "holder_image": args.holder_image,
            "holder_limits": {
                "cpus": args.holder_cpus, "memory": args.holder_memory,
                "pids_limit": args.holder_pids},
            "target_endpoint_argument": (
                "<target-ipv4>:8000" if args.egress_mode == "strict"
                else TARGET_ENDPOINT),
        },
        "engine": None,
        "instance": None,
        "solver": None,
        "boundary": {
            "status": "not-run",
            "reason": "Run with --boundary-check on a Docker-capable host.",
            "filesystem_pid_separation": {"status": "not-run"},
            "endpoint_only_egress": {
                "status": (
                    "not-run" if args.egress_mode == "strict"
                    else "not-accepted-legacy"),
                "reason": (
                    "Strict policy must be installed and read back before the "
                    "boundary can pass."
                    if args.egress_mode == "strict" else
                    "Legacy mode installs no strict egress policy."),
            },
            "isolation_gate": {
                "status": (
                    "not-run" if args.egress_mode == "strict"
                    else "not-accepted-legacy"),
                "reason": (
                    "Run the boundary check in strict mode on a Linux "
                    "controller with legacy iptables/ip6tables and nsenter."
                    if args.egress_mode == "strict" else
                    "Legacy mode is non-accepting."),
            },
        },
        "cleanup": None,
        "challenge_solvability": {
            "status": "pending",
            "reason": "Phase 3A adds no challenge variant and no reference "
                      "solution. A solver verdict only describes the "
                      "operator-supplied command.",
        },
        "limitations": [
            "Target and solver containers share the host kernel; kernel "
            "escape is out of scope for this boundary.",
            "An internal Docker bridge alone is not proof of endpoint-only "
            "egress. Legacy mode is non-accepting; strict mode requires an "
            "installed, read-back and exercised legacy iptables/ip6tables policy.",
            "The solver is operator-supplied code. This controller bounds "
            "its argv/env/mounts/runtime but does not audit its logic.",
        ],
    }
    report_path = Path(args.report)

    engine_path, diagnostics = find_engine(args.engine)
    if not engine_path:
        report["status"] = "skipped"
        report["finished_at_utc"] = utc_now()
        report["engine"] = {"path": None, "diagnostics": diagnostics}
        report["limitations"].append(
            "No container engine was available; nothing was run.")
        write_report(report, report_path)
        print("container-controller: no container engine available; "
              "nothing was run", file=sys.stderr)
        return 2

    engine = Engine(engine_path)
    report["engine"] = {"path": engine_path, "version": engine.version(),
                        "diagnostics": diagnostics}
    evaluator = ContainerEvaluator(
        engine, args.target_image, args.solver_image, solver_argv,
        probe_image=args.probe_image, platform=args.platform,
        target_user=args.target_user, solver_user=args.solver_user,
        target_cpus=args.target_cpus, target_memory=args.target_memory,
        target_pids=args.target_pids, solver_cpus=args.solver_cpus,
        solver_memory=args.solver_memory, solver_pids=args.solver_pids,
        startup_timeout=args.startup_timeout, name_prefix=args.name_prefix,
        egress_mode=args.egress_mode, holder_image=args.holder_image,
        holder_cpus=args.holder_cpus, holder_memory=args.holder_memory,
        holder_pids=args.holder_pids,
        defer_egress=(
            args.boundary_check and args.egress_mode == "strict"))

    old_int = signal.signal(signal.SIGINT, _signal_handler)
    old_term = signal.signal(signal.SIGTERM, _signal_handler)
    try:
        metadata = evaluator.start()
        report["instance"] = metadata
        if args.reset_before_solve and not args.boundary_check:
            metadata = evaluator.reset()
            report["instance"] = metadata
            report["reset"] = {"performed": True,
                               "fresh_flag_per_instance": True}
        if args.boundary_check:
            boundary = evaluator.boundary_check(args.boundary_timeout)
            report["boundary"] = boundary
            report["status"] = boundary["status"]
        else:
            verdict = evaluator.evaluate(args.timeout)
            report["solver"] = verdict
            report["status"] = "passed" if verdict["ok"] else "failed"
    except (ContainerError, subprocess.SubprocessError, OSError,
            ValueError, ShutdownRequested) as exc:
        report["status"] = "failed"
        if args.boundary_check:
            # A thrown boundary operation is an attempted and failed check,
            # not the untouched "not-run" default.  Keep the public boundary
            # reason generic; engine stdout/stderr and private argv never
            # become part of this result.
            report["boundary"]["status"] = "failed"
            report["boundary"]["reason"] = (
                "The boundary check raised before producing a complete "
                "accepted result.")
            report["boundary"]["endpoint_only_egress"] = {
                "status": "failed",
                "reason": "Endpoint-only egress was not proven.",
            }
            report["boundary"]["isolation_gate"] = {
                "status": "pending",
                "reason": "Full isolation was not proven.",
            }
        report["error"] = safe_error_text(exc)
        print(f"container-controller: {safe_error_text(exc)}",
              file=sys.stderr)
    finally:
        owned_instance = evaluator._instance
        try:
            cleanup = evaluator.stop()
        except (ContainerError, subprocess.SubprocessError, OSError,
                ShutdownRequested) as exc:
            cleanup = {"ok": False,
                       "errors": [{"role": "controller",
                                   "error": safe_error_text(exc)}]}
        report["cleanup"] = cleanup
        # Refresh after cleanup so a failed strict-policy attempt retains its
        # per-family diagnostics while active ownership state reflects the
        # completed teardown.  Public metadata never includes the flag value.
        if owned_instance is not None:
            try:
                report["instance"] = owned_instance.public_metadata()
            except (ContainerError, OSError, ValueError):
                pass
        # Public engine-call records are metadata-only; solver argv can
        # contain private inline code or operator arguments.
        report["engine_calls"] = public_engine_calls(engine.calls)
        report["finished_at_utc"] = utc_now()
        signal.signal(signal.SIGINT, old_int)
        signal.signal(signal.SIGTERM, old_term)

    if not (report.get("cleanup") or {}).get("ok", False):
        report["status"] = "failed"
    write_report(report, report_path)
    if report["status"] == "passed":
        return 0
    if report["status"] == "partial":
        return 3
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
