# QuickJS source provenance

- Upstream project: QuickJS by Fabrice Bellard
- Pinned release: **2026-06-04**
- Upstream URL: <https://bellard.org/quickjs/quickjs-2026-06-04.tar.xz>
- Retrieved: 2026-11-01 (UTC) from `bellard.org` over HTTPS
- Archive: `quickjs-2026-06-04.tar.xz`
- Archive size: **621500 bytes**
- Archive SHA-256: `b376e839b322978313d929fd20663b11ba58b75df5a46c126dd19ea2fa70ad2a`
- Extracted tree: `third_party/quickjs/src/`
- Upstream `VERSION` after extraction: `2026-06-04`
- License: MIT-style QuickJS license, retained verbatim at
  `third_party/quickjs/src/LICENSE`

## Pin policy

The archive is vendored so builds do not follow a moving branch or mirror.
Verification is reproducible:

```sh
python3 scripts/verify_pin.py
# or
cd third_party/quickjs && shasum -a 256 -c SHA256SUMS
```

`scripts/verify_pin.py` checks the archive size and SHA-256, the
`SHA256SUMS` entry, the extracted `VERSION`, the upstream license text, and the
presence of the engine sources compiled by this project.

## Extraction command

```sh
mkdir -p third_party/quickjs/src
tar -xJf third_party/quickjs/quickjs-2026-06-04.tar.xz \
    -C third_party/quickjs/src --strip-components=1
```

No patches are applied to upstream source in Phase 1.
