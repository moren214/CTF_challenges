/*
 * qjs_runner.c - minimal source-only QuickJS embedding.
 *
 * This process is driven by adapter/server.py over stdin/stdout using a
 * bounded binary protocol.  It deliberately does not link quickjs-libc.c,
 * so there is no std/os module, module loader, file API, subprocess API,
 * CLI helper, or bytecode loader.
 *
 * Request  (adapter -> runner): uint32_be length, then `length` UTF-8 bytes
 *                               of JavaScript source.
 * Response (runner -> adapter): status byte, uint32_be length, payload bytes.
 *   'O' payload is the JSON serialization of the script completion value.
 *   'E' payload is a JSON object: {name, message, stack}.
 *   'L' payload is a JSON limit error.  Source-too-large is fatal because the
 *       unread request body would desynchronize the stream; output-too-large
 *       is non-fatal.
 *   'F' payload is a fatal internal error; the process exits after sending it.
 *
 * The runtime is persistent for the lifetime of this process.  Ordinary JS
 * exceptions are caught, reported, and do not destroy the context.
 */

#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "quickjs.h"

#define MAX_SOURCE_BYTES (64u * 1024u)
#define MAX_OUTPUT_BYTES (1024u * 1024u)
#define MEMORY_LIMIT_BYTES (64u * 1024u * 1024u)
#define STACK_LIMIT_BYTES (1024u * 1024u)

#define STATUS_RESULT 'O'
#define STATUS_EXCEPTION 'E'
#define STATUS_LIMIT 'L'
#define STATUS_FATAL 'F'

static const char ERR_INPUT_LIMIT[] =
    "{\"name\":\"InputLimitError\",\"message\":\"source exceeds 65536 bytes\"}";
static const char ERR_OUTPUT_LIMIT[] =
    "{\"name\":\"OutputLimitError\",\"message\":\"serialized output exceeds 1048576 bytes\"}";
static const char ERR_INTERNAL[] =
    "{\"name\":\"InternalError\",\"message\":\"runner internal error\"}";
static const char ERR_EXCEPTION_FALLBACK[] =
    "{\"name\":\"Error\",\"message\":\"exception could not be serialized\"}";

/*
 * Captured intrinsics and the result/error serializers live in this closure.
 * The returned object is retained as a JSValue, not published on globalThis,
 * so user scripts cannot reach or replace the helpers (short of corrupting the
 * engine itself).  Scripts may still mutate captured prototypes/intrinsics;
 * that is visible through ordinary JS semantics and is not defended against.
 */
static const char BOOTSTRAP_JS[] =
    "(function () {\n"
    "  var stringify = JSON.stringify;\n"
    "  var isView = ArrayBuffer.isView;\n"
    "  var isArray = Array.isArray;\n"
    "  var keys = Object.keys;\n"
    "  var create = Object.create;\n"
    "  var objToString = Object.prototype.toString;\n"
    "  var StringCtor = String;\n"
    "  var ErrorCtor = Error;\n"
    "  var slice = String.prototype.slice;\n"
    "  function truncate(v) {\n"
    "    var s = StringCtor(v);\n"
    "    return s.length > 8192 ? slice.call(s, 0, 8192) + '...truncated' : s;\n"
    "  }\n"
    "  var MAX_DEPTH = 12;\n"
    "\n"
    "  function contains(list, v) {\n"
    "    for (var i = 0; i < list.length; i++) if (list[i] === v) return true;\n"
    "    return false;\n"
    "  }\n"
    "\n"
    "  function encode(v, depth, seen) {\n"
    "    var t = typeof v;\n"
    "    if (v === undefined) return { '$type': 'undefined' };\n"
    "    if (v === null) return null;\n"
    "    if (t === 'number') {\n"
    "      if (v !== v) return { '$type': 'number', value: 'NaN' };\n"
    "      if (v === Infinity) return { '$type': 'number', value: 'Infinity' };\n"
    "      if (v === -Infinity) return { '$type': 'number', value: '-Infinity' };\n"
    "      return v;\n"
    "    }\n"
    "    if (t === 'string' || t === 'boolean') return v;\n"
    "    if (t === 'bigint') return { '$type': 'bigint', value: StringCtor(v) };\n"
    "    if (t === 'symbol') return { '$type': 'symbol', value: StringCtor(v) };\n"
    "    if (t === 'function') return { '$type': 'function', name: v.name || '' };\n"
    "    if (depth > MAX_DEPTH) return { '$type': 'depth-limit' };\n"
    "    if (contains(seen, v)) return { '$type': 'cycle' };\n"
    "    seen[seen.length] = v;\n"
    "    try {\n"
    "      if (v instanceof ErrorCtor) {\n"
    "        return { '$type': 'Error', name: StringCtor(v.name),\n"
    "                 message: StringCtor(v.message),\n"
    "                 stack: v.stack === undefined ? '' : truncate(v.stack) };\n"
    "      }\n"
    "      if (isView(v)) {\n"
    "        var viewName = objToString.call(v).slice(8, -1);\n"
    "        var viewData = [];\n"
    "        for (var vi = 0; vi < v.length; vi++) {\n"
    "          viewData[viewData.length] = encode(v[vi], depth + 1, seen);\n"
    "        }\n"
    "        return { '$type': viewName, length: v.length, data: viewData };\n"
    "      }\n"
    "      if (isArray(v)) {\n"
    "        var arr = [];\n"
    "        for (var ai = 0; ai < v.length; ai++) {\n"
    "          arr[arr.length] = encode(v[ai], depth + 1, seen);\n"
    "        }\n"
    "        return arr;\n"
    "      }\n"
    "      if (objToString.call(v) === '[object Date]') {\n"
    "        var time = v.getTime();\n"
    "        return { '$type': 'Date', value: time !== time ? null : v.toISOString() };\n"
    "      }\n"
    "      var out = create(null);\n"
    "      var ks = keys(v);\n"
    "      for (var ki = 0; ki < ks.length; ki++) {\n"
    "        try {\n"
    "          out[ks[ki]] = encode(v[ks[ki]], depth + 1, seen);\n"
    "        } catch (pe) {\n"
    "          out[ks[ki]] = { '$type': 'property-error',\n"
    "                          message: StringCtor(pe && pe.message ? pe.message : pe) };\n"
    "        }\n"
    "      }\n"
    "      return out;\n"
    "    } finally {\n"
    "      seen.length = seen.length - 1;\n"
    "    }\n"
    "  }\n"
    "\n"
    "  function result(v) {\n"
    "    try {\n"
    "      return stringify(encode(v, 0, []));\n"
    "    } catch (e) {\n"
    "      return stringify({ '$type': 'serialization-error',\n"
    "                         message: StringCtor(e && e.message ? e.message : e) });\n"
    "    }\n"
    "  }\n"
    "\n"
    "  function error(e) {\n"
    "    try {\n"
    "      if (e && (typeof e === 'object' || typeof e === 'function')) {\n"
    "        return stringify({\n"
    "          name: e.name === undefined ? 'Error' : StringCtor(e.name),\n"
    "          message: e.message === undefined ? StringCtor(e) : StringCtor(e.message),\n"
    "          stack: e.stack === undefined ? '' : truncate(e.stack)\n"
    "        });\n"
    "      }\n"
    "      return stringify({ name: 'ThrownValue', message: StringCtor(e), stack: '' });\n"
    "    } catch (e2) {\n"
    "      return '{\"name\":\"UnserializableError\",\"message\":\"exception could not be serialized\"}';\n"
    "    }\n"
    "  }\n"
    "\n"
    "  return { result: result, error: error };\n"
    "})()\n";

static int write_all(int fd, const void *buf, size_t len)
{
    const char *p = (const char *)buf;
    while (len > 0) {
        ssize_t n = write(fd, p, len);
        if (n < 0) {
            if (errno == EINTR)
                continue;
            return -1;
        }
        if (n == 0)
            return -1;
        p += n;
        len -= (size_t)n;
    }
    return 0;
}

/* Returns 1 on success, 0 on clean EOF before any byte, -1 on error/partial. */
static int read_all(int fd, void *buf, size_t len)
{
    char *p = (char *)buf;
    size_t off = 0;
    while (off < len) {
        ssize_t n = read(fd, p + off, len - off);
        if (n < 0) {
            if (errno == EINTR)
                continue;
            return -1;
        }
        if (n == 0)
            return off == 0 ? 0 : -1;
        off += (size_t)n;
    }
    return 1;
}

static int send_frame(int fd, char status, const char *payload, size_t len)
{
    uint8_t header[5];
    header[0] = (uint8_t)status;
    header[1] = (uint8_t)(len >> 24);
    header[2] = (uint8_t)(len >> 16);
    header[3] = (uint8_t)(len >> 8);
    header[4] = (uint8_t)len;
    if (write_all(fd, header, sizeof(header)) < 0)
        return -1;
    if (len > 0 && write_all(fd, payload, len) < 0)
        return -1;
    return 0;
}

static int send_static(int fd, char status, const char *payload)
{
    return send_frame(fd, status, payload, strlen(payload));
}

/* Copy a JS string value into a malloc'd, NUL-terminated UTF-8 buffer. */
static char *js_string_copy(JSContext *ctx, JSValueConst value, size_t *len_out)
{
    size_t len;
    const char *s = JS_ToCStringLen(ctx, &len, value);
    char *copy;
    if (!s)
        return NULL;
    copy = (char *)malloc(len + 1);
    if (!copy) {
        JS_FreeCString(ctx, s);
        JS_ThrowOutOfMemory(ctx);
        return NULL;
    }
    memcpy(copy, s, len);
    copy[len] = '\0';
    JS_FreeCString(ctx, s);
    *len_out = len;
    return copy;
}

/*
 * Serialize the pending exception with the JS error serializer.  The exception
 * itself has already been retrieved with JS_GetException() and must be freed by
 * the caller.  Always sends a frame.
 */
static int send_js_exception(JSContext *ctx, JSValueConst error_serializer,
                             JSValueConst exception)
{
    JSValue serialized;
    JSValueConst args[1];
    size_t len;
    char *payload;

    args[0] = exception;
    serialized = JS_Call(ctx, error_serializer, JS_UNDEFINED, 1, args);
    if (JS_IsException(serialized)) {
        JS_FreeValue(ctx, JS_GetException(ctx));
        JS_FreeValue(ctx, serialized);
        return send_static(STDOUT_FILENO, STATUS_EXCEPTION,
                           ERR_EXCEPTION_FALLBACK);
    }
    payload = js_string_copy(ctx, serialized, &len);
    JS_FreeValue(ctx, serialized);
    if (!payload) {
        JS_FreeValue(ctx, JS_GetException(ctx));
        return send_static(STDOUT_FILENO, STATUS_EXCEPTION,
                           ERR_EXCEPTION_FALLBACK);
    }
    if (len > MAX_OUTPUT_BYTES) {
        free(payload);
        return send_static(STDOUT_FILENO, STATUS_LIMIT, ERR_OUTPUT_LIMIT);
    }
    if (send_frame(STDOUT_FILENO, STATUS_EXCEPTION, payload, len) < 0) {
        free(payload);
        return -1;
    }
    free(payload);
    return 0;
}

int main(void)
{
    JSRuntime *rt;
    JSContext *ctx;
    JSValue bootstrap;
    JSValue result_serializer;
    JSValue error_serializer;
    const char *flag;
    int rc = 0;

    /* OS-level placeholder flag: presence is reported without the value.
       No JS API exposes the environment or this variable. */
    flag = getenv("QJS_CTF_FLAG");
    fprintf(stderr,
            "qjs-runner: instance flag %s (OS-level only; not exposed to JavaScript)\n",
            (flag && flag[0]) ? "present" : "absent");

    rt = JS_NewRuntime();
    if (!rt) {
        fprintf(stderr, "qjs-runner: JS_NewRuntime failed\n");
        return 1;
    }
    JS_SetMemoryLimit(rt, MEMORY_LIMIT_BYTES);
    JS_SetMaxStackSize(rt, STACK_LIMIT_BYTES);

    ctx = JS_NewContext(rt);
    if (!ctx) {
        fprintf(stderr, "qjs-runner: JS_NewContext failed\n");
        JS_FreeRuntime(rt);
        return 1;
    }

    bootstrap = JS_Eval(ctx, BOOTSTRAP_JS, sizeof(BOOTSTRAP_JS) - 1,
                        "<bootstrap>", JS_EVAL_TYPE_GLOBAL);
    if (JS_IsException(bootstrap)) {
        JSValue ex = JS_GetException(ctx);
        const char *s = JS_ToCString(ctx, ex);
        fprintf(stderr, "qjs-runner: bootstrap failed: %s\n",
                s ? s : "(unprintable)");
        if (s)
            JS_FreeCString(ctx, s);
        JS_FreeValue(ctx, ex);
        JS_FreeValue(ctx, bootstrap);
        JS_FreeContext(ctx);
        JS_FreeRuntime(rt);
        return 1;
    }
    result_serializer = JS_GetPropertyStr(ctx, bootstrap, "result");
    error_serializer = JS_GetPropertyStr(ctx, bootstrap, "error");
    JS_FreeValue(ctx, bootstrap);
    if (JS_IsException(result_serializer) || JS_IsException(error_serializer) ||
        !JS_IsFunction(ctx, result_serializer) ||
        !JS_IsFunction(ctx, error_serializer)) {
        fprintf(stderr, "qjs-runner: bootstrap serializers unavailable\n");
        rc = 1;
        goto done;
    }

    for (;;) {
        uint8_t header[4];
        uint32_t source_len;
        char *source = NULL;
        JSValue completion;
        JSValue serialized;
        JSValueConst call_args[1];
        size_t payload_len;
        char *payload;
        int n;

        n = read_all(STDIN_FILENO, header, sizeof(header));
        if (n == 0)
            break; /* clean adapter shutdown */
        if (n < 0) {
            send_static(STDOUT_FILENO, STATUS_FATAL, ERR_INTERNAL);
            rc = 1;
            break;
        }
        source_len = ((uint32_t)header[0] << 24) |
                     ((uint32_t)header[1] << 16) |
                     ((uint32_t)header[2] << 8) |
                     (uint32_t)header[3];
        if (source_len > MAX_SOURCE_BYTES) {
            /* The stream cannot be resynchronized safely without reading the
               rejected body, so this is fatal for the worker. */
            send_static(STDOUT_FILENO, STATUS_LIMIT, ERR_INPUT_LIMIT);
            rc = 0;
            break;
        }
        /* QuickJS may inspect one byte past input_len in some parser
           states; keep an explicit NUL sentinel. */
        source = (char *)malloc((size_t)source_len + 1);
        if (!source) {
            send_static(STDOUT_FILENO, STATUS_FATAL, ERR_INTERNAL);
            rc = 1;
            break;
        }
        if (source_len > 0) {
            n = read_all(STDIN_FILENO, source, source_len);
            if (n <= 0) {
                free(source);
                send_static(STDOUT_FILENO, STATUS_FATAL, ERR_INTERNAL);
                rc = 1;
                break;
            }
        }
        source[source_len] = '\0';

        completion = JS_Eval(ctx, source, source_len, "<eval>",
                             JS_EVAL_TYPE_GLOBAL);
        free(source);
        if (JS_IsException(completion)) {
            JSValue ex = JS_GetException(ctx);
            if (send_js_exception(ctx, error_serializer, ex) < 0) {
                JS_FreeValue(ctx, ex);
                JS_FreeValue(ctx, completion);
                rc = 1;
                break;
            }
            JS_FreeValue(ctx, ex);
            JS_FreeValue(ctx, completion);
            continue;
        }

        call_args[0] = completion;
        serialized = JS_Call(ctx, result_serializer, JS_UNDEFINED, 1,
                             call_args);
        JS_FreeValue(ctx, completion);
        if (JS_IsException(serialized)) {
            JSValue ex = JS_GetException(ctx);
            if (send_js_exception(ctx, error_serializer, ex) < 0) {
                JS_FreeValue(ctx, ex);
                JS_FreeValue(ctx, serialized);
                rc = 1;
                break;
            }
            JS_FreeValue(ctx, ex);
            JS_FreeValue(ctx, serialized);
            continue;
        }
        payload = js_string_copy(ctx, serialized, &payload_len);
        JS_FreeValue(ctx, serialized);
        if (!payload) {
            JSValue ex = JS_GetException(ctx);
            send_js_exception(ctx, error_serializer, ex);
            JS_FreeValue(ctx, ex);
            continue;
        }
        if (payload_len > MAX_OUTPUT_BYTES) {
            free(payload);
            if (send_static(STDOUT_FILENO, STATUS_LIMIT,
                            ERR_OUTPUT_LIMIT) < 0) {
                rc = 1;
                break;
            }
            continue;
        }
        if (send_frame(STDOUT_FILENO, STATUS_RESULT, payload,
                       payload_len) < 0) {
            free(payload);
            rc = 1;
            break;
        }
        free(payload);
    }

done:
    JS_FreeValue(ctx, result_serializer);
    JS_FreeValue(ctx, error_serializer);
    JS_FreeContext(ctx);
    JS_FreeRuntime(rt);
    return rc;
}
