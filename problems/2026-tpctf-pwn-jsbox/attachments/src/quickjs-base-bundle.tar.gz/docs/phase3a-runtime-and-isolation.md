# Phase 3A: runtime image and container-separated evaluation

Status: runtime-image verification and the container-separated evaluator are
implemented. The observed Linux 6.1.147 x86-64 / Docker 28.5.2 platform does
not support nftables or the iptables-nft Netlink path, so strict egress now
uses the explicit legacy binaries `iptables-legacy-restore` /
`iptables-legacy-save` and `ip6tables-legacy-restore` /
`ip6tables-legacy-save` inside a held holder network namespace. The native
test suite covers this implementation; **it does not claim a passing real
Docker boundary**. The first frozen strict-backend run passed its non-root
215-test image suite, then failed closed during policy installation before any
untrusted solver started. Independent review added fail-closed gate checks,
trusted-helper separation, exact solver-configuration allowlists and bounded,
redacted per-family install/readback diagnostics; the current native suite
passes 238/238. A fresh frozen revision must be rerun on the Docker host.

The historical failed boundary result remains preserved at
`reports/phase3a-boundary-real.json`; it predates the legacy backend.
The first strict-backend failure is preserved at
`reports/phase3a-egress3-boundary-first.json`.

Both containers share the host kernel. This is a controlled CTF evaluation
boundary, not proof of resistance to kernel escape or a formal multi-tenant
security proof.

## Package A: real runtime-image verification

Entry point: `scripts/verify_runtime.py` (Python standard library only).

It builds the Dockerfile `runtime` stage, records the actual local image
identity and RepoDigests, enforces the amd64 architecture, inspects the image
user/command/environment, scans `/app` and `/run/secrets` for flag-like content,
starts the image with a synthetic flag supplied only through a read-only file
mount, and probes the real TCP service.

The runtime container is started with no published port and `--network none`.
The service is reached through `docker exec` over the container's own loopback,
so normal replies and logs can be checked without exposing the endpoint.

Checks performed against the real image:

- health reply `1+1` equals `2`;
- arithmetic and persistent state on one connection;
- a second connection starts with fresh state;
- a JavaScript exception is recoverable;
- ordinary host APIs (`require`, `process`, `std`, `os`, `fs`, `fetch`,
  `XMLHttpRequest`, `importScripts`) are absent;
- the synthetic flag does not appear in normal replies or container logs; a
  failed `docker logs` read is recorded as unverified and fails acceptance,
  because an unread log cannot prove non-disclosure;
- the process uid is not 0 and CPU/memory/PID limits match the request;
- read-only root filesystem, dropped capabilities, no-new-privileges, no
  published ports, and a read-only flag mount;
- the image config has no entrypoint, no flag variable, no flag-like literal,
  and no image-declared `VOLUME` path;
- a missing flag file exits visibly with a flag-configuration error;
- owned containers and the temporary secret directory are removed on success,
  failure, timeout, or interruption. No global prune or kill is used.

The image's default `CMD` preserves the adapter's environment mode and omits
`--flag-file`; the verifier's explicit file-mode override adds
`--flag-file /run/secrets/qjs_ctf_flag` only when it starts the container. The
image-config check compares against the Dockerfile default, not that override.

Before scanning or starting any container, the verifier rejects an image that
declares `VOLUME` paths, because `--read-only` does not cover the writable
anonymous volumes Docker creates for them. Owned container removal uses
`docker rm -f -v`, which also removes anonymous volumes attached to those
containers as a fallback; no global volume prune is used. The filesystem scan
helper is uniquely named and labelled before it is created, and the report
records the scan bounds (`max_files`, `max_file_bytes`, `files_limit_reached`,
and skipped oversized files) rather than presenting a bounded scan as
exhaustive.

### Base image, offline build, and frontend

The Dockerfile no longer carries a `# syntax=` directive, so a build uses the
engine's built-in Dockerfile frontend and does not fetch a separate frontend
image. An operator can opt into an explicit pinned or mirrored frontend:

```sh
python3 scripts/verify_runtime.py --engine docker \
  --base-image ubuntu:24.04@sha256:<pinned-digest> \
  --frontend mirror.example/dockerfile@sha256:<pinned-digest> \
  --platform linux/amd64 --cpus 2 --memory 2g --pids-limit 64 \
  --report reports/verify-runtime-report.json
```

For a pre-provisioned base and an offline build, keep the base local and make
network use explicit:

```sh
python3 scripts/verify_runtime.py --engine docker \
  --base-image <local-base-reference> --skip-apt --build-network none \
  --platform linux/amd64 --cpus 2 --memory 2g --pids-limit 64 \
  --report reports/verify-runtime-report.json
```

To verify an already built local runtime image without building:

```sh
python3 scripts/verify_runtime.py --engine docker \
  --prebuilt-image qjs-ctf-baseline:<local-tag> \
  --platform linux/amd64 --cpus 2 --memory 2g --pids-limit 64 \
  --report reports/verify-runtime-report.json
```

A built image ID is a local identity, not a portable registry RepoDigest. The
report records the image ID, the RepoDigests the engine actually reports (which
may be empty), and a note that no registry digest was invented.

Exit codes: `0` passed, `1` failed, `2` skipped because no engine exists. A
skipped report is not runtime verification.

## Package B: separate target and solver containers

Entry point: `evaluator/container_controller.py`. The existing
`evaluator/controller.py` remains the same-user local development helper.

For each instance the trusted controller:

1. generates one fresh random flag;
2. creates a uniquely named internal bridge network with ownership labels;
3. starts the target container with the flag file mounted read-only, no
   published port, no host PID or network namespace, dropped capabilities,
   no-new-privileges, read-only root filesystem, private tmpfs, and explicit
   CPU/memory/PID limits;
4. in strict mode, starts a fixed trusted idle holder, resolves and pins its
   immutable image ID, holds its network namespace FD after identity and
   host-namespace-difference checks, and installs and reads back both IPv4 and
   IPv6 filter tables inside that namespace;
5. creates the solver in the holder namespace, exactly inspects its image/user/
   `SecurityOpt`/PID/IPC/tmpfs/mount/capability/device/resource configuration,
   performs a final complete live-egress revalidation, and only then starts it
   with no secret mount, flag variable, controller environment or Docker
   socket, and only the current numeric target IP:8000 appended to its argv
   (legacy mode uses `<target-alias>:8000` on the internal network instead);
6. health-checks the target through a trusted `docker exec` control action,
   judges exit 0 plus the exact flag as the only stdout content, rejects
   truncated output, and enforces a strict wall-clock timeout;
7. removes the solver and every helper before retiring policy state; the
   holder is removed to destroy the disposable namespace, then the target,
   networks and per-instance secret are removed. Cleanup is retried after an
   engine failure and a failed/unknown holder inspect never counts as absence.

Reset removes the old instance and creates a new target, network, and flag.
Cleanup uses exact owned names and ownership labels; it never runs a global
prune or kill. Ownership names for the target network, solver, probe, sentinel,
second network, and solver-config inspection container are recorded before each
create/start attempt, so a lost CLI response does not orphan a successful
create. A failed startup retains its provisional instance and cleanup outcome
for the outer stop/report, which retries owned resources and cannot report a
clean cleanup while they are present or unknown. A confirmed engine "not
found" is distinct from an unknown engine/permission/transport failure. Public
timeout summaries retain only the operation/error category: they never include
the engine command line, captured stdout, or stderr. Target and solver images
must already exist locally. Images are never downloaded implicitly.

At start, every image that may execute and the configured solver image are
rejected if they declare writable `VOLUME` paths, before any secret or
container is created. In strict boundary mode the operator-supplied probe image
does not execute; all helpers use the resolved immutable holder image ID. The
solver receives `--log-driver none` so the daemon cannot spool unbounded output
despite the client-side capture bound. Owned container removal uses `rm -f -v`
as the anonymous-volume fallback.

Strict mode additionally starts a fixed trusted idle holder container, holds
its network-namespace FD, enters only that network namespace with
`nsenter --net`, and installs a full IPv4 and IPv6 filter policy. Each family
restore is atomic; the two-family sequence is not atomic. Only the idle holder
exists in the namespace until both families have been installed and read back,
and any failed install, readback, identity or host-firewall check prevents the
solver from starting. Normal evaluation revalidates the complete live policy
after exact solver inspection and immediately before `start`. The policy
accepts only IPv4 TCP to the current numeric target at port 8000 and
established replies from that endpoint; it explicitly
defaults INPUT/OUTPUT/FORWARD to DROP and carries per-destination counters for
the target's other ports, the instance gateway, a second-network sentinel,
Docker DNS, loopback, generic UDP and the default drop. IPv6 accepts nothing
and carries explicit `::1` and configured-test-address counters.

The policy carries its instance ownership marker as a dedicated, empty,
never-referenced filter chain whose name is derived from the instance id.
The marker cannot change packet processing and does not require any kernel
match module. The earlier `-m comment` representation was removed because the
observed legacy backend kernel does not expose the `comment` match: exact
`iptables-legacy-restore --test` / `ip6tables-legacy-restore --test` runs
returned rc 2 with `Couldn't load match 'comment': No such file or directory`,
and `/proc/net/ip_tables_matches` listed no `comment` match. A chain
declaration is accepted by iptables-restore without loading a match module.

Strict boundary mode executes its sentinel and pre-/post-policy probes only
from the resolved immutable trusted-holder image ID. The solver and optional
probe references never start. The actual solver follows `create` -> exact
`inspect` -> `remove`; its evidence is configuration-only. Filesystem, secret,
PID and capability runtime observations come from the trusted holder probe and
are never presented as solver self-report. The formal gate requires both that
trusted runtime evidence and the exact actual-solver configuration audit. If
either part is missing, `isolation_gate` remains `pending` and only the
precisely proven egress property is reported.

### Evaluate an operator-supplied solver

```sh
python3 evaluator/container_controller.py --engine docker \
  --target-image qjs-ctf-baseline:<local-tag> \
  --solver-image <prebuilt-solver-image> \
  --solver-json '["/opt/solve"]' \
  --target-cpus 2 --target-memory 2g --target-pids 64 \
  --solver-cpus 1 --solver-memory 1g --solver-pids 128 \
  --timeout 30 \
  --report reports/container-evaluation-report.json
```

The solver image must contain everything the solver needs because its root
filesystem is read-only and its working directory is a private tmpfs at
`/tmp` mounted with `noexec`. Its files must be readable and executable by the
configured non-root user (default `10001:10001`). There is no built-in solver,
challenge variant, or target backdoor. The unmodified target plus a wrong
solver is expected to be rejected.

### Real-engine boundary check

```sh
python3 evaluator/container_controller.py --engine docker \
  --target-image qjs-ctf-baseline:<local-tag> \
  --solver-image <prebuilt-solver-image> \
  --holder-image <trusted-holder-image> \
  --egress-mode strict --boundary-check \
  --report reports/container-boundary-report.json
```

`--boundary-check` defers policy activation so the trusted pre-policy controls
run in the holder namespace before enforcement. The trusted holder image must
provide Python 3 for the probes. The configured solver and optional probe image
references are not executed by this command. The boundary command checks:

- target service, repeated sessions and an actual source request larger than
  20 KiB through the solver protocol;
- the IPv4 target allow and the established-reply INPUT rule;
- negative controls for the target's other port, the host gateway (TCP and
  UDP), a second owned internal network (TCP and UDP), Docker DNS (TCP and
  UDP), IPv4 and IPv6 loopback (TCP and UDP), a configured IPv6 test address,
  an IPv4-mapped IPv6 attempt, generic UDP and the default drop;
- live owned listeners with successful pre-policy controls and zero
  post-policy receives, plus increased kernel counters for each exercised
  deny path; on this platform an OUTPUT DROP of a locally generated UDP
  datagram can surface as `EPERM` from `sendto` instead of a silent drop.
  The strict UDP checks therefore accept either a successful send with zero
  receives or the `EPERM` rejection, while the pre-policy control must have
  been live, the owned receive counters must be unchanged, and each
  exercised per-path policy counter must have increased. A send error that is not the policy rejection, or a control that
  was not live before enforcement, still fails the boundary;
- separate PID and mount namespaces, and that the trusted probe network
  namespace is the held holder namespace;
- on the trusted holder probe, no flag file, flag environment variable,
  controller-environment sentinel or Docker socket; read-only rootfs; dropped
  capabilities; denied `unshare(CLONE_NEWNET)` and `setns`; no host PID/IPC/
  network namespace; no privileges; no published ports; limits;
- for the never-started actual solver container, exact immutable image and user
  identity, the sole allowed `SecurityOpt`, private PID/IPC, exact `/tmp` tmpfs,
  allowlisted effective mounts, no host binds/volumes, no added capabilities or
  devices, no secrets, Docker socket, ports or privilege, and exact limits;
- unchanged host firewall policy and absence of the instance rule marker from
  the host namespace;
- image identity of every trusted helper and the created solver container.

The second internal network is attached to the trusted holder before
enforcement (a documented test fixture). Its pre-policy positive control is
therefore genuinely reachable; after policy the same endpoint is denied. The
holder identity check accepts exactly that pre-registered extra network.
Unroutable IPv6 or mapped attempts are reported as not policy-proven, never as
a pass.

An internal Docker bridge alone is not proof of endpoint-only egress. Strict
mode reports `endpoint_only_egress` only when the legacy policy was installed
and read back for both families and every required control/counter check
passed. The formal `isolation_gate` is `passed` only when the trusted-holder
runtime evidence and the never-executed actual-solver configuration audit also
pass. Holder runtime evidence is not solver self-report. Otherwise the gate
remains `pending` (egress proven, full boundary not) or the boundary fails. Do
not present the formal gate as passed without the real-engine run.

Boundary status is `passed` when the full boundary passes, `partial` when only
the egress property is proven and full isolation remains pending, or `failed`
when a probe or cleanup check fails. Exit codes are `0` passed, `1` failed, `2`
skipped because no engine exists, and `3` partial. An exception after boundary
execution begins produces a structured failed boundary with endpoint-only
egress failed and the isolation gate pending; it is never left as `not-run`.

## Reports

- `reports/phase3a-runtime-skipped.json` records that runtime verification was
  skipped on this host because no engine exists. It is not runtime evidence.
- `reports/phase3a-container-skipped.json` records the same for container
  evaluation.
- Real-engine reports must be written by the commands above on the Docker host
  and kept separate from these skipped records.

Reports contain metadata, boolean verdicts, and at most 2048 bytes of
flag-redacted stderr for each legacy policy install/readback command. Policy
stdout is represented only by its byte length; install batches by SHA-256 and
rule count. Reports never contain the expected flag, a returned flag, raw
solver output, probe output, flag-file contents, arbitrary image environment
values, policy argv/batches, or unexpected image commands.
Retained engine output is redacted at capture, and the final runtime report is
redacted again before it is written. Boundary `engine_calls` records are
metadata-only (subcommand, argument count, return code, timeout flag); raw argv
is never exported, so private inline solver code or operator arguments do not
appear in the public boundary report. Runtime verification, boundary
configuration/probes, and challenge solvability are separate report sections.
Phase 3A does not implement a challenge variant or reference solution, so
challenge solvability remains pending.

The first strict-backend install cause was confirmed to be the unavailable
`comment` match module. Exact-batch diagnostic runs on the disposable offline
Docker UVM reported `Couldn't load match 'comment': No such file or directory`
for both `iptables-legacy-restore --test` and `ip6tables-legacy-restore
--test`; the kernel match list contained `conntrack`, `icmp`, `addrtype`,
`udplite`, `udp` and `tcp` but no `comment`. The policy marker is therefore a
dedicated chain name instead of a comment match. Any future policy change must
keep this diagnostic reproducible rather than reintroducing a match module
that the platform does not provide.

## Pending operator actions

1. Preserve the already-passed runtime-image report; rerun the current frozen
   verification revision on the Docker-capable host.
2. Capture exact legacy-restore `--test` diagnostics, then run the strict
   boundary check with the real target and trusted holder images plus the
   never-started solver configuration audit; archive the pass/partial/failed
   result. Uploading the revised project and creating a new temporary UVM
   require explicit authorization in the current chat.
3. Run an operator-supplied solver (including a known-wrong solver) and keep
   the real-engine verdict separate from the unit tests.
4. If the real-engine boundary does not prove the full boundary, keep the
   formal isolation gate `pending` and report only the proven egress property.
