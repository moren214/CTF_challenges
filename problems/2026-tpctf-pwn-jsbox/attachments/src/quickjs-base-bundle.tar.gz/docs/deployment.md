# Deployment and verification

## Build without network access

The pinned QuickJS archive is vendored. Once the archive, extracted sources,
and a C toolchain are provisioned, normal builds fetch nothing:

```sh
make clean
make -j1 runner
make check
```

## Linux verification entrypoint

Run inside an existing Ubuntu 24.04 x86-64 container or host:

```sh
python3 scripts/verify_linux.py --runs 3 --jobs 1
```

Stages are `source_pin`, `clean`, `build`, `tests`, and `timings`. Any
non-zero stage exits 1 and is recorded in `reports/verify-linux-report.json`.
The clean stage forces a build with only the requested compiler and flags; the
runner is hashed after that build and again after timing. If timing rebuilds a
different binary, the exact tested binary is restored as the final artifact,
with both hashes recorded. By default the host must be Ubuntu 24.04 x86-64;
`--allow-non-target` is available only for harness smoke tests on another host
and records the mismatch as a limitation.

The timing output is written to `build/linux-build-timings.json` and
`build/linux-build-timings.md` so native reference timings are not overwritten.

## Docker verification

The operator supplies the base image reference. Prefer a digest:

```sh
python3 scripts/verify_docker.py \
  --image ubuntu:24.04@sha256:<operator-supplied-digest> \
  --require-digest \
  --platform linux/amd64 \
  --cpus 2 --memory 2g \
  --runs 3
```

What it does when an engine is available:

1. Builds the `verify` stage explicitly with `--platform linux/amd64`,
   `--build-arg BASE_IMAGE=<operator reference>`, and `--target verify`.
2. Inspects the built validation image and the base image and records the
   actual local image ID, architecture, OS, creation time, and repo digests.
3. Requires the requested platform and both image architectures to be
   `amd64` unless `--allow-arch` is given.
4. Runs `scripts/verify_linux.py` in the container with `--platform
   linux/amd64`, the requested `--cpus`/`--memory` quota, and `--network none`.
   It records the requested resources, the engine-applied `HostConfig`, the
   observed in-container cgroup CPU quota, and requires a clean x86_64 host
   report with no `target_mismatches`.
5. Exits non-zero on any failed stage and writes
   `reports/verify-docker-report.json`. Labels in that report separate the
   verification image from the runtime image.

A passing verify run validates the **validation image only**. The runtime
image is recorded as `runtime_image.status: pending`; it is not built, run, or
smoke-tested by this script. Runtime smoke testing is a separate operation; a
historical runtime revision passed it, while the current strict-boundary
revision still requires its fresh Docker/UVM rerun.

The Dockerfile's final stage is `runtime`, so a plain `docker build .` produces
the runtime service image. Build the validation image only with `--target
verify` (or `make docker-build-verify`).

```sh
docker build --platform linux/amd64 --target runtime \
  -t qjs-ctf-baseline:2026-06-04 .
docker build --platform linux/amd64 --target verify \
  -t qjs-ctf-verify:local .
```

When no engine is available it writes `status: skipped`, explains that nothing
was run, and exits 2. It does not invent a digest or claim a container run.

If the supplied base image already contains the build and Python dependencies,
add `--skip-apt` so the image build does not use the network.

## Runtime image verification (Phase 3A)

The real runtime image is verified separately from the `verify` stage. Build,
start, and probe it with:

```sh
python3 scripts/verify_runtime.py --engine docker \
  --base-image ubuntu:24.04@sha256:<operator-digest> \
  --platform linux/amd64 --cpus 2 --memory 2g --pids-limit 64 \
  --report reports/verify-runtime-report.json
```

The script builds `--target runtime`, enforces `linux/amd64`, records the
actual local image ID and RepoDigests, checks the non-root user and documented
command, scans `/app` and `/run/secrets`, mounts a synthetic flag read-only,
and probes health, state persistence, connection isolation, exception recovery,
absent host APIs, flag non-disclosure, limits, and cleanup. The container runs
with `--network none` and no published port; probes use `docker exec` over the
container's loopback. A missing flag file must fail visibly, and cleanup runs
on every path.

The Dockerfile has no `# syntax` directive, so the engine's built-in frontend
is used and no frontend image is fetched. `--frontend REF` opts into an
explicit pinned or mirrored frontend. `--skip-apt --build-network none`
supports a pre-provisioned base; `--prebuilt-image REF` verifies an existing
local runtime image without building.

With no engine the script writes `status: skipped` and exits 2. It does not
claim a run. See
[phase3a-runtime-and-isolation.md](phase3a-runtime-and-isolation.md).

## Container-separated evaluation (Phase 3A)

`evaluator/container_controller.py` runs one target container and one solver
container on a uniquely named internal bridge, with a fresh flag per instance:

```sh
python3 evaluator/container_controller.py --engine docker \
  --target-image qjs-ctf-baseline:<local-tag> \
  --solver-image <prebuilt-solver-image> \
  --solver-json '["/opt/solve"]' --timeout 30 \
  --report reports/container-evaluation-report.json
```

No target port is published. The solver receives only `target:8000`, no flag
mount or flag variable, no controller environment, no Docker socket, and no
host PID or network namespace. Both containers run non-root with dropped
capabilities, no-new-privileges, read-only root filesystems, private tmpfs
(`noexec`), and explicit CPU/memory/PID limits. Images must already exist
locally. The solver image must contain its files and be readable/executable by
the configured non-root user. In strict mode the controller creates and
exactly inspects the solver, then performs one final complete live-egress
revalidation immediately before starting it.

The real-engine boundary check is:

```sh
python3 evaluator/container_controller.py --engine docker \
  --target-image qjs-ctf-baseline:<local-tag> \
  --solver-image <prebuilt-solver-image> \
  --holder-image <trusted-holder-image> \
  --egress-mode strict --boundary-check \
  --report reports/container-boundary-report.json
```

Strict mode resolves the trusted holder reference to an immutable image ID,
holds the idle holder's network namespace, and installs a full IPv4 and IPv6
filter policy with the explicit legacy binaries
`iptables-legacy-restore`/`ip6tables-legacy-restore`, and validates both
readbacks before any untrusted solver starts. Each family restore is atomic;
the two-family sequence is not atomic. The safety property is that only the
idle holder exists in the namespace until both families are installed and read
back, and a failed operation never starts the solver. `--boundary-check`
defers activation so trusted pre-policy controls run in the holder namespace
first. Every executable boundary helper uses only the resolved immutable
holder image ID. The configured solver and optional probe references never
start; the actual solver follows `create` -> exact `inspect` -> `remove`.
Inspection requires exact image/user/`SecurityOpt`/PID/IPC/tmpfs/mount/
capability/device/resource allowlists. Filesystem, secret, PID and capability
runtime observations come from the trusted holder probe and are not solver
self-report. If the full boundary is not proven, only the proven egress
property is reported and the formal isolation gate stays `pending`. Both
containers share the host kernel.

Every image that may execute, plus the configured solver image, is rejected if
it declares writable `VOLUME` paths before any container starts. The solver
uses `--log-driver none` so the daemon cannot spool unbounded output.
Cleanup is retried per owned resource after engine failures. Public
engine-call records are metadata-only, so solver argv is not exported. Exit
codes are `0` passed, `1` failed, `2` skipped and `3` partial. Boundary
exceptions are written as structured `failed` results rather than `not-run`.

The current native revision passes 238/238 tests, but its fresh Docker/UVM
strict-boundary rerun remains pending. The first strict install failure has no
confirmed backend cause; unavailable `xt_comment` is only a hypothesis until
the exact IPv4 and IPv6 restore batches are captured with `--test`. Uploading
the revised source and creating a new temporary UVM require explicit
authorization in the current chat.

## Runtime flag injection

Preferred file mode:

```sh
python3 adapter/server.py \
  --host 127.0.0.1 \
  --port 8000 \
  --runner ./build/qjs_runner \
  --flag-file /run/secrets/qjs_ctf_flag
```

The platform mounts the flag file read-only and readable by the adapter user.
Environment mode remains available for local compatibility:

```sh
QJS_CTF_FLAG='<runtime-secret>' python3 adapter/server.py
```

Do not configure both a non-empty environment flag and `--flag-file`; the
adapter rejects the conflict at startup. See `docs/flag-injection.md`.

## Docker runtime image

The runtime stage keeps only Python 3, the runner, the adapter, and the upstream
license. Build it explicitly (the final Dockerfile stage):

```sh
docker build --platform linux/amd64 --target runtime \
  -t qjs-ctf-baseline:2026-06-04 .
```

Run it with the flag file mounted read-only:

```sh
docker run --rm -p 127.0.0.1:8000:8000 \
  -v /run/secrets/qjs_ctf_flag:/run/secrets/qjs_ctf_flag:ro \
  qjs-ctf-baseline:2026-06-04 \
  python3 /app/adapter/server.py --host 0.0.0.0 --port 8000 \
    --runner /app/build/qjs_runner \
    --flag-file /run/secrets/qjs_ctf_flag
```

The runtime image itself has not been built or smoke-tested on the
implementation host; see `docs/acceptance.md`.

The runtime image contains no baked-in flag. Publish the port to host loopback
unless external exposure is intentional.
