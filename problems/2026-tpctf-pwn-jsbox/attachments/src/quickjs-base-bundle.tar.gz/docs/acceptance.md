# Requirements and acceptance matrix

Full objective: a deployable QuickJS CTF environment with runtime flag
injection, remote interaction, reproducible Linux/Docker validation, a local
instance evaluator, and honest authoring-workflow evidence.

Status meanings:

- **Executed** means the command was run and passed on the explicitly named host.
- **Implemented, pending execution** means code and tests exist, but the
  required Linux/Docker execution has not happened on this host.
- **Pending** means the item is not implemented or not evidenced at all.

The native and Ubuntu x86-64 baseline checks do **not** complete the project.
Runtime packaging has now been tested separately. These checks do not prove
strict endpoint-only isolation, challenge solvability, or the two-hour authoring
workflow. See `linux-validation.md` for earlier Linux baseline evidence and
`.orchestration/review-phase3a.md` for current runtime results.

| ID | Requirement | Evidence / command | Status |
| --- | --- | --- | --- |
| R1 | Pinned, unmodified QuickJS source layer | `python3 scripts/verify_pin.py`; archive SHA-256 `b376e839...ad2a`, release `2026-06-04` | Executed |
| R2 | Native build and full test suite | Current 238-test suite passed on Darwin arm64; the historical 150-test Docker verification-image run and earlier 65-test baseline reports are preserved | Current native suite executed; fresh Docker rerun pending |
| R3 | Audit existing platform code and fix real defects | Adapter regression fix for non-default `--flag-env`; shutdown-race worker cleanup guard; tests in `tests/test_integration.py` | Executed |
| R4 | Repeated cold/no-op/core-touch timing with raw samples, median, maximum, host metadata, CPU quota, compiler, jobs, actual flags, timestamp restoration | `docs/build-timings.md` (native); `reports/linux-timings.json` and `.md` (Linux, 3 samples/category) | Executed on both hosts |
| R5 | One Linux verification entrypoint: build, pin, all tests, timing suite, machine-readable report, visible failures | `python3 scripts/verify_linux.py --runs 3`; `reports/linux-validation.json` | Executed on Ubuntu 24.04 x86-64 |
| R6 | Actual Docker verification image, architecture, resources and toolchain evidence | `reports/phase3a-docker-real.json`; final non-root run `reports/phase3a-real-nonroot-tests.json`; archived local base identity recorded | Passed; registry publication is not claimed |
| R7 | File-based runtime flag injection preferred; environment mode retained; no JS exposure; no value in logs/replies | `adapter/server.py --flag-file PATH`; tests `FlagFileAdapterTest`, `FlagFileLoaderUnitTest` | Executed on both hosts |
| R8 | Local evaluation controller: fresh flag per instance, isolated cwd, loopback endpoint, health check, process cleanup, redacted reports | `python3 evaluator/controller.py --solver-json '[...]' --report ...`; `tests/test_evaluator.py` | Executed on both hosts; same-user development harness |
| R9 | Evaluator tests separate plumbing doubles from real-target tests | `EvaluatorPlumbingUnitTests` and `EvaluatorTargetIntegrationTests`; the latter explicitly makes no solvability claim | Executed |
| R10 | Ubuntu 24.04 Linux x86-64 target validation | DSec Ubuntu container, uid 10001, 2 CPUs / 2 GiB, no external network; `reports/linux-validation.json` | **Passed: 65 tests, zero target mismatches** |
| R11 | Two genuinely different challenge variants with end-to-end reference solutions | No challenge variant or reference exploit exists in Phase 2 | **Pending** |
| R12 | Real two-hour challenge-authoring workflow experiment | Not run. Build timings alone are not evidence for this | **Pending** |
| R13 | Hardened multi-tenant isolation | Explicit non-goal; same-user local evaluator, process-per-connection only | Out of scope |
| R14 | Actual runtime-image build, service/flag/resource checks and cleanup | `reports/phase3a-runtime-real.json`; runtime image ID `11cbdaa9…310302` | Passed |
| R15 | Separate target/solver containers, negative judging, trusted-holder runtime probes and exact solver-configuration checks | `reports/phase3a-evaluator-*.json`, `reports/phase3a-boundary-real.json`, `reports/phase3a-egress3-boundary-first.json` | Historical negative checks passed, but strict policy installation failed closed; fresh formal isolation run pending |

## Acceptance criteria and remaining gates

### R10 Linux target validation

Passed in the DSec source-validation container. Test duration was 2.946 s;
clean/core-touch timing medians were 20.625275 s / 19.117432 s. The tested,
post-timing and final runner SHA-256 values match. This does not validate
the separate Dockerfile runtime image.

Accept only when `scripts/verify_linux.py --runs 3` exits zero inside an
Ubuntu 24.04 x86-64 container and its report has `status: passed`, with every
stage (`source_pin`, `clean`, `build`, `tests`, `timings`) at return code zero
and no `target_mismatches`. The clean stage removes prior objects so the build
uses only the requested compiler and flags. `build/qjs_runner` is hashed after
the clean build and after timing; if timing rebuilds a different binary, the
tested binary is restored as the final artifact, and the report records both
hashes.

### R11 Challenge variants and reference solutions

Accept only when two genuinely different challenge variants exist, each with a
reference solver that interacts with the remote target and returns the exact
runtime-injected flag. The evaluator plumbing tests in this phase do not
satisfy this requirement.

### R12 Two-hour authoring experiment

Accept only when a real timed authoring session is recorded with its start/end
times, artifacts produced, and observed blockers. Repeated build timings are
compile/link measurements only and must not be presented as workflow evidence.

### R6 Docker verification

Accept only when `scripts/verify_docker.py` runs with an available engine and
`--platform linux/amd64`, the operator-supplied image and the built
verification image are recorded with their actual local image IDs and
architectures, the requested CPU/memory quota and observed cgroup CPU quota are
recorded, and the in-container `linux-report.json` has `status: passed` with no
`target_mismatches`. The script writes `status: skipped` and exits 2 when no
engine is available; it never invents a digest or claims a run that did not
occur.

This accepts the **verification image** only. The runtime image must be
reported separately as pending unless it is independently built, started, and
smoke-tested. A passing verify stage is not runtime-image validation.

For formal Phase 3 solvability results, target and solver must use independent
sandboxes as specified in `phase3-plan.md`; the local same-user harness does
not rule out direct access to the Flag.

### Phase 3A runtime-image and container-boundary status

`scripts/verify_runtime.py` implements the missing runtime-image check
separately from the `verify` stage: real `--target runtime` build, amd64
enforcement, actual image identity, non-root/command inspection, a synthetic
read-only flag mount, service probes, absent host APIs, flag non-disclosure,
missing-flag failure, and scoped cleanup. It exits 2 with a skipped report when
no engine exists. It passed on the temporary Docker-capable DSec UVM. The
image default `CMD` and the verifier's explicit file-mode override are kept
distinct; images that declare writable `VOLUME` paths are rejected before the
scan or service container starts; a failed log read fails the disclosure check
as unverified; scan helper containers are uniquely named and labelled; and
report output is redacted at capture and again before writing.

`evaluator/container_controller.py` implements a Docker-backed target/solver
evaluation path with a fresh flag per instance, an internal per-instance
network, no published target port, endpoint-only solver argv, hardened
containers, bounded judging, reset, and idempotent scoped cleanup. It rejects
image-declared writable volumes, disables the solver log driver, records
resource ownership before create/start attempts, and retries cleanup after
engine failures. Strict egress now uses the legacy iptables/ip6tables backend
(the observed Linux platform does not support nftables/Netlink) inside a held
holder network namespace. It installs and reads back both families, requires
per-destination counters, and keeps only the idle holder in that namespace
until both readbacks succeed. In boundary mode every executable helper uses the
resolved immutable trusted-holder image ID; the solver and optional probe
references never start. The actual solver follows `create` -> exact `inspect`
-> `remove`, with exact image/user/`SecurityOpt`/PID/IPC/tmpfs/mount/capability/
device and resource allowlists. Runtime filesystem, secret, PID and capability
observations therefore belong to the trusted-holder probe, not to solver
self-report. Normal evaluation repeats the complete live-egress validation
after solver inspection and immediately before start. A partial boundary exits
3, while a thrown boundary operation is recorded as structured `failed`
instead of `not-run`. Both containers share the host kernel.

The historical 150 behavioral assertions are retained and the current native
suite passes 238/238, including the legacy strict-egress implementation and the
boundary trust/configuration regressions. Native tests do not claim real
Docker outcomes. Historical skipped reports remain host-absence
evidence only. The historical real boundary report failed the host-gateway
check. The first frozen strict-backend run then failed closed during policy
installation before any solver started; its recovered report is
`reports/phase3a-egress3-boundary-first.json`. Neither result is full-isolation
acceptance. The current revision preserves bounded per-family
install/readback diagnostics and must be exercised again on a fresh Docker
host before the formal gate can pass. The first-run cause remains unknown:
missing `xt_comment` support is only a hypothesis until the exact restore
batches are tested with `iptables-legacy-restore --test` and
`ip6tables-legacy-restore --test`.
