# Linux source-baseline validation

The final source snapshot passed `python3 scripts/verify_linux.py --runs 3`
inside a temporary DSec container. This is source validation in Ubuntu, not a
build or smoke test of the project's Dockerfile images.

| Item | Observed value |
| --- | --- |
| Distribution / architecture | Ubuntu 24.04.3 LTS / x86-64 |
| User | qjs, uid/gid 10001 |
| Compiler | GCC 13.3.0, Ubuntu 13.3.0-6ubuntu2~24.04.1 |
| libc | libc6 2.39-0ubuntu8.9 |
| Make / Python | GNU Make 4.3 / Python 3.12.3 |
| Resources | cgroup v2 2 CPUs; memory.max 2147483648 bytes |
| Build jobs | 1 |
| Test result | 65 passed, no skips, 2.946 s |
| Verification stages | environment, source_pin, clean, build, tests, timings: all exit 0 |
| Target mismatches | none |
| Network during validation | LAN, WWW and apt-mirror access disabled |

| Build measurement | Median | Maximum | Raw samples (s) |
| --- | --- | --- | --- |
| Clean | 20.625275 s | 20.883398 s | 19.983517, 20.883398, 20.625275 |
| No-op | 0.001942 s | 0.002132 s | 0.001942, 0.001924, 0.002132 |
| Core-touch | 19.117432 s | 19.327592 s | 18.397101, 19.117432, 19.327592 |

The source snapshot contained 89 files and was checked against the final local
files before review-only documentation updates. Archive SHA-256:
`4b40081b938533d4b5f35e4b493939efc4a10b032f483e9661122f367ab6e3e0`.

The tested, post-timing, and final runner hashes are identical:
`243a899cd0a338f0b90758d012b9fde41e015594d6935c5f7e791f3bdfcb373e`.

Evidence:

- `reports/linux-validation.json`: all stage results, test output and artifact hashes.
- `reports/linux-timings.json` and `.md`: raw samples, actual flags and quota.
- `reports/linux-identity.json`: uid, libc, quota and binary hash.
- `reports/linux-snapshot.json`: per-file source manifest.
- `reports/dsec-validation-state.json`: provisioning and cleanup state.

The container image was referenced by a tag; no immutable base digest is
claimed. Apt was used only while preparing the temporary environment. Package
versions are recorded, but a reproducible final runtime image remains pending.
These measurements also do not establish challenge solvability or two-hour
authoring performance; those gates are in `phase3-plan.md`.
