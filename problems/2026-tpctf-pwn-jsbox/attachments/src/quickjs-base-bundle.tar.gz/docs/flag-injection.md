# Runtime instance-flag injection boundary

The preferred deployment interface is a **read-only flag file** supplied by the
platform. Environment injection remains supported for local compatibility. Both
modes inject one value per adapter instance; the value is never exposed to
JavaScript, never logged, and never included in normal replies.

## Preferred file mode

The adapter reads the value once at startup:

```sh
python3 adapter/server.py \
  --host 127.0.0.1 --port 8000 --runner ./build/qjs_runner \
  --flag-file /run/secrets/qjs_ctf_flag
```

Documented deployment path: **`/run/secrets/qjs_ctf_flag`**. The platform mounts
it readable by the adapter user and read-only. The adapter warns if the file is
writable but does not change the mount. The file is read before the listening
socket is created.

File parsing rules:

- At most 4096 bytes.
- Valid UTF-8, no NUL byte.
- One trailing LF or CRLF is stripped for secret-file convenience.
- Empty, missing, unreadable, directory, oversized, or invalid-UTF-8 files are
  startup errors. The adapter exits 2 and prints only the path and error kind,
  never the contents.
- Conflict rule: `--flag-file` together with a non-empty environment value for
  the variable named by `--flag-env` is a startup error. Silent precedence is
  intentionally avoided.

## Environment mode (local compatibility)

```sh
QJS_CTF_FLAG='<runtime-secret>' python3 adapter/server.py
```

`--flag-env NAME` selects the adapter-side source variable. An empty name
disables environment mode. An empty value is treated as absent. The adapter
reads that source once at startup and forwards the value to each worker under
the fixed reserved worker variable `QJS_CTF_FLAG`. This fixes the earlier
defect where a non-default `--flag-env` name caused the worker handshake to
fail.

## Worker boundary

1. The adapter does not forward its own environment to workers.
2. Each worker receives a fixed minimal environment (`LC_ALL`, `LANG`) plus,
   when configured, `QJS_CTF_FLAG`.
3. The runner prints only `instance flag present` or `instance flag absent` to
   stderr. The adapter reads this startup line, requires it to match the
   resolved flag presence, and fails closed on a missing or inconsistent
   handshake.
4. JavaScript cannot read environment variables or files. The worker does not
   register `std`/`os`, a module loader, `process`, a filesystem API, or a
   subprocess API. Tests inspect every global and serialized reply for the flag
   value.
5. The adapter logs only the source (`file:<path>` or `env:<name>`) and whether
   it is configured. It never logs the value.

## Docker example

Build the runtime image explicitly (the runtime stage is the Dockerfile's final
stage; a plain `docker build .` also selects it, while verification must select
`--target verify`):

```sh
docker build --platform linux/amd64 --target runtime \
  -t qjs-ctf-baseline:2026-06-04 .
```

Run it with the flag file mounted read-only:

```sh
docker run --rm -p 127.0.0.1:8000:8000 \
  -v /run/secrets/qjs_ctf_flag:/run/secrets/qjs_ctf_flag:ro \
  qjs-ctf-baseline:2026-06-04 \
  python3 /app/adapter/server.py --host 0.0.0.0 --port 8000 \
    --runner /app/build/qjs_runner \
    --flag-file /run/secrets/qjs_ctf_flag
```

The runtime image contains no baked-in flag. The default container command still
uses environment mode for local compatibility; deployment should override it
with `--flag-file`. This runtime image has not been built or smoke-tested on the
implementation host; a passing `verify` stage is not runtime-image validation.

## Tests

- `FlagFileAdapterTest` covers file mode, non-default environment names,
  conflicting sources, missing files, directories, empty files, unreadable
  files, and absence of the value from replies and logs.
- `FlagFileLoaderUnitTest` covers newline stripping, empty/NUL/non-UTF-8/
  oversized files, and source resolution.
- Existing tests cover JavaScript invisibility and the worker handshake.

## Non-goals and limitations

- There is no per-connection flag. Use one adapter process (or one evaluator
  instance) per challenge instance.
- The flag file is readable by the adapter user. A same-user process that can
  inspect the filesystem or process arguments may learn the path; use a
  dedicated user/container boundary for real deployment.
- The adapter does not implement secret-manager integration, encryption, or
  filesystem sandboxing.
- This phase does not introduce a challenge vulnerability or reference exploit.
