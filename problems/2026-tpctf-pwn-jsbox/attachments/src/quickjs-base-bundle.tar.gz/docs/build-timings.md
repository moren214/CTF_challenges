# Native build timings

Measured 2026-11-01T11:17:35Z with `make -j1`,
3 run(s). The pinned QuickJS archive was verified by SHA-256
before timing; download and extraction time is **not** included, and no LTO is
used. Source timestamps were restored after the run.

| Field | Value |
| --- | --- |
| Host | Darwin 25.4.0 (arm64) |
| Distribution | Darwin |
| CPU quota | not observable |
| Compiler | Apple clang version 21.0.0 (clang-2100.0.123.102) |
| Compiler target | arm64-apple-darwin25.4.0 |
| Make | GNU Make 3.81 (`/Library/Developer/CommandLineTools/usr/bin/make`) |
| Jobs | 1 |
| Runs | 3 |

| Measurement | Median | Maximum | Raw samples (s) |
| --- | --- | --- | --- |
| Cold build (`make clean` then build) | 5.503 s | 6.073 s | [6.07326, 5.418482, 5.503334] |
| No-op build (nothing changed) | 0.004 s | 0.004 s | [0.004183, 0.003943, 0.004256] |
| Core-touch incremental (`touch quickjs.c`) | 4.767 s | 4.937 s | [4.765538, 4.76722, 4.936667] |

Actual make variables recorded for this run:

```json
{
  "BUILD_DIR": "build",
  "CC": "cc",
  "CFLAGS": "-O2 -g",
  "COMMON_CFLAGS": "-std=gnu11 -fwrapv -funsigned-char -Wall -Wextra -Wno-unused-parameter -Wno-sign-compare -O2 -g -D_GNU_SOURCE -DCONFIG_VERSION=\\\"2026-06-04\\\" -Ithird_party/quickjs/src",
  "CPPFLAGS": "-D_GNU_SOURCE -DCONFIG_VERSION=\\\"2026-06-04\\\" -Ithird_party/quickjs/src",
  "LDFLAGS": "-g",
  "LDLIBS": "-lm -lpthread",
  "OPT": "-O2",
  "WARNFLAGS": "-Wall -Wextra -Wno-unused-parameter -Wno-sign-compare"
}
```

Scope: **native Darwin arm64 only**. Target validation
for Ubuntu 24.04 Linux x86-64 is a separate stage
(`scripts/verify_linux.py`); its current status, including any pending items, is
recorded in `docs/acceptance.md`. These numbers measure compile and link
throughput; they are not evidence that a two-hour challenge-authoring workflow
is achievable. That experiment is still pending.

The native raw samples are retained in the table above. The original
`build/build-timings.json` was an ephemeral build output and was removed by a
later clean verification; it is not available as a separate JSON artifact.
The later Linux run preserves its complete raw JSON at
`reports/linux-timings.json`. For future measurements, pass `--json` and
`--markdown` paths under `reports/` so `make clean` cannot remove the evidence.
