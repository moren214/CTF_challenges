# Local evaluation controller

`evaluator/controller.py` manages separate local challenge instances. It is a
plumbing and lifecycle harness, not a hardened multi-tenant system.

## What one instance does

1. Generates a fresh random flag with `secrets.token_hex`.
2. Creates a mode-0700 instance directory and a separate mode-0700 solver
   working directory.
3. Writes the flag to `instance-flag` (mode 0400) and starts the adapter with
   `--flag-file <path>` on a random loopback port.
4. Health-checks the endpoint with `{"code":"1+1"}` and requires result `2`.
5. Adds the adapter process and its workers to the controller-owned cleanup
   set.
6. On stop, reset, timeout, or error, terminates the adapter process group and
   any discoverable descendants. `/proc` is used on Linux; `ps` is the macOS
   fallback. Graceful SIGTERM lets the adapter kill its workers; SIGKILL follows
   if it does not exit.

`reset()` stops the old instance and starts a new one with a new flag.

## Solver contract

The solver command is an explicit operator-provided argv list, for example:

```sh
python3 evaluator/controller.py \
  --solver-json '["python3", "/opt/challenge/solve.py"]' \
  --timeout 30 \
  --report build/evaluation-report.json
```

- The controller appends exactly one argument: `127.0.0.1:<port>`.
- The solver runs with `shell=False`, an isolated empty working directory, a
  minimal environment, and stdin connected to `/dev/null`.
- The expected flag is never placed in solver argv, environment, working
  directory, stdin, or feedback.
- The solver must exit 0 and write the exact flag as its only non-whitespace
  stdout content. Empty, wrong, non-zero-exit, and timed-out results are
  rejected.
- Stdout is retained up to 65536 bytes. Output overflow is rejected with
  `reason: output_limit` even when the retained prefix would otherwise equal
  the flag; a truncated buffer is never judged as a match.
- The verdict contains only `ok`, `reason`, `timed_out`, `returncode`,
  `duration_s`, total and retained output byte counts, truncation flags, and
  `stdout_limit_bytes`. Solver stdout and stderr content are not included in
  reports.
- The wall-clock timeout is strict. On expiry the solver process group is
  SIGKILLed.
- No built-in solver exists. A trivial solver that bypasses the target is
  explicitly not provided.

## Reports and redaction

Public metadata contains the instance ID, loopback endpoint, flag source,
flag length, redacted directory placeholders, and health status. It never
contains the flag value or solver output. The expected flag remains in
controller memory and in the mode-0400 flag file that the adapter reads.

## Test separation

- `EvaluatorPlumbingUnitTests` uses test doubles only. It tests lifecycle,
  fresh flags, argv/env/cwd isolation, judging, timeout, and redaction.
- `EvaluatorTargetIntegrationTests` starts the real adapter and unmodified
  QuickJS runner. It tests real target interaction and cleanup but makes **no
  challenge-solvability claim**. Phase 2 has no challenge variant or reference
  exploit.

## Limitations

- Same-user local harness: a process running as the same OS user may be able
  to inspect the adapter, its arguments, or the filesystem. Use a dedicated
  container/user boundary for real deployment.
- The adapter endpoint is loopback-only and unauthenticated.
- The solver is operator-supplied code and is trusted to the extent that the
  operator trusts it. The controller isolates its argv/env/cwd/stdin and bounds
  its runtime, but it cannot sandbox arbitrary operator code.
