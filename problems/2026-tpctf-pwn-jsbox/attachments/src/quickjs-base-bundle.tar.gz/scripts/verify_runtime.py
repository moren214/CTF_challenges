#!/usr/bin/env python3
"""Build and verify the *runtime* Docker image (not the verify stage).

This is the Phase 3A runtime-image check.  It builds the Dockerfile's
``runtime`` stage, inspects the resulting image identity and configuration,
starts it with a synthetic flag supplied only through a read-only file mount,
and runs service probes against the real TCP adapter.

The script never prints or stores the synthetic flag value and never claims a
container run that did not happen.  With no container engine it writes an
honest ``skipped`` report and exits 2.

Networking notes:
  * The Dockerfile no longer carries a ``# syntax=`` directive, so a build uses
    the engine's built-in Dockerfile frontend and does not fetch a frontend
    image.  ``--frontend REF`` passes an explicit pinned/mirrored frontend via
    BUILDKIT_SYNTAX; that may require registry or mirror access.
  * The runtime container is started with ``--network none``.  The adapter's
    TCP service is reached through ``docker exec`` over the container's own
    loopback, so no host port is published.
  * ``--skip-apt`` plus ``--build-network none`` supports a pre-provisioned
    base image and an offline build.  ``--prebuilt-image`` skips the build
    entirely and verifies an existing local runtime image.
"""

from __future__ import annotations

import argparse
import json
import os
import platform
import re
import secrets
import shutil
import subprocess
import sys
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_REPORT = ROOT / "reports" / "verify-runtime-report.json"
ENGINE_CANDIDATES = ("docker", "podman", "nerdctl")
LABEL_INSTANCE = "qjsctf.instance"
LABEL_ROLE = "qjsctf.role"
FLAG_PATH = "/run/secrets/qjs_ctf_flag"

# The image's default CMD (Dockerfile runtime stage).  It preserves the
# adapter's environment mode and deliberately omits --flag-file.
IMAGE_DEFAULT_CMD = [
    "python3", "/app/adapter/server.py",
    "--host", "0.0.0.0", "--port", "8000",
    "--runner", "/app/build/qjs_runner",
]
# Explicit file-mode override used only when this verifier starts the runtime
# container with a read-only mounted flag file.
RUNTIME_FILE_CMD = IMAGE_DEFAULT_CMD + ["--flag-file", FLAG_PATH]
# Backwards-compatible name for the documented file-mode runtime command.
RUNTIME_CMD = RUNTIME_FILE_CMD
# The image configuration must match the image's own default CMD, not the
# verifier's file-mode override.
EXPECTED_IMAGE_CMD = IMAGE_DEFAULT_CMD

FLAG_LITERAL_RE = re.compile(r"FLAG\{[0-9a-fA-F]{16,}\}")
REDACTED_FLAG = "<redacted-flag>"


class RuntimeVerificationError(RuntimeError):
    pass


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def new_flag() -> str:
    return "FLAG{" + secrets.token_hex(16) + "}"


def redact_text(text, flag: str | None = None) -> str:
    """Remove the synthetic flag and flag-like literals from report text."""
    if not isinstance(text, str):
        text = str(text)
    if flag:
        text = text.replace(flag, REDACTED_FLAG)
    return FLAG_LITERAL_RE.sub(REDACTED_FLAG, text)


def redact_value(value, flag: str | None = None):
    """Recursively redact a report structure before it is written."""
    if isinstance(value, str):
        return redact_text(value, flag)
    if isinstance(value, list):
        return [redact_value(item, flag) for item in value]
    if isinstance(value, dict):
        return {key: redact_value(item, flag)
                for key, item in value.items()}
    return value


# ---------------------------------------------------------------------------
# Engine helpers

def find_engine(explicit: str | None) -> tuple[str | None, str]:
    candidates = []
    if explicit:
        candidates.append(explicit)
    else:
        env_engine = os.environ.get("CONTAINER_ENGINE")
        if env_engine:
            candidates.append(env_engine)
        candidates.extend(ENGINE_CANDIDATES)
    seen = set()
    diagnostics = []
    for candidate in candidates:
        if not candidate or candidate in seen:
            continue
        seen.add(candidate)
        path = shutil.which(candidate)
        if not path:
            diagnostics.append(f"{candidate}: not found on PATH")
            continue
        try:
            probe = subprocess.run([path, "info"], capture_output=True,
                                   text=True, timeout=60)
        except (OSError, subprocess.SubprocessError) as exc:
            diagnostics.append(f"{candidate}: info failed ({exc})")
            continue
        if probe.returncode == 0:
            return path, "; ".join(diagnostics)
        diagnostics.append(
            f"{candidate}: engine info failed ({probe.stderr.strip()[:200]})")
    return None, "; ".join(diagnostics)


class Engine:
    """Thin, test-friendly wrapper around engine CLI invocations."""

    def __init__(self, path: str, default_timeout: float = 1800.0):
        self.path = path
        self.default_timeout = default_timeout

    def run(self, argv: list[str], timeout: float | None = None,
            env: dict | None = None) -> subprocess.CompletedProcess:
        return subprocess.run(
            argv, capture_output=True, text=True,
            timeout=timeout if timeout is not None else self.default_timeout,
            env=env)

    def version(self) -> str:
        try:
            probe = self.run([self.path, "version"], timeout=60)
        except (OSError, subprocess.SubprocessError):
            return "unknown"
        if probe.returncode == 0:
            lines = (probe.stdout or probe.stderr).strip().splitlines()
            return lines[0] if lines else "unknown"
        return "unknown"


# ---------------------------------------------------------------------------
# Pure command builders (unit-tested)

def build_argv(engine: str, tag: str, base_image: str, platform: str,
               dockerfile: str, context: str, *, skip_apt: bool = False,
               build_network: str | None = None,
               frontend: str | None = None) -> list[str]:
    argv = [
        engine, "build",
        "--platform", platform,
        "--target", "runtime",
        "--build-arg", f"BASE_IMAGE={base_image}",
        "-t", tag,
        "-f", dockerfile,
    ]
    if skip_apt:
        argv.extend(["--build-arg", "SKIP_APT=1"])
    if build_network:
        argv.extend(["--network", build_network])
    if frontend:
        argv.extend(["--build-arg", f"BUILDKIT_SYNTAX={frontend}"])
    argv.append(context)
    return argv


def runtime_container_argv(engine: str, name: str, image: str, platform: str,
                           instance_id: str, *, cpus: float, memory: str,
                           pids_limit: int, flag_host_path: str | None,
                           detach: bool = True) -> list[str]:
    """Command for the runtime container or the missing-flag control.

    The flag value never appears here; only the host path (which contains no
    secret value) and the fixed container path do.
    """
    argv = [engine, "run"]
    argv.extend(["--name", name])
    if detach:
        argv.append("-d")
    else:
        argv.append("--rm")
    argv.extend([
        "--platform", platform,
        "--pull=never",
        "--network", "none",
        "--cap-drop", "ALL",
        "--security-opt", "no-new-privileges:true",
        "--read-only",
        "--tmpfs", "/tmp:rw,noexec,nosuid,nodev,size=16m",
        "--cpus", f"{cpus:g}",
        "--memory", memory,
        "--pids-limit", str(pids_limit),
        "--label", f"{LABEL_INSTANCE}={instance_id}",
        "--label", f"{LABEL_ROLE}=runtime",
    ])
    if flag_host_path is not None:
        argv.extend([
            "--mount",
            f"type=bind,source={flag_host_path},target={FLAG_PATH},readonly",
        ])
    argv.append(image)
    argv.extend(RUNTIME_CMD)
    return argv


def image_inspect_argv(engine: str, reference: str) -> list[str]:
    return [engine, "image", "inspect", "--format", "{{json .}}", reference]


def container_inspect_argv(engine: str, reference: str) -> list[str]:
    return [engine, "inspect", "--format", "{{json .}}", reference]


def exec_argv(engine: str, container: str, command: list[str]) -> list[str]:
    return [engine, "exec", container, *command]


def remove_argv(engine: str, reference: str) -> list[str]:
    # -v removes anonymous volumes attached by an image-declared
    # VOLUME; named operator volumes are never removed.
    return [engine, "rm", "-f", "-v", reference]


# ---------------------------------------------------------------------------
# Image inspection

def parse_image_inspect(text: str) -> dict:
    try:
        data = json.loads(text)
    except json.JSONDecodeError as exc:
        raise RuntimeVerificationError(
            f"image inspect returned invalid JSON: {exc}") from exc
    config = data.get("Config") or {}
    return {
        "Id": data.get("Id"),
        "RepoTags": data.get("RepoTags"),
        "RepoDigests": data.get("RepoDigests") or [],
        "Architecture": data.get("Architecture"),
        "Os": data.get("Os"),
        "Created": data.get("Created"),
        "Size": data.get("Size"),
        "User": config.get("User"),
        "Entrypoint": config.get("Entrypoint"),
        "Cmd": config.get("Cmd"),
        "WorkingDir": config.get("WorkingDir"),
        "Env": config.get("Env") or [],
        "ExposedPorts": config.get("ExposedPorts"),
        "Volumes": config.get("Volumes") or {},
    }


def is_nonroot_user(user: str | None) -> bool:
    if not user:
        return False
    name = user.split(":", 1)[0].strip()
    if name in ("", "root", "0"):
        return False
    if name.isdigit():
        return int(name) != 0
    return True


def expected_command_matches(cmd) -> bool:
    return list(cmd or []) == EXPECTED_IMAGE_CMD


def redacted_image_record(image: dict) -> dict:
    """Image metadata safe for a report: no arbitrary env values or commands."""
    record = dict(image)
    env = record.pop("Env", None) or []
    record["env_names"] = [entry.split("=", 1)[0] for entry in env]
    record["env_count"] = len(env)
    volumes = record.get("Volumes") or {}
    record["Volumes"] = {
        "count": len(volumes),
        "paths": sorted(str(path) for path in volumes),
    } if volumes else {"count": 0, "paths": []}
    cmd = record.get("Cmd")
    if expected_command_matches(cmd):
        record["Cmd"] = list(cmd)
    else:
        record["Cmd"] = "<redacted: unexpected command>"
    if record.get("Entrypoint"):
        record["Entrypoint"] = "<redacted: unexpected entrypoint>"
    return record


def env_contains_flag(env: list[str], flag: str | None = None) -> bool:
    for entry in env:
        if entry.startswith("QJS_CTF_FLAG="):
            return True
        if flag is not None and flag in entry:
            return True
    return False


def _has_flag_literal(value) -> bool:
    return FLAG_LITERAL_RE.search(str(value)) is not None


def image_security_summary(image: dict, flag: str | None = None) -> dict:
    env = image.get("Env") or []
    cmd = list(image.get("Cmd") or [])
    entrypoint = list(image.get("Entrypoint") or [])
    volumes = image.get("Volumes") or {}
    config_parts = cmd + entrypoint
    return {
        "architecture": image.get("Architecture"),
        "os": image.get("Os"),
        "user": image.get("User"),
        "non_root_user": is_nonroot_user(image.get("User")),
        "expected_command": expected_command_matches(cmd),
        "entrypoint_empty": not entrypoint,
        "command": (list(cmd) if expected_command_matches(cmd)
                    else "<redacted: unexpected command>"),
        "entrypoint": (entrypoint if not entrypoint
                       else "<redacted: unexpected entrypoint>"),
        "env_has_flag_variable": any(
            e.startswith("QJS_CTF_FLAG=") for e in env),
        # These checks do not require the synthetic flag to have been
        # generated yet: they look for the flag *pattern* in baked config.
        "env_has_flag_literal": any(_has_flag_literal(e) for e in env),
        "command_has_flag_literal": any(
            _has_flag_literal(part) for part in config_parts),
        "env_has_synthetic_flag": bool(flag) and any(flag in e for e in env),
        "command_has_synthetic_flag": bool(flag) and any(
            flag in str(part) for part in config_parts),
        "has_image_volumes": bool(volumes),
        "image_volumes": sorted(str(path) for path in volumes),
    }


# ---------------------------------------------------------------------------
# In-image secret scan (bounded, reports paths/pattern labels only)

def scan_image_script() -> str:
    return r'''
import json, os, re
roots = ["/app", "/run/secrets"]
MAX_FILES = 5000
MAX_FILE_BYTES = 1024 * 1024
flag_re = re.compile(rb"FLAG\{[0-9a-fA-F]{16,}\}")
patterns = [(flag_re, "flag-literal"), (b"QJS_CTF_FLAG=", "flag-env-assignment")]
findings = []
files = 0
bytes_read = 0
skipped_oversized = 0
files_limit_reached = False
for root in roots:
    if files_limit_reached:
        break
    if not os.path.isdir(root):
        continue
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in ("__pycache__",)]
        for name in filenames:
            if files >= MAX_FILES:
                files_limit_reached = True
                break
            path = os.path.join(dirpath, name)
            try:
                if not os.path.isfile(path) or os.path.islink(path):
                    continue
                size = os.path.getsize(path)
            except OSError:
                continue
            if size > MAX_FILE_BYTES:
                skipped_oversized += 1
                continue
            files += 1
            try:
                with open(path, "rb") as handle:
                    data = handle.read(MAX_FILE_BYTES + 1)
            except OSError:
                continue
            bytes_read += len(data)
            for pattern, label in patterns:
                matched = (pattern.search(data) is not None
                           if hasattr(pattern, "search") else pattern in data)
                if matched:
                    findings.append({"path": path, "pattern": label})
                    break
        if files_limit_reached:
            break
print(json.dumps({
    "roots": roots,
    "files_scanned": files,
    "bytes_scanned": bytes_read,
    "max_files": MAX_FILES,
    "max_file_bytes": MAX_FILE_BYTES,
    "files_limit_reached": files_limit_reached,
    "skipped_oversized_files": skipped_oversized,
    "findings": findings,
    "flag_path_exists": os.path.exists("/run/secrets/qjs_ctf_flag"),
}))
'''


def parse_scan_result(stdout: str) -> dict:
    try:
        data = json.loads(stdout)
    except json.JSONDecodeError as exc:
        raise RuntimeVerificationError(
            f"image secret scan returned invalid JSON: {exc}") from exc
    if not isinstance(data, dict):
        raise RuntimeVerificationError("image secret scan returned no object")
    return data


# ---------------------------------------------------------------------------
# Runtime probe scripts

def health_script(port: int = 8000) -> str:
    return (
        "import json, socket\n"
        f"s = socket.create_connection(('127.0.0.1', {port}), 3)\n"
        "s.sendall(b'{\"code\":\"1+1\"}\\n')\n"
        "line = s.makefile('rb').readline()\n"
        "r = json.loads(line)\n"
        "print('HEALTH_OK' if r.get('ok') and r.get('result') == 2 "
        "else 'HEALTH_BAD')\n"
    )


def runtime_probe_script(port: int = 8000) -> str:
    return r'''
import json, socket

PORT = @PROBE_PORT@

def connect():
    return socket.create_connection(("127.0.0.1", PORT), 5)

def session(sock):
    reader = sock.makefile("rb")
    def call(code):
        sock.sendall((json.dumps({"code": code}) + "\n").encode("utf-8"))
        line = reader.readline()
        if not line:
            raise EOFError("connection closed")
        return json.loads(line)
    return call

replies = []
sock = connect()
call = session(sock)
replies.append(call("Object.getOwnPropertyNames(globalThis).join(',')"))
arithmetic = call("1 + 2 * 3")
replies.append(arithmetic)
state_set = call("globalThis.__qjs_runtime_probe = 41")
state_get = call("globalThis.__qjs_runtime_probe + 1")
replies.extend([state_set, state_get])
exception = call("throw new Error('runtime-probe')")
recovery = call("1 + 2")
replies.extend([exception, recovery])
host_apis = call(
    "({require: typeof require, process: typeof process, std: typeof std,"
    " os: typeof os, fs: typeof fs, fetch: typeof fetch,"
    " XMLHttpRequest: typeof XMLHttpRequest,"
    " importScripts: typeof importScripts})")
replies.append(host_apis)
sock.close()

sock2 = connect()
call2 = session(sock2)
separate = call2("typeof globalThis.__qjs_runtime_probe")
replies.append(separate)
sock2.close()

print(json.dumps({
    "arithmetic": arithmetic,
    "state_set": state_set,
    "state_get": state_get,
    "exception": exception,
    "recovery": recovery,
    "host_apis": host_apis,
    "separate_connection": separate,
    "reply_blob": json.dumps(replies),
}))
'''.replace("@PROBE_PORT@", str(port))


def parse_runtime_probe(stdout: str) -> dict:
    try:
        data = json.loads(stdout)
    except json.JSONDecodeError as exc:
        raise RuntimeVerificationError(
            f"runtime probe returned invalid JSON: {exc}") from exc
    if not isinstance(data, dict):
        raise RuntimeVerificationError("runtime probe returned no object")
    return data


ABSENT_HOST_APIS = (
    "require", "process", "std", "os", "fs", "fetch",
    "XMLHttpRequest", "importScripts",
)


def wire_result(reply) -> tuple[bool, object]:
    """Unwrap one adapter wire reply ``{"ok": bool, "result": ...}``.

    The adapter protocol always returns an object; a bare primitive is a
    protocol violation, not a successful result.
    """
    if not isinstance(reply, dict) or "ok" not in reply:
        return False, None
    if reply.get("ok") is not True:
        return False, None
    return True, reply.get("result")


def runtime_probe_checks(probe: dict, flag: str) -> dict:
    hosts_ok, host_apis = wire_result(probe.get("host_apis"))
    if not hosts_ok or not isinstance(host_apis, dict):
        host_apis = {}
    state_set_ok, state_set = wire_result(probe.get("state_set"))
    state_get_ok, state_get = wire_result(probe.get("state_get"))
    separate_ok, separate = wire_result(probe.get("separate_connection"))
    recovery_ok, recovery = wire_result(probe.get("recovery"))
    arithmetic_ok, arithmetic = wire_result(probe.get("arithmetic"))
    exception = probe.get("exception")
    reply_blob = probe.get("reply_blob")
    if not isinstance(reply_blob, str):
        reply_blob = json.dumps(probe)
    return {
        "health_arithmetic": arithmetic_ok and arithmetic == 7,
        "state_persistence": (
            state_set_ok and state_set == 41
            and state_get_ok and state_get == 42),
        "separate_connection_state": separate_ok and separate == "undefined",
        "exception_recovered": (
            isinstance(exception, dict)
            and exception.get("ok") is False
            and recovery_ok and recovery == 3
        ),
        "host_apis_absent": hosts_ok and all(
            host_apis.get(name) == "undefined" for name in ABSENT_HOST_APIS),
        "host_api_values": {name: host_apis.get(name)
                            for name in ABSENT_HOST_APIS},
        "flag_not_in_replies": flag not in reply_blob,
    }


def missing_flag_visible(returncode: int | None, stderr: str) -> bool:
    text = (stderr or "").lower()
    return (returncode == 2 and "flag configuration error" in text
            and "not found" in text)


# ---------------------------------------------------------------------------
# Container configuration checks

def runtime_config_checks(inspect_data: dict) -> dict:
    host = inspect_data.get("HostConfig") or {}
    config = inspect_data.get("Config") or {}
    mounts = inspect_data.get("Mounts") or []
    flag_mount = next(
        (m for m in mounts if m.get("Destination") == FLAG_PATH), None)
    security_opts = host.get("SecurityOpt") or []
    cap_drop = host.get("CapDrop") or []
    ports = host.get("PortBindings") or {}
    return {
        "user": config.get("User"),
        "non_root_config": is_nonroot_user(config.get("User")),
        "network_mode": host.get("NetworkMode"),
        "network_none": host.get("NetworkMode") == "none",
        "privileged": bool(host.get("Privileged")),
        "readonly_rootfs": bool(host.get("ReadonlyRootfs")),
        "cap_drop_all": "ALL" in cap_drop,
        "no_new_privileges": any(
            "no-new-privileges" in str(opt) for opt in security_opts),
        "memory_bytes": host.get("Memory"),
        "nano_cpus": host.get("NanoCpus"),
        "pids_limit": host.get("PidsLimit"),
        "port_bindings_empty": not ports,
        "flag_mount_readonly": bool(flag_mount) and flag_mount.get("RW") is False,
        "flag_mount_present": flag_mount is not None,
    }


def limits_match(checks: dict, cpus: float, memory: str,
                 pids_limit: int) -> bool:
    nano = checks.get("nano_cpus")
    expected_nano = int(cpus * 1_000_000_000)
    memory_bytes = parse_memory_bytes(memory)
    return (
        nano == expected_nano
        and checks.get("memory_bytes") == memory_bytes
        and checks.get("pids_limit") == pids_limit
    )


def _is_missing(stderr: str | None) -> bool:
    """Return true only for explicit engine not-found diagnostics."""
    text = (stderr or "").lower()
    return ("no such" in text or "not found" in text
            or "does not exist" in text)


def parse_memory_bytes(text: str) -> int | None:
    text = text.strip().lower()
    multipliers = {"k": 1024, "m": 1024 ** 2, "g": 1024 ** 3}
    if text and text[-1] in multipliers:
        try:
            return int(float(text[:-1]) * multipliers[text[-1]])
        except ValueError:
            return None
    try:
        return int(text)
    except ValueError:
        return None


# ---------------------------------------------------------------------------
# Main verification flow

class Verification:
    def __init__(self, engine: Engine, args, report: dict):
        self.engine = engine
        self.args = args
        self.report = report
        self.commands: list[dict] = report["commands"]
        self._command_index: dict[tuple, dict] = {}
        self.secret_dir: Path | None = None
        self.container_name: str | None = None
        self.missing_name: str | None = None
        self.helper_names: list[str] = []
        self.flag_value: str | None = None
        self.instance_id = secrets.token_hex(8)
        self.token = secrets.token_hex(6)

    def _redact(self, text) -> str:
        return redact_text(text, self.flag_value)

    def owned_references(self) -> list[str]:
        refs = [self.container_name, self.missing_name, *self.helper_names]
        return [ref for index, ref in enumerate(refs)
                if ref and ref not in refs[:index]]

    def run(self, argv: list[str], name: str, timeout: float | None = None,
            env: dict | None = None,
            retain_output: bool = False) -> subprocess.CompletedProcess:
        print(f"=== {name}: {argv}", file=sys.stderr)
        key = (name, tuple(argv))
        entry = self._command_index.get(key)
        if entry is None:
            entry = {"name": name, "argv": argv}
            self.commands.append(entry)
            self._command_index[key] = entry
        try:
            proc = self.engine.run(argv, timeout=timeout, env=env)
        except subprocess.TimeoutExpired as exc:
            entry["returncode"] = None
            entry["error"] = "timeout"
            raise RuntimeVerificationError(f"{name} timed out") from exc
        entry["returncode"] = proc.returncode
        entry.pop("error", None)
        if retain_output:
            # Retained engine output is redacted at capture time: it must
            # never carry the synthetic flag into a public report.
            entry["stdout_tail"] = self._redact(
                (proc.stdout or "")[-4000:])
            entry["stderr_tail"] = self._redact(
                (proc.stderr or "")[-4000:])
        return proc

    def require(self, argv: list[str], name: str,
                timeout: float | None = None,
                retain_output: bool = False) -> subprocess.CompletedProcess:
        proc = self.run(argv, name, timeout=timeout,
                        retain_output=retain_output)
        if proc.returncode != 0:
            raise RuntimeVerificationError(
                f"{name} failed with exit code {proc.returncode}")
        return proc

    def prepare_flag(self) -> tuple[str, Path]:
        self.secret_dir = Path(tempfile.mkdtemp(prefix="qjs-runtime-flag-"))
        os.chmod(self.secret_dir, 0o700)
        flag = new_flag()
        self.flag_value = flag
        flag_path = self.secret_dir / "flag"
        flag_path.write_bytes((flag + "\n").encode("utf-8"))
        os.chmod(flag_path, 0o444)
        self.report["secret_mount"] = {
            "host_directory_mode": "0700",
            "mounted_file_mode": "0444",
            "read_only_mount": True,
            "note": "The flag value is not recorded; only permissions and "
                    "boolean mount properties are reported.",
        }
        return flag, flag_path

    def build_or_use_image(self) -> str:
        args = self.args
        if args.prebuilt_image:
            self.report["build"] = {
                "status": "skipped",
                "reason": "--prebuilt-image supplied; no build was run",
            }
            return args.prebuilt_image
        tag = f"{args.image_prefix}:phase3a-{self.token}"
        argv = build_argv(
            self.engine.path, tag, args.base_image, args.platform,
            str(ROOT / "Dockerfile"), str(ROOT),
            skip_apt=args.skip_apt, build_network=args.build_network,
            frontend=args.frontend)
        proc = self.require(argv, "build runtime image",
                            retain_output=True)
        self.report["build"] = {
            "status": "executed",
            "target": "runtime",
            "tag": tag,
            "base_image": args.base_image,
            "platform": args.platform,
            "skip_apt": args.skip_apt,
            "build_network": args.build_network or "engine default",
            "frontend": args.frontend or "engine built-in (no syntax fetch)",
            "stdout_tail": (proc.stdout or "")[-2000:],
            "stderr_tail": (proc.stderr or "")[-2000:],
        }
        return tag

    def inspect_images(self, image_ref: str) -> tuple[dict, dict | None]:
        proc = self.require(image_inspect_argv(self.engine.path, image_ref),
                            "inspect runtime image", timeout=300)
        image = parse_image_inspect(proc.stdout)
        base = None
        if self.args.base_image and not self.args.prebuilt_image:
            base_proc = self.require(
                image_inspect_argv(self.engine.path, self.args.base_image),
                "inspect base image", timeout=300)
            base = parse_image_inspect(base_proc.stdout)
        runtime_record = redacted_image_record(image)
        runtime_record["identity_note"] = (
            "Id is the local image identity. RepoDigests is recorded "
            "exactly as the engine reports it and may be empty; no "
            "registry RepoDigest was invented for a locally built image.")
        self.report["images"] = {
            "runtime": runtime_record,
            "base": (redacted_image_record(base) if base else None),
        }
        return image, base

    def scan_image(self, image_ref: str) -> dict:
        # The helper is named and labelled *before* creation so a CLI timeout
        # or lost response still leaves an owned, recoverable reference.
        name = f"{self.args.container_prefix}-scan-{self.token}"
        self.helper_names.append(name)
        argv = [
            self.engine.path, "run",
            "--name", name,
            "--pull=never",
            "--network", "none",
            "--user", "10001:10001",
            "--label", f"{LABEL_INSTANCE}={self.instance_id}",
            "--label", f"{LABEL_ROLE}=scan",
            "--entrypoint", "python3", image_ref, "-c", scan_image_script(),
        ]
        proc = self.run(argv, "scan image filesystem", timeout=300)
        if proc.returncode != 0:
            raise RuntimeVerificationError(
                "in-image secret scan failed; the runtime image must provide "
                "python3 for this check")
        result = parse_scan_result(proc.stdout)
        findings = result.get("findings") or []
        sanitized = {
            "roots": result.get("roots"),
            "files_scanned": result.get("files_scanned"),
            "bytes_scanned": result.get("bytes_scanned"),
            # The scan is deliberately bounded and this is reported so a
            # partial scan is never presented as exhaustive.
            "bounded": True,
            "max_files": result.get("max_files"),
            "max_file_bytes": result.get("max_file_bytes"),
            "files_limit_reached": bool(result.get("files_limit_reached")),
            "skipped_oversized_files": result.get("skipped_oversized_files"),
            "finding_count": len(findings),
            "finding_patterns": sorted({
                finding.get("pattern") for finding in findings
                if isinstance(finding, dict)}),
            "flag_path_exists": result.get("flag_path_exists"),
            "status": "clean" if (
                not findings and not result.get("flag_path_exists")
            ) else "finding",
        }
        self.report["baked_in_secret_scan"] = sanitized
        return sanitized

    def start_runtime(self, image_ref: str, flag_path: Path) -> str:
        name = f"{self.args.container_prefix}-{self.token}"
        self.container_name = name
        argv = runtime_container_argv(
            self.engine.path, name, image_ref, self.args.platform,
            self.instance_id, cpus=self.args.cpus, memory=self.args.memory,
            pids_limit=self.args.pids_limit, flag_host_path=str(flag_path))
        proc = self.require(argv, "start runtime container", timeout=300)
        return proc.stdout.strip() or name

    def wait_health(self, name: str) -> None:
        deadline = time.monotonic() + self.args.startup_timeout
        last = "no probe"
        while time.monotonic() < deadline:
            proc = self.run(
                exec_argv(self.engine.path, name,
                          ["python3", "-c", health_script()]),
                "runtime health probe", timeout=15)
            if proc.returncode == 0 and "HEALTH_OK" in (proc.stdout or ""):
                return
            state = self.run(
                container_inspect_argv(self.engine.path, name),
                "runtime state probe", timeout=15)
            if state.returncode == 0:
                try:
                    data = json.loads(state.stdout)
                except json.JSONDecodeError:
                    data = {}
                if not (data.get("State") or {}).get("Running", False):
                    last = ("container exited with code "
                            f"{(data.get('State') or {}).get('ExitCode')}")
                    break
            last = "health probe did not return 2"
            time.sleep(0.1)
        raise RuntimeVerificationError(f"runtime health check failed: {last}")

    def run_probes(self, name: str, flag: str) -> dict:
        proc = self.require(
            exec_argv(self.engine.path, name,
                      ["python3", "-c", runtime_probe_script()]),
            "runtime service probes", timeout=60)
        probe = parse_runtime_probe(proc.stdout)
        checks = runtime_probe_checks(probe, flag)

        uid_proc = self.require(
            exec_argv(self.engine.path, name,
                      ["python3", "-c",
                       "import os; print(os.getuid(), os.getgid())"]),
            "runtime uid probe", timeout=15)
        try:
            uid_text = uid_proc.stdout.strip().split()
            uid, gid = int(uid_text[0]), int(uid_text[1])
        except (IndexError, ValueError) as exc:
            raise RuntimeVerificationError(
                "runtime uid probe returned an unexpected value") from exc
        checks["uid"] = uid
        checks["gid"] = gid
        checks["non_root_runtime"] = uid != 0

        logs = self.run([self.engine.path, "logs", name],
                        "runtime logs", timeout=30)
        log_text = (logs.stdout or "") + (logs.stderr or "")
        logs_read_ok = logs.returncode == 0
        # A failed log read cannot prove the flag was absent from the logs.
        checks["logs_read_ok"] = logs_read_ok
        checks["log_read_failed"] = not logs_read_ok
        checks["flag_not_in_logs"] = logs_read_ok and flag not in log_text
        checks["log_bytes"] = len(log_text.encode("utf-8", errors="replace"))
        self.report["runtime"]["probes"] = checks
        return checks

    def check_missing_flag(self, image_ref: str, flag: str) -> dict:
        name = f"{self.args.container_prefix}-missing-{self.token}"
        self.missing_name = name
        argv = runtime_container_argv(
            self.engine.path, name, image_ref, self.args.platform,
            self.instance_id, cpus=self.args.cpus, memory=self.args.memory,
            pids_limit=self.args.pids_limit, flag_host_path=None,
            detach=False)
        # docker run --rm plus the image command that points at the fixed
        # flag path.  The adapter must exit 2 with a configuration error.
        try:
            proc = self.run(argv, "missing-flag control", timeout=60)
        except RuntimeVerificationError:
            self.remove_exact(name)
            self.report["missing_flag"] = {
                "visible_failure": False,
                "timed_out": True,
            }
            return self.report["missing_flag"]
        visible = missing_flag_visible(proc.returncode, proc.stderr)
        flag_absent = (flag not in (proc.stderr or ""))
        result = {
            "visible_failure": visible,
            "exit_code": proc.returncode,
            "reported_configuration_error": (
                "flag configuration error" in (proc.stderr or "").lower()),
            "flag_not_in_stderr": flag_absent,
            "timed_out": False,
        }
        self.report["missing_flag"] = result
        return result

    def remove_exact(self, reference: str) -> dict:
        try:
            proc = self.engine.run(remove_argv(self.engine.path, reference),
                                   timeout=60)
        except (OSError, subprocess.SubprocessError) as exc:
            return {"reference": reference, "returncode": None,
                    "error": self._redact(f"engine failure: {exc}")[:300]}
        missing = _is_missing(proc.stderr)
        return {"reference": reference, "returncode": proc.returncode,
                "confirmed_not_found": missing,
                "stderr_tail": self._redact((proc.stderr or "")[-500:])}

    def cleanup(self) -> dict:
        """Best-effort removal of every owned resource and the secret dir.

        A failure or timeout for one reference never skips the rest.  A
        confirmed not-found is not an error; any other engine failure is.
        """
        errors: list[dict] = []
        confirmed_absent: list[str] = []
        for reference in self.owned_references():
            try:
                proc = self.engine.run(
                    remove_argv(self.engine.path, reference), timeout=60)
            except (OSError, subprocess.SubprocessError) as exc:
                errors.append({
                    "reference": reference,
                    "returncode": None,
                    "error": self._redact(
                        f"cleanup engine failure: {exc}")[:300],
                })
                continue
            if proc.returncode == 0:
                continue
            if _is_missing(proc.stderr):
                confirmed_absent.append(reference)
                continue
            errors.append({
                "reference": reference,
                "returncode": proc.returncode,
                "error": self._redact((proc.stderr or "")[-300:]),
            })
        # Always attempt local secret removal, independent of engine state.
        if self.secret_dir is not None:
            try:
                shutil.rmtree(self.secret_dir, ignore_errors=True)
            except OSError as exc:
                errors.append({"reference": "<secret-dir>",
                               "returncode": None,
                               "error": self._redact(
                                   f"secret removal error: {exc}")[:300]})
            if self.secret_dir.exists():
                errors.append({"reference": "<secret-dir>",
                               "returncode": None,
                               "error": "secret directory still exists"})
            else:
                self.secret_dir = None
        return {"ok": not errors, "errors": errors,
                "confirmed_absent": confirmed_absent}

    def cleanup_verified(self) -> dict:
        result = self.cleanup()
        still_present = []
        inspection_errors = []
        confirmed_absent = list(result.get("confirmed_absent") or [])
        for reference in self.owned_references():
            try:
                proc = self.engine.run(
                    container_inspect_argv(self.engine.path, reference),
                    timeout=30)
            except (OSError, subprocess.SubprocessError) as exc:
                # A timeout/transport failure is unknown, not proof of absence.
                inspection_errors.append({
                    "reference": reference,
                    "error": self._redact(
                        f"inspection engine failure: {exc}")[:300],
                })
                continue
            if proc.returncode == 0:
                still_present.append(reference)
            elif _is_missing(proc.stderr):
                if reference not in confirmed_absent:
                    confirmed_absent.append(reference)
            else:
                inspection_errors.append({
                    "reference": reference,
                    "error": self._redact((proc.stderr or "")[-300:]),
                })
        result["owned_containers_absent"] = (
            not still_present and not inspection_errors)
        result["still_present"] = still_present
        result["inspection_errors"] = inspection_errors
        result["confirmed_absent"] = confirmed_absent
        result["ok"] = (result["ok"] and not still_present
                        and not inspection_errors)
        return result


def evaluate_required(report: dict) -> tuple[bool, list[str]]:
    failures = []
    image = report.get("images", {}).get("runtime") or {}
    build_checks = report.get("image_checks") or {}
    runtime_checks = (report.get("runtime") or {}).get("probes") or {}
    config = (report.get("runtime") or {}).get("config") or {}
    scan = report.get("baked_in_secret_scan") or {}
    missing = report.get("missing_flag") or {}
    cleanup = report.get("cleanup") or {}

    if image.get("Architecture") not in ("amd64", "x86_64"):
        failures.append("runtime image architecture is not amd64")
    if image.get("Os") not in (None, "linux"):
        failures.append("runtime image OS is not linux")
    base = report.get("images", {}).get("base")
    if base and base.get("Architecture") not in ("amd64", "x86_64"):
        failures.append("base image architecture is not amd64")
    if not build_checks.get("non_root_user"):
        failures.append("image user is root or unset")
    if not build_checks.get("expected_command"):
        failures.append(
            "image command does not match the image default CMD")
    if not build_checks.get("entrypoint_empty"):
        failures.append("image defines an unexpected entrypoint")
    if build_checks.get("env_has_flag_variable"):
        failures.append("image environment defines the flag variable")
    if build_checks.get("env_has_flag_literal") or \
            build_checks.get("command_has_flag_literal") or \
            build_checks.get("env_has_synthetic_flag") or \
            build_checks.get("command_has_synthetic_flag"):
        failures.append("flag-like content found in image config")
    if build_checks.get("has_image_volumes"):
        failures.append(
            "image defines writable VOLUMEs that --read-only does not cover")
    if scan.get("status") != "clean":
        failures.append("image file scan found a baked-in flag-like secret")
    if not runtime_checks.get("health_arithmetic"):
        failures.append("runtime arithmetic/health probe failed")
    if not runtime_checks.get("state_persistence"):
        failures.append("runtime state persistence probe failed")
    if not runtime_checks.get("separate_connection_state"):
        failures.append("runtime connection isolation probe failed")
    if not runtime_checks.get("exception_recovered"):
        failures.append("runtime exception recovery probe failed")
    if not runtime_checks.get("host_apis_absent"):
        failures.append("ordinary host APIs are visible to JavaScript")
    if not runtime_checks.get("flag_not_in_replies"):
        failures.append("flag value appeared in a normal reply")
    if not runtime_checks.get("logs_read_ok"):
        failures.append("runtime logs could not be read; disclosure unverified")
    if not runtime_checks.get("flag_not_in_logs"):
        failures.append("flag value appeared in container logs")
    if not runtime_checks.get("non_root_runtime"):
        failures.append("runtime process uid is 0")
    if config.get("network_none") is not True:
        failures.append("runtime network mode is not none")
    if config.get("privileged"):
        failures.append("runtime container is privileged")
    if not config.get("readonly_rootfs"):
        failures.append("runtime root filesystem is writable")
    if not config.get("cap_drop_all"):
        failures.append("runtime capabilities were not dropped")
    if not config.get("no_new_privileges"):
        failures.append("runtime no-new-privileges is not set")
    if not config.get("port_bindings_empty"):
        failures.append("runtime container published a host port")
    if not config.get("flag_mount_readonly"):
        failures.append("runtime flag mount is not read-only")
    if not report.get("limits_match"):
        failures.append("runtime CPU/memory/PID limits do not match the request")
    if not missing.get("visible_failure"):
        failures.append("missing flag file did not fail visibly")
    if not missing.get("flag_not_in_stderr", False):
        failures.append("flag value appeared in the missing-flag output")
    if not cleanup.get("ok"):
        failures.append("cleanup did not complete")
    if not cleanup.get("owned_containers_absent"):
        failures.append("owned containers remain after cleanup")
    return not failures, failures


def write_report(report: dict, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report, indent=2) + "\n")
    print(f"verify-runtime: {report['status']} -> {path}")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--engine",
                        help="container engine path/name (docker, podman, ...)")
    parser.add_argument("--base-image",
                        help="operator-supplied pinned base image reference "
                             "(required unless --prebuilt-image)")
    parser.add_argument("--prebuilt-image",
                        help="verify this existing local runtime image instead "
                             "of building; implies offline mode")
    parser.add_argument("--platform", default="linux/amd64",
                        help="expected target platform (default linux/amd64)")
    parser.add_argument("--cpus", type=float, default=2.0)
    parser.add_argument("--memory", default="2g")
    parser.add_argument("--pids-limit", type=int, default=64)
    parser.add_argument("--startup-timeout", type=float, default=20.0)
    parser.add_argument("--image-prefix", default="qjs-ctf-runtime",
                        help="prefix for the locally built runtime image tag")
    parser.add_argument("--container-prefix", default="qjs-runtime-check",
                        help="owned container-name prefix")
    parser.add_argument("--skip-apt", action="store_true",
                        help="build with SKIP_APT=1; the base image must "
                             "already contain the dependencies")
    parser.add_argument("--build-network",
                        help="explicit docker build --network value "
                             "(e.g. none for an offline pre-provisioned base)")
    parser.add_argument("--frontend",
                        help="explicit pinned/mirrored Dockerfile frontend "
                             "reference passed as BUILDKIT_SYNTAX; omitted "
                             "means the engine built-in frontend")
    parser.add_argument("--report", default=str(DEFAULT_REPORT))
    args = parser.parse_args()

    if args.platform != "linux/amd64":
        parser.error("this verifier only accepts --platform linux/amd64")
    if args.cpus <= 0:
        parser.error("--cpus must be positive")
    if args.pids_limit < 1:
        parser.error("--pids-limit must be >= 1")
    if not args.prebuilt_image and not args.base_image:
        parser.error("--base-image is required unless --prebuilt-image is used")

    report = {
        "schema_version": 1,
        "kind": "qjs-ctf-runtime-verification",
        "started_at_utc": utc_now(),
        "status": "running",
        "host": {
            "platform": platform.system(),
            "release": platform.release(),
            "machine": platform.machine(),
        },
        "requested": {
            "base_image": args.base_image,
            "prebuilt_image": args.prebuilt_image,
            "platform": args.platform,
            "cpus": args.cpus,
            "memory": args.memory,
            "pids_limit": args.pids_limit,
            "skip_apt": args.skip_apt,
            "build_network": args.build_network or "engine default",
            "frontend": args.frontend or "engine built-in",
        },
        "scope": "runtime image build/run/smoke verification only; challenge "
                 "solvability and formal multi-tenant isolation are separate",
        "engine": None,
        "build": {"status": "not-run"},
        "images": {},
        "image_checks": None,
        "baked_in_secret_scan": None,
        "runtime": {
            "container_id": None,
            "config": None,
            "probes": None,
        },
        "limits_match": None,
        "missing_flag": None,
        "cleanup": None,
        "boundary": {
            "status": "not-evaluated",
            "reason": "Target/solver container boundary probes are "
                      "implemented in evaluator/container_controller.py "
                      "--boundary-check and are reported separately.",
            "isolated_evaluation": {
                "status": "not-run",
                "isolation_gate": {"status": "pending"},
            },
        },
        "commands": [],
        "limitations": [
            "Containers share the host kernel. This is a controlled CTF "
            "evaluation boundary, not proof of resistance to kernel escape.",
            "The baked-in secret scan is a bounded file-content scan of /app "
            "and /run/secrets, not a proof about every layer or package.",
        ],
        "solvability": {
            "status": "pending",
            "reason": "This verifier does not contain or run a reference "
                      "solution. Runtime-image health is not challenge "
                      "solvability.",
        },
    }
    report_path = Path(args.report)

    engine_path, diagnostics = find_engine(args.engine)
    if not engine_path:
        report["status"] = "skipped"
        report["finished_at_utc"] = utc_now()
        report["engine"] = {"path": None, "diagnostics": diagnostics}
        report["build"] = {"status": "skipped",
                           "reason": "no container engine available"}
        report["runtime"]["status"] = "skipped"
        report["limitations"].append(
            "No container engine was available; nothing was built or run.")
        write_report(report, report_path)
        print("verify-runtime: no container engine available; nothing was run",
              file=sys.stderr)
        return 2

    engine = Engine(engine_path)
    report["engine"] = {"path": engine_path, "version": engine.version(),
                        "diagnostics": diagnostics}
    verification = Verification(engine, args, report)
    image_ref = None
    try:
        image_ref = verification.build_or_use_image()
        image, _base = verification.inspect_images(image_ref)
        checks = image_security_summary(image)
        report["image_checks"] = checks
        if checks.get("has_image_volumes"):
            # Reject before starting the scan or service container: --read-only
            # does not cover an image-declared VOLUME, which becomes a
            # writable anonymous volume at run time.
            raise RuntimeVerificationError(
                "runtime image declares writable VOLUME paths "
                f"{checks.get('image_volumes')}; refusing to run it")
        scan = verification.scan_image(image_ref)
        if scan.get("status") != "clean":
            raise RuntimeVerificationError(
                "baked-in secret scan found flag-like content")
        flag, flag_path = verification.prepare_flag()
        container_id = verification.start_runtime(image_ref, flag_path)
        report["runtime"]["container_id"] = container_id
        verification.wait_health(verification.container_name)
        verification.run_probes(verification.container_name, flag)
        inspect_proc = verification.require(
            container_inspect_argv(engine.path, verification.container_name),
            "inspect runtime container", timeout=60)
        try:
            inspect_data = json.loads(inspect_proc.stdout)
        except json.JSONDecodeError as exc:
            raise RuntimeVerificationError(
                f"container inspect returned invalid JSON: {exc}") from exc
        config_checks = runtime_config_checks(inspect_data)
        report["runtime"]["config"] = config_checks
        report["limits_match"] = limits_match(
            config_checks, args.cpus, args.memory, args.pids_limit)
        verification.check_missing_flag(image_ref, flag)
    except (RuntimeVerificationError, subprocess.SubprocessError,
            OSError, ValueError) as exc:
        # Preserve the primary failure text, redacted before it is public.
        report["error"] = verification._redact(str(exc))
        print(f"verify-runtime: {exc}", file=sys.stderr)
    finally:
        # Cleanup must never suppress the primary failure or the report.
        try:
            report["cleanup"] = verification.cleanup_verified()
        except Exception as exc:  # noqa: BLE001 - always write a report
            report["cleanup"] = {
                "ok": False,
                "errors": [{
                    "reference": "<cleanup>",
                    "error": verification._redact(str(exc))[:300],
                }],
                "owned_containers_absent": False,
            }
        report["finished_at_utc"] = utc_now()

    ok, failures = evaluate_required(report)
    report["failures"] = failures
    report["status"] = "passed" if ok else "failed"
    # Final defense in depth: no synthetic flag or flag-like literal may
    # reach the serialized public report by any path.
    report = redact_value(report, verification.flag_value)
    write_report(report, report_path)
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
