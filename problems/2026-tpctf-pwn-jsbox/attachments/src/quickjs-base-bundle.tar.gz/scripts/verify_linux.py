#!/usr/bin/env python3
"""One-entrypoint Linux verification for the QuickJS CTF baseline.

Run this inside an already-existing Ubuntu 24.04 x86-64 container (or on such a
host).  It builds, verifies the pinned source, runs the full test suite, and
runs the repeated build-timing suite.  Any failed stage makes the process exit
non-zero and is recorded in a machine-readable JSON report.

This is intentionally a local verification harness, not a cloud orchestrator.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import shutil
import subprocess
import sys
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
BUILD = ROOT / "build"
REPORTS = ROOT / "reports"
DEFAULT_REPORT = REPORTS / "verify-linux-report.json"
DEFAULT_TIMINGS_JSON = BUILD / "linux-build-timings.json"
DEFAULT_TIMINGS_MD = BUILD / "linux-build-timings.md"


class StageFailure(RuntimeError):
    def __init__(self, name: str, returncode: int):
        super().__init__(f"stage {name} failed with exit code {returncode}")
        self.name = name
        self.returncode = returncode


def find_make() -> str:
    candidates = [
        os.environ.get("MAKE"),
        shutil.which("make"),
        "/Library/Developer/CommandLineTools/usr/bin/make",
    ]
    seen = set()
    for candidate in candidates:
        if not candidate or candidate in seen:
            continue
        seen.add(candidate)
        if not Path(candidate).is_file():
            continue
        probe = subprocess.run([candidate, "--version"],
                               capture_output=True, text=True)
        if probe.returncode == 0:
            return candidate
    raise SystemExit("verify-linux: no working make found; set MAKE")


def os_release() -> dict:
    path = Path("/etc/os-release")
    if not path.is_file():
        return {}
    data = {}
    for line in path.read_text(errors="replace").splitlines():
        if "=" not in line:
            continue
        key, value = line.split("=", 1)
        data[key] = value.strip().strip('"')
    return data


def command_version(argv: list[str]) -> str:
    probe = subprocess.run(argv, capture_output=True, text=True)
    lines = (probe.stdout or probe.stderr).strip().splitlines()
    return lines[0] if lines else "unknown"


def package_versions() -> dict:
    if not shutil.which("dpkg-query"):
        return {}
    names = ["build-essential", "gcc", "make", "xz-utils", "python3"]
    versions = {}
    for name in names:
        probe = subprocess.run(
            ["dpkg-query", "-W", "-f=${Status} ${Version}",
             name], capture_output=True, text=True)
        text = probe.stdout.strip()
        if probe.returncode == 0 and text:
            versions[name] = text
    return versions


def host_environment() -> dict:
    release = os_release()
    return {
        "platform": platform.system(),
        "release": platform.release(),
        "machine": platform.machine(),
        "processor": platform.processor(),
        "python": platform.python_version(),
        "os_release": release,
        "logical_cpus": os.cpu_count(),
    }


def target_mismatches(host: dict) -> list[str]:
    mismatches = []
    if not (host["platform"] == "Linux"):
        mismatches.append(f"platform is {host['platform']}, expected Linux")
    if host["machine"] not in ("x86_64", "amd64"):
        mismatches.append(f"architecture is {host['machine']}, expected x86_64")
    release = host.get("os_release") or {}
    if not (release.get("ID") == "ubuntu"):
        mismatches.append(
            f"distribution ID is {release.get('ID')}, expected ubuntu")
    if not (release.get("VERSION_ID") == "24.04"):
        mismatches.append(
            f"distribution version is {release.get('VERSION_ID')}, "
            "expected 24.04")
    return mismatches


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def run_clean_build(make: str, jobs: int, env, report: dict) -> None:
    """Remove every prior object, then build with the requested compiler.

    The clean stage is explicit so an incremental build cannot mix objects
    compiled by a different compiler or with different flags.
    """
    run_stage("clean", [make, "clean"], env=env, report=report)
    run_stage("build", [make, f"-j{jobs}", "runner"], env=env, report=report)


class TestedArtifact:
    """Keep the final runner identical to the binary the tests exercised."""

    def __init__(self, binary: Path):
        self.binary = Path(binary)
        self.tested_sha256 = sha256_file(self.binary)
        self._tempdir = Path(tempfile.mkdtemp(prefix="qjs-tested-artifact-"))
        self._preserved = self._tempdir / self.binary.name
        shutil.copy2(self.binary, self._preserved)

    def ensure_final(self) -> dict:
        final_sha256 = (sha256_file(self.binary)
                        if self.binary.is_file() else None)
        record = {
            "tested_runner_sha256": self.tested_sha256,
            "post_timing_runner_sha256": final_sha256,
            "final_runner_sha256": final_sha256,
            "restored_tested_artifact": False,
        }
        if final_sha256 != self.tested_sha256:
            # The timing stage rebuilds the binary.  Restore the exact binary
            # that the test stage ran so the reported artifact is honest.
            shutil.copy2(self._preserved, self.binary)
            restored = sha256_file(self.binary)
            if restored != self.tested_sha256:
                raise RuntimeError(
                    "could not restore the tested runner artifact")
            record["final_runner_sha256"] = restored
            record["restored_tested_artifact"] = True
        return record

    def close(self) -> None:
        shutil.rmtree(self._tempdir, ignore_errors=True)


def print_stage_output(name: str, stdout: str, stderr: str) -> None:
    print(f"--- stage {name} stdout ---", file=sys.stderr)
    if stdout:
        sys.stderr.write(stdout)
        if not stdout.endswith("\n"):
            sys.stderr.write("\n")
    print(f"--- stage {name} stderr ---", file=sys.stderr)
    if stderr:
        sys.stderr.write(stderr)
        if not stderr.endswith("\n"):
            sys.stderr.write("\n")
    sys.stderr.flush()


def run_stage(name: str, argv: list[str], env=None,
              report=None) -> dict:
    print(f"=== stage {name}: {argv}", file=sys.stderr)
    start = time.perf_counter()
    proc = subprocess.run(argv, cwd=ROOT, env=env, capture_output=True,
                          text=True)
    duration = round(time.perf_counter() - start, 3)
    print_stage_output(name, proc.stdout, proc.stderr)
    record = {
        "name": name,
        "argv": argv,
        "returncode": proc.returncode,
        "duration_s": duration,
        "stdout_tail": proc.stdout[-4000:],
        "stderr_tail": proc.stderr[-4000:],
    }
    if report is not None:
        report["stages"].append(record)
    if not (proc.returncode == 0):
        raise StageFailure(name, proc.returncode)
    return record


def read_timings(path: Path) -> dict | None:
    if not path.is_file():
        return None
    try:
        return json.loads(path.read_text())
    except (OSError, json.JSONDecodeError):
        return None


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=int, default=3,
                        help="repeated timing runs (default 3)")
    parser.add_argument("--jobs", type=int, default=1,
                        help="parallel make jobs (default 1)")
    parser.add_argument("--cc", default=os.environ.get("CC", "cc"))
    parser.add_argument("--report", default=str(DEFAULT_REPORT))
    parser.add_argument("--timings-json", default=str(DEFAULT_TIMINGS_JSON))
    parser.add_argument("--timings-markdown", default=str(DEFAULT_TIMINGS_MD))
    parser.add_argument("--allow-non-target", action="store_true",
                        help="run on a non-Ubuntu-24.04/x86_64 host, recording "
                             "the mismatch as a limitation")
    args = parser.parse_args()
    if args.runs < 1:
        parser.error("--runs must be >= 1")
    if args.jobs < 1:
        parser.error("--jobs must be >= 1")

    started = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    host = host_environment()
    mismatches = target_mismatches(host)
    report = {
        "schema_version": 1,
        "kind": "qjs-ctf-linux-verification",
        "started_at_utc": started,
        "host": host,
        "target": {"os": "Ubuntu 24.04", "arch": "x86_64"},
        "target_mismatches": mismatches,
        "allow_non_target": args.allow_non_target,
        "stages": [],
        "timings": None,
        "status": "running",
        "limitations": [],
    }

    failure = None
    try:
        if mismatches and not args.allow_non_target:
            report["stages"].append({
                "name": "environment",
                "argv": [],
                "returncode": 2,
                "duration_s": 0.0,
                "stdout_tail": "",
                "stderr_tail": "; ".join(mismatches),
            })
            report["limitations"].append(
                "Host does not match the Ubuntu 24.04 x86-64 target.")
            raise StageFailure("environment", 2)
        if mismatches:
            report["limitations"].append(
                "Ran with --allow-non-target; host mismatches: "
                + "; ".join(mismatches))
        report["stages"].append({
            "name": "environment",
            "argv": [],
            "returncode": 0,
            "duration_s": 0.0,
            "stdout_tail": "",
            "stderr_tail": "",
        })

        make = find_make()
        env = dict(os.environ)
        env["CC"] = args.cc
        report["toolchain"] = {
            "make": {"path": make,
                     "version": command_version([make, "--version"])},
            "compiler": {"command": args.cc,
                         "version": command_version([args.cc, "--version"])},
            "python": platform.python_version(),
            "packages": package_versions(),
        }

        run_stage("source_pin",
                  [sys.executable, str(ROOT / "scripts" / "verify_pin.py")],
                  env=env, report=report)
        run_clean_build(make, args.jobs, env, report)
        artifact_guard = None
        try:
            artifact_guard = TestedArtifact(BUILD / "qjs_runner")
            report["artifacts"] = {
                "tested_runner_sha256": artifact_guard.tested_sha256,
            }
            run_stage("tests",
                      [sys.executable, "-m", "unittest", "discover",
                       "-s", "tests", "-v"],
                      env=env, report=report)
            run_stage("timings",
                      [sys.executable,
                       str(ROOT / "scripts" / "bench_build.py"),
                       "--runs", str(args.runs), "--jobs", str(args.jobs),
                       "--cc", args.cc,
                       "--json", args.timings_json,
                       "--markdown", args.timings_markdown],
                      env=env, report=report)
            report["timings"] = read_timings(Path(args.timings_json))
            artifact_record = artifact_guard.ensure_final()
            report["artifacts"].update(artifact_record)
            if artifact_record["restored_tested_artifact"]:
                report["limitations"].append(
                    "The timing stage rebuilt build/qjs_runner with a "
                    "different hash; the exact tested binary was restored as "
                    "the final artifact.")
        finally:
            if artifact_guard is not None:
                artifact_guard.close()
    except StageFailure as exc:
        failure = exc
        report["limitations"].append(str(exc))
        print(f"STAGE FAILED: {exc.name} (exit {exc.returncode})",
              file=sys.stderr)
    except Exception as exc:  # noqa: BLE001 - report any harness failure
        failure = exc
        report["limitations"].append(f"harness error: {exc}")
        print(f"HARNESS ERROR: {exc}", file=sys.stderr)

    report["finished_at_utc"] = datetime.now(timezone.utc).strftime(
        "%Y-%m-%dT%H:%M:%SZ")
    report["status"] = "failed" if failure is not None else "passed"
    report_path = Path(args.report)
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, indent=2) + "\n")
    print(f"verify-linux: {report['status']} -> {report_path}")
    print(json.dumps({"status": report["status"],
                      "report": str(report_path),
                      "stages": [stage["name"] for stage in report["stages"]],
                      "target_mismatches": mismatches}))
    return 0 if failure is None else 1


if __name__ == "__main__":
    raise SystemExit(main())
