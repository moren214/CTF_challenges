#!/usr/bin/env python3
"""Measure native cold, no-op, and core-touch incremental build times.

The pinned archive is vendored and its SHA-256 is verified before timing, so
no download or extraction time is counted as compilation.

Each run performs three independent measurements:
  * cold: after `make clean`, compile every object and link;
  * no-op: immediately invoke make again with nothing changed;
  * core-touch: update quickjs.c's mtime, then recompile quickjs.o and relink.

Timestamps of the touched source are restored in a finally block.  This script
measures local compile/link throughput only.  It is not evidence that a
two-hour challenge-authoring workflow is achievable.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import shutil
import statistics
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
BUILD = ROOT / "build"
QJS_CORE = ROOT / "third_party" / "quickjs" / "src" / "quickjs.c"
DEFAULT_RUNS = 3


def find_make() -> str:
    candidates = [
        os.environ.get("MAKE"),
        shutil.which("make"),
        "/Library/Developer/CommandLineTools/usr/bin/make",
    ]
    seen = set()
    for candidate in candidates:
        if not candidate or candidate in seen:
            continue
        seen.add(candidate)
        if not Path(candidate).is_file():
            continue
        probe = subprocess.run([candidate, "--version"], capture_output=True,
                               text=True)
        if probe.returncode == 0:
            return candidate
    raise SystemExit("bench: no working make found; set MAKE=/path/to/make")


def run(cmd, label: str, env=None) -> None:
    result = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True,
                            env=env)
    if not (result.returncode == 0):
        sys.stderr.write(f"bench: {label} failed ({result.returncode})\n")
        sys.stderr.write(result.stdout)
        sys.stderr.write(result.stderr)
        raise SystemExit(result.returncode)


def timed(cmd, label: str, env=None) -> float:
    start = time.perf_counter()
    run(cmd, label, env=env)
    return time.perf_counter() - start


def first_line(stdout: str, stderr: str) -> str:
    lines = (stdout or stderr).splitlines()
    return lines[0] if lines else "unknown"


def compiler_info(cc: str) -> dict:
    probe = subprocess.run([cc, "--version"], capture_output=True, text=True)
    version_lines = (probe.stdout or probe.stderr).strip().splitlines()
    machine = subprocess.run([cc, "-dumpmachine"], capture_output=True,
                             text=True)
    return {
        "cc": cc,
        "version": version_lines[0] if version_lines else "unknown",
        "version_lines": version_lines,
        "target_machine": (machine.stdout.strip()
                           if machine.returncode == 0
                           else "unknown"),
    }


def make_info(make: str) -> dict:
    probe = subprocess.run([make, "--version"], capture_output=True, text=True)
    return {
        "path": make,
        "version": first_line(probe.stdout, probe.stderr),
    }


def os_release() -> dict | None:
    path = Path("/etc/os-release")
    if not path.is_file():
        return None
    data = {}
    for line in path.read_text(errors="replace").splitlines():
        if "=" not in line:
            continue
        key, value = line.split("=", 1)
        data[key] = value.strip().strip('"')
    return {
        key: data.get(key)
        for key in ("ID", "VERSION_ID", "PRETTY_NAME", "VERSION")
        if data.get(key)
    }


def cpu_quota() -> dict | None:
    """Report cgroup CPU quota when the host exposes it."""
    v2 = Path("/sys/fs/cgroup/cpu.max")
    if v2.is_file():
        parts = v2.read_text().split()
        if len(parts) == 2 and parts[0] not in ("max", "-1"):
            quota, period = int(parts[0]), int(parts[1])
            if period > 0:
                return {"cgroup": "v2", "quota_us": quota,
                        "period_us": period,
                        "cores": round(quota / period, 3)}
    quota_path = Path("/sys/fs/cgroup/cpu/cpu.cfs_quota_us")
    period_path = Path("/sys/fs/cgroup/cpu/cpu.cfs_period_us")
    if quota_path.is_file() and period_path.is_file():
        quota = int(quota_path.read_text().strip())
        period = int(period_path.read_text().strip())
        if quota > 0 and period > 0:
            return {"cgroup": "v1", "quota_us": quota, "period_us": period,
                    "cores": round(quota / period, 3)}
    return None


def host_info() -> dict:
    uname = platform.uname()
    affinity = None
    if hasattr(os, "sched_getaffinity"):
        try:
            affinity = len(os.sched_getaffinity(0))
        except OSError:
            affinity = None
    return {
        "system": uname.system,
        "release": uname.release,
        "machine": uname.machine,
        "processor": uname.processor,
        "mac_version": platform.mac_ver()[0] or None,
        "distribution": os_release(),
        "python": platform.python_version(),
        "logical_cpus": os.cpu_count(),
        "affinity_cpus": affinity,
        "cpu_quota": cpu_quota(),
    }


def actual_flags(make: str, env) -> dict:
    probe = subprocess.run([make, "-s", "print-flags"], cwd=ROOT,
                           capture_output=True, text=True, env=env)
    if not (probe.returncode == 0):
        return {"error": probe.stderr.strip() or "make print-flags failed"}
    flags = {}
    for line in probe.stdout.splitlines():
        if "=" in line:
            key, value = line.split("=", 1)
            flags[key] = value
    return flags


def touch_quickjs_core() -> None:
    """Make quickjs.c strictly newer than build artifacts.

    Some make/filesystem combinations compare timestamps at one-second
    resolution.  A bare utime(now) can therefore leave a freshly built object
    looking newer than the source and produce a false no-op sample.
    """
    newest = 0.0
    if BUILD.is_dir():
        for path in BUILD.rglob("*"):
            if path.is_file():
                newest = max(newest, path.stat().st_mtime)
    target = max(time.time(), newest + 2.0)
    os.utime(QJS_CORE, (target, target))


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def summarize(samples: list[float]) -> dict:
    return {
        "samples_s": [round(value, 6) for value in samples],
        "median_s": round(statistics.median(samples), 6),
        "max_s": round(max(samples), 6),
        "min_s": round(min(samples), 6),
        "count": len(samples),
    }


def markdown_report(record: dict) -> str:
    summary = record["timings"]
    host = record["host"]
    distro = host.get("distribution") or {}
    distro_text = distro.get("PRETTY_NAME") or host["system"]
    quota = host.get("cpu_quota")
    quota_text = (f"{quota['cores']} core(s) via cgroup {quota['cgroup']}"
                  if quota else "not observable")
    rows = "\n".join(
        f"| {name} | {data['median_s']:.3f} s | "
        f"{data['max_s']:.3f} s | {data['samples_s']} |"
        for name, data in (
            ("Cold build (`make clean` then build)", summary["cold"]),
            ("No-op build (nothing changed)", summary["noop"]),
            ("Core-touch incremental (`touch quickjs.c`)",
             summary["core_touch_incremental"]),
        )
    )
    return f"""# Native build timings

Measured {record['measured_at_utc']} with `make -j{record['jobs']}`,
{record['runs']} run(s). The pinned QuickJS archive was verified by SHA-256
before timing; download and extraction time is **not** included, and no LTO is
used. Source timestamps were restored after the run.

| Field | Value |
| --- | --- |
| Host | {host['system']} {host['release']} ({host['machine']}) |
| Distribution | {distro_text} |
| CPU quota | {quota_text} |
| Compiler | {record['compiler']['version']} |
| Compiler target | {record['compiler']['target_machine']} |
| Make | {record['make']['version']} (`{record['make']['path']}`) |
| Jobs | {record['jobs']} |
| Runs | {record['runs']} |

| Measurement | Median | Maximum | Raw samples (s) |
| --- | --- | --- | --- |
{rows}

Actual make variables recorded for this run:

```json
{json.dumps(record['flags'], indent=2, sort_keys=True)}
```

Scope: **native {host['system']} {host['machine']} only**. Target validation
for Ubuntu 24.04 Linux x86-64 is a separate stage
(`scripts/verify_linux.py`); its current status, including any pending items, is
recorded in `docs/acceptance.md`. These numbers measure compile and link
throughput; they are not evidence that a two-hour challenge-authoring workflow
is achievable. That experiment is still pending.

Raw data: `build/build-timings.json`.
"""


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=int, default=DEFAULT_RUNS,
                        help=f"repeated measurement runs (default {DEFAULT_RUNS})")
    parser.add_argument("--jobs", type=int, default=1,
                        help="parallel make jobs (default 1 for a stable baseline)")
    parser.add_argument("--cc", default=os.environ.get("CC", "cc"))
    parser.add_argument("--markdown",
                        default=str(ROOT / "docs" / "build-timings.md"))
    parser.add_argument("--json", default=str(BUILD / "build-timings.json"))
    args = parser.parse_args()
    if args.runs < 1:
        parser.error("--runs must be >= 1")
    if args.jobs < 1:
        parser.error("--jobs must be >= 1")

    make = find_make()
    verify = subprocess.run(
        [sys.executable, str(ROOT / "scripts" / "verify_pin.py")],
        cwd=ROOT, capture_output=True, text=True)
    if not (verify.returncode == 0):
        sys.stderr.write(verify.stdout)
        sys.stderr.write(verify.stderr)
        raise SystemExit("bench: pinned source verification failed")

    env = dict(os.environ)
    env["CC"] = args.cc
    make_cmd = [make, f"-j{args.jobs}", "runner"]
    clean_cmd = [make, "clean"]

    source_stat = QJS_CORE.stat()
    samples = {"cold": [], "noop": [], "core_touch_incremental": []}
    try:
        for index in range(args.runs):
            run(clean_cmd, f"run {index + 1} clean", env=env)
            samples["cold"].append(
                timed(make_cmd, f"run {index + 1} cold build", env=env))
            samples["noop"].append(
                timed(make_cmd, f"run {index + 1} no-op build", env=env))
            touch_quickjs_core()
            samples["core_touch_incremental"].append(
                timed(make_cmd, f"run {index + 1} incremental build", env=env))
    finally:
        os.utime(QJS_CORE, ns=(source_stat.st_atime_ns,
                               source_stat.st_mtime_ns))

    runner = BUILD / "qjs_runner"
    qjs_obj = BUILD / "quickjs.o"
    build_total = sum(path.stat().st_size for path in BUILD.rglob("*")
                      if path.is_file())
    record = {
        "measured_at_utc": datetime.now(timezone.utc)
                          .strftime("%Y-%m-%dT%H:%M:%SZ"),
        "host": host_info(),
        "compiler": compiler_info(args.cc),
        "make": make_info(make),
        "jobs": args.jobs,
        "runs": args.runs,
        "flags": actual_flags(make, env),
        "pinned_source": "QuickJS 2026-06-04 (SHA-256 verified before timing)",
        "download_or_extract_counted": False,
        "lto": False,
        "source_timestamp_restored": True,
        "core_touch_offset_seconds": 2.0,
        "timings": {
            "cold": summarize(samples["cold"]),
            "noop": summarize(samples["noop"]),
            "core_touch_incremental": summarize(
                samples["core_touch_incremental"]),
        },
        "seconds": {
            "clean_build": round(statistics.median(samples["cold"]), 3),
            "noop_build": round(statistics.median(samples["noop"]), 3),
            "core_touch_incremental": round(
                statistics.median(samples["core_touch_incremental"]), 3),
        },
        "artifacts": {
            "runner_bytes": runner.stat().st_size if runner.is_file() else None,
            "runner_sha256": sha256_file(runner) if runner.is_file() else None,
            "quickjs_object_bytes": (qjs_obj.stat().st_size
                                     if qjs_obj.is_file() else None),
            "build_dir_bytes": build_total,
        },
        "validation_scope": (
            "Native host only. It measures compile/link throughput and is not "
            "evidence of a two-hour challenge-authoring workflow. Ubuntu "
            "24.04 x86-64 validation is a separate stage."
        ),
    }

    json_path = Path(args.json)
    json_path.parent.mkdir(parents=True, exist_ok=True)
    json_path.write_text(json.dumps(record, indent=2) + "\n")

    markdown_path = Path(args.markdown)
    markdown_path.parent.mkdir(parents=True, exist_ok=True)
    markdown_path.write_text(markdown_report(record))

    print(json.dumps(record, indent=2))
    print(f"wrote {json_path} and {markdown_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
