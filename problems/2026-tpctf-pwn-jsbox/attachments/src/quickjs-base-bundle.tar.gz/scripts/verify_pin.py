#!/usr/bin/env python3
"""Verify the vendored QuickJS archive pin and extracted release metadata."""

from __future__ import annotations

import hashlib
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
QJS_DIR = ROOT / "third_party" / "quickjs"
ARCHIVE = QJS_DIR / "quickjs-2026-06-04.tar.xz"
SUM_FILE = QJS_DIR / "SHA256SUMS"
SRC = QJS_DIR / "src"

EXPECTED_SHA256 = "b376e839b322978313d929fd20663b11ba58b75df5a46c126dd19ea2fa70ad2a"
EXPECTED_VERSION = "2026-06-04"
EXPECTED_SIZE = 621500


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def fail(message: str) -> None:
    print(f"verify-pin: FAIL: {message}", file=sys.stderr)
    raise SystemExit(1)


def main() -> int:
    if not ARCHIVE.is_file():
        fail(f"missing archive: {ARCHIVE}")
    if not SUM_FILE.is_file():
        fail(f"missing checksum file: {SUM_FILE}")

    size = ARCHIVE.stat().st_size
    if size != EXPECTED_SIZE:
        fail(f"archive size {size} does not match pinned {EXPECTED_SIZE}")

    digest = sha256_file(ARCHIVE)
    if digest != EXPECTED_SHA256:
        fail(f"archive sha256 {digest} does not match pinned {EXPECTED_SHA256}")

    sum_lines = [line.strip() for line in SUM_FILE.read_text().splitlines()
                 if line.strip()]
    expected_line = f"{EXPECTED_SHA256}  {ARCHIVE.name}"
    if expected_line not in sum_lines:
        fail(f"SHA256SUMS does not contain the pinned entry: {expected_line}")

    version_file = SRC / "VERSION"
    if not version_file.is_file():
        fail(f"missing extracted version file: {version_file}")
    version = version_file.read_text().strip()
    if version != EXPECTED_VERSION:
        fail(f"extracted VERSION {version!r} != {EXPECTED_VERSION!r}")

    license_file = SRC / "LICENSE"
    if not license_file.is_file() or "QuickJS Javascript Engine" not in \
            license_file.read_text(errors="replace"):
        fail(f"missing or unexpected upstream license: {license_file}")

    for name in ("quickjs.c", "quickjs.h", "dtoa.c", "libregexp.c",
                 "libunicode.c", "cutils.c"):
        if not (SRC / name).is_file():
            fail(f"missing extracted source file: {SRC / name}")

    print("verify-pin: OK")
    print(f"  release:   {EXPECTED_VERSION}")
    print(f"  archive:   {ARCHIVE.relative_to(ROOT)} ({size} bytes)")
    print(f"  sha256:    {digest}")
    print(f"  extracted: {SRC.relative_to(ROOT)}")
    print(f"  license:   {(SRC / 'LICENSE').relative_to(ROOT)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
