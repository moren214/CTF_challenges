#!/usr/bin/env python3
"""Run the full test suite inside a Docker/Podman-built target image.

The operator supplies the pinned Ubuntu image reference.  This script never
invents a digest: it records the actual engine output and exits non-zero when
the image, architecture, build, or in-container verification fails.

If no container engine is available it writes a "skipped" report and exits 2.
It does not claim that a container run happened on the implementation host.
"""

from __future__ import annotations

import argparse
import json
import os
import platform
import secrets
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
BUILD = ROOT / "build"
REPORTS = ROOT / "reports"
DEFAULT_REPORT = REPORTS / "verify-docker-report.json"
ENGINE_CANDIDATES = ("docker", "podman", "nerdctl")


class DockerVerificationError(RuntimeError):
    pass


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def platform_error(requested: str, allow_arch: bool) -> str | None:
    """Return an error unless the requested platform is the x86-64 target."""
    if allow_arch:
        return None
    if requested != "linux/amd64":
        return (f"requested platform is {requested}, expected linux/amd64; "
                "pass --allow-arch to override")
    return None


def positive_cpus(value: str) -> float:
    try:
        cpus = float(value)
    except ValueError as exc:
        raise argparse.ArgumentTypeError("must be a number") from exc
    if cpus <= 0:
        raise argparse.ArgumentTypeError("must be positive")
    return cpus


def container_resources(engine: str, name: str, report: dict) -> dict:
    """Record the engine-applied CPU/memory limits for the run container."""
    proc = run_command(
        [engine, "inspect", "--format", "{{json .HostConfig}}", name],
        "inspect container resources", report)
    try:
        data = json.loads(proc.stdout)
    except json.JSONDecodeError as exc:
        raise DockerVerificationError(
            f"container inspect returned invalid JSON: {exc}")
    record = {
        "NanoCpus": data.get("NanoCpus"),
        "CpuQuota": data.get("CpuQuota"),
        "CpuPeriod": data.get("CpuPeriod"),
        "Memory": data.get("Memory"),
        "MemorySwap": data.get("MemorySwap"),
        "CpusetCpus": data.get("CpusetCpus"),
    }
    report["resources"]["actual"] = record
    return record


def find_engine(explicit: str | None) -> tuple[str | None, str]:
    candidates = []
    if explicit:
        candidates.append(explicit)
    else:
        env_engine = os.environ.get("CONTAINER_ENGINE")
        if env_engine:
            candidates.append(env_engine)
        candidates.extend(ENGINE_CANDIDATES)
    seen = set()
    diagnostics = []
    for candidate in candidates:
        if not candidate or candidate in seen:
            continue
        seen.add(candidate)
        path = shutil.which(candidate)
        if not path:
            diagnostics.append(f"{candidate}: not found on PATH")
            continue
        probe = subprocess.run([path, "info"], capture_output=True, text=True)
        if probe.returncode == 0:
            return path, "; ".join(diagnostics)
        diagnostics.append(
            f"{candidate}: engine info failed ({probe.stderr.strip()[:200]})")
    return None, "; ".join(diagnostics)


def engine_version(engine: str) -> str:
    probe = subprocess.run([engine, "version"], capture_output=True,
                           text=True)
    if probe.returncode == 0:
        lines = (probe.stdout or probe.stderr).strip().splitlines()
        return lines[0] if lines else "unknown"
    return "unknown"


def run_command(argv: list[str], name: str, report: dict,
                timeout: int = 3600) -> subprocess.CompletedProcess:
    print(f"=== {name}: {argv}", file=sys.stderr)
    proc = subprocess.run(argv, cwd=ROOT, capture_output=True, text=True,
                          timeout=timeout)
    print(f"--- {name} stdout ---", file=sys.stderr)
    if proc.stdout:
        sys.stderr.write(proc.stdout)
    print(f"--- {name} stderr ---", file=sys.stderr)
    if proc.stderr:
        sys.stderr.write(proc.stderr)
    sys.stderr.flush()
    report["commands"].append({
        "name": name,
        "argv": argv,
        "returncode": proc.returncode,
        "stdout_tail": proc.stdout[-4000:],
        "stderr_tail": proc.stderr[-4000:],
    })
    if not (proc.returncode == 0):
        raise DockerVerificationError(
            f"{name} failed with exit code {proc.returncode}")
    return proc


def image_inspect(engine: str, reference: str, report: dict,
                  label: str) -> dict:
    proc = subprocess.run(
        [engine, "image", "inspect", "--format", "{{json .}}", reference],
        cwd=ROOT, capture_output=True, text=True, timeout=300)
    if not (proc.returncode == 0):
        raise DockerVerificationError(
            f"cannot inspect {label} image {reference}: "
            f"{proc.stderr.strip()[:300]}")
    try:
        data = json.loads(proc.stdout)
    except json.JSONDecodeError as exc:
        raise DockerVerificationError(
            f"image inspect returned invalid JSON for {reference}: {exc}")
    record = {
        "reference": reference,
        "Id": data.get("Id"),
        "Architecture": data.get("Architecture"),
        "Os": data.get("Os"),
        "Created": data.get("Created"),
        "RepoDigests": data.get("RepoDigests"),
        "Size": data.get("Size"),
    }
    report["images"][label] = record
    return record


def read_json(path: Path) -> dict | None:
    if not path.is_file():
        return None
    try:
        return json.loads(path.read_text())
    except (OSError, json.JSONDecodeError):
        return None


def write_report(report: dict, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report, indent=2) + "\n")
    print(f"verify-docker: {report['status']} -> {path}")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--image", required=True,
                        help="operator-supplied Ubuntu image reference, ideally "
                             "ubuntu:24.04@sha256:<digest>")
    parser.add_argument("--tag", default="qjs-ctf-verify:local",
                        help="tag for the locally built verification image")
    parser.add_argument("--engine",
                        help="container engine path/name (docker, podman, ...)")
    parser.add_argument("--runs", type=int, default=3,
                        help="repeated timing runs inside the container")
    parser.add_argument("--jobs", type=int, default=1,
                        help="make jobs inside the container")
    parser.add_argument("--cc", default="cc")
    parser.add_argument("--platform", default="linux/amd64",
                        help="container platform (default linux/amd64, the "
                             "declared x86-64 target)")
    parser.add_argument("--cpus", type=positive_cpus, default=2.0,
                        help="CPU quota requested for the verification "
                             "container (docker --cpus; default 2)")
    parser.add_argument("--memory", default="2g",
                        help="memory limit requested for the verification "
                             "container (docker --memory; default 2g)")
    parser.add_argument("--skip-apt", action="store_true",
                        help="do not run apt in the image build; the supplied "
                             "base must already contain the dependencies")
    parser.add_argument("--build-network",
                        help="optional --network value for docker build")
    parser.add_argument("--run-network", default="none",
                        help="docker run network mode (default none for an "
                             "offline verification run)")
    parser.add_argument("--require-digest", action="store_true",
                        help="fail unless --image contains @sha256:...")
    parser.add_argument("--allow-arch", action="store_true",
                        help="permit a non-amd64 image architecture")
    parser.add_argument("--report", default=str(DEFAULT_REPORT))
    args = parser.parse_args()
    if args.runs < 1:
        parser.error("--runs must be >= 1")
    if args.jobs < 1:
        parser.error("--jobs must be >= 1")

    report = {
        "schema_version": 1,
        "kind": "qjs-ctf-docker-verification",
        "started_at_utc": utc_now(),
        "status": "running",
        "host": {
            "platform": platform.system(),
            "release": platform.release(),
            "machine": platform.machine(),
        },
        "image_reference": args.image,
        "image_digest_pinned": "@sha256:" in args.image,
        "require_digest": args.require_digest,
        "scope": "verification image only; the runtime image is not built, "
                 "run, or smoke-tested by this report",
        "requested": {
            "platform": args.platform,
            "cpus": args.cpus,
            "memory": args.memory,
            "build_network": args.build_network or "engine default",
            "run_network": args.run_network,
        },
        "resources": {
            "requested": {
                "cpus": args.cpus,
                "memory": args.memory,
            },
            "actual": None,
            "observed_cgroup_cpu_quota": None,
            "observed_machine": None,
        },
        "engine": None,
        "images": {},
        "verification_image": None,
        "runtime_image": {
            "status": "pending",
            "stage": "runtime",
            "reason": "This verifier selects the verify stage. A passing "
                      "verify stage does not build, run, or validate the "
                      "runtime image.",
        },
        "commands": [],
        "linux_report": None,
        "limitations": [],
    }
    report_path = Path(args.report)

    platform_problem = platform_error(args.platform, args.allow_arch)
    if platform_problem:
        report["status"] = "failed"
        report["limitations"].append(platform_problem)
        write_report(report, report_path)
        print(f"verify-docker: {platform_problem}", file=sys.stderr)
        return 1
    if args.allow_arch:
        report["limitations"].append(
            f"--allow-arch set; requested platform is {args.platform}")

    if args.require_digest and not report["image_digest_pinned"]:
        report["status"] = "failed"
        report["limitations"].append(
            "--require-digest was set but --image has no @sha256: digest")
        write_report(report, report_path)
        print("verify-docker: image reference is not digest-pinned",
              file=sys.stderr)
        return 1
    if not report["image_digest_pinned"]:
        report["limitations"].append(
            "Image reference is not digest-pinned; the operator supplied a "
            "tag. No digest was invented.")

    engine, diagnostics = find_engine(args.engine)
    if not engine:
        report["status"] = "skipped"
        report["finished_at_utc"] = utc_now()
        report["limitations"].append(
            "No container engine available. " + diagnostics)
        write_report(report, report_path)
        print("verify-docker: no container engine available; nothing was run",
              file=sys.stderr)
        return 2

    report["engine"] = {"path": engine,
                        "version": engine_version(engine),
                        "diagnostics": diagnostics}
    BUILD.mkdir(parents=True, exist_ok=True)
    temp_dir = Path(tempfile.mkdtemp(prefix="docker-verify-", dir=BUILD))
    container_name = "qjs-ctf-verify-" + secrets.token_hex(4)
    try:
        build_cmd = [
            engine, "build",
            "--platform", args.platform,
            "--build-arg", f"BASE_IMAGE={args.image}",
            "--target", "verify",
            "-t", args.tag,
            "-f", str(ROOT / "Dockerfile"),
        ]
        if args.skip_apt:
            build_cmd.extend(["--build-arg", "SKIP_APT=1"])
        if args.build_network:
            build_cmd.extend(["--network", args.build_network])
        build_cmd.append(str(ROOT))
        run_command(build_cmd, "build verify image", report)

        built = image_inspect(engine, args.tag, report, "verification")
        base = image_inspect(engine, args.image, report, "base")
        report["verification_image"] = {
            "reference": args.tag,
            "architecture": built.get("Architecture"),
            "os": built.get("Os"),
            "scope": "validation image only; not the runtime image",
        }
        for label, record in (("verification", built), ("base", base)):
            arch = record.get("Architecture")
            if arch not in ("amd64", "x86_64") and not args.allow_arch:
                raise DockerVerificationError(
                    f"{label} image architecture is {arch}, expected amd64; "
                    "pass --allow-arch to override")
            if arch not in ("amd64", "x86_64"):
                report["limitations"].append(
                    f"{label} image architecture is {arch}, not x86_64")

        container_cmd = [
            engine, "run", "--name", container_name,
            "--platform", args.platform,
            "--cpus", f"{args.cpus:g}",
            "--memory", args.memory,
            "--network", args.run_network,
            "-v", f"{temp_dir}:/out",
            args.tag,
            "python3", "scripts/verify_linux.py",
            "--report", "/out/linux-report.json",
            "--timings-json", "/out/linux-timings.json",
            "--timings-markdown", "/out/linux-timings.md",
            "--runs", str(args.runs),
            "--jobs", str(args.jobs),
            "--cc", args.cc,
        ]
        run_command(container_cmd, "in-container verification", report)
        container_resources(engine, container_name, report)
        linux_report = read_json(temp_dir / "linux-report.json")
        if linux_report is None:
            raise DockerVerificationError(
                "in-container verification produced no machine-readable report")
        report["linux_report"] = linux_report
        if linux_report.get("status") not in ("passed",):
            raise DockerVerificationError(
                "in-container verification report status is "
                f"{linux_report.get('status')}")
        observed_host = linux_report.get("host") or {}
        observed_machine = observed_host.get("machine")
        report["resources"]["observed_machine"] = observed_machine
        if observed_machine not in ("x86_64", "amd64"):
            raise DockerVerificationError(
                "in-container host architecture is "
                f"{observed_machine}, expected x86_64")
        if linux_report.get("target_mismatches"):
            raise DockerVerificationError(
                "in-container target mismatches: "
                + "; ".join(linux_report["target_mismatches"]))
        timings = linux_report.get("timings") or {}
        observed_quota = (timings.get("host") or {}).get("cpu_quota")
        report["resources"]["observed_cgroup_cpu_quota"] = observed_quota
        report["status"] = "passed"
    except (DockerVerificationError, subprocess.TimeoutExpired) as exc:
        report["status"] = "failed"
        report["limitations"].append(str(exc))
        print(f"verify-docker: {exc}", file=sys.stderr)
    finally:
        try:
            subprocess.run([engine, "rm", "-f", container_name],
                           capture_output=True, text=True, timeout=60)
        except (OSError, subprocess.SubprocessError):
            pass
        shutil.rmtree(temp_dir, ignore_errors=True)
        report["finished_at_utc"] = utc_now()
        write_report(report, report_path)

    return 0 if report["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
