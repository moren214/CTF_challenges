#!/usr/bin/env python3
"""Bounded TCP adapter for the minimal QuickJS worker.

Design:
  * One accepted TCP connection owns one child worker process and one
    persistent JS runtime.  Closing the connection -- normally or after a
    timeout -- tears the worker down.
  * Client protocol is JSON Lines: {"code": "<source>"}.
  * Replies are JSON objects: {"ok": true, "result": ...} or
    {"ok": false, "error": {name, message, stack?}, "fatal"?: true}.
  * The adapter enforces line/source limits and an external wall-clock
    deadline.  On deadline expiry it SIGKILLs the worker's process group;
    the runtime and all connection state are lost.

Only the Python standard library is used.  The adapter is not a general
JavaScript host: the worker is the minimal embedding in runner/qjs_runner.c.
"""

from __future__ import annotations

import argparse
import json
import os
import select
import signal
import socket
import socketserver
import struct
import subprocess
import sys
import threading
import time

# Keep in sync with runner/qjs_runner.c.
MAX_SOURCE_BYTES = 64 * 1024
MAX_WORKER_PAYLOAD = 1024 * 1024
MAX_LINE_BYTES = 1024 * 1024
# Allow a little over the line limit so we can consume the trailing newline
# and avoid resetting the connection before the error reply is delivered.
MAX_LINE_DRAIN = MAX_LINE_BYTES + 64 * 1024
MAX_REPLY_BYTES = 2 * 1024 * 1024
MAX_CONNECTIONS = 64
DEFAULT_TIMEOUT = 2.0
MAX_TIMEOUT = 30.0
IDLE_READ_TIMEOUT = 60.0

# The runner reads exactly this worker-side variable.  The adapter may read its
# own source from a different environment variable (--flag-env) or a file, but
# the worker always receives the value under this fixed reserved name.
WORKER_FLAG_ENV = "QJS_CTF_FLAG"
MAX_FLAG_FILE_BYTES = 4096

STATUS_RESULT = b"O"
STATUS_EXCEPTION = b"E"
STATUS_LIMIT = b"L"
STATUS_FATAL = b"F"


class WorkerTimeout(Exception):
    pass


class WorkerClosed(Exception):
    pass


class WorkerProtocolError(Exception):
    pass


class FlagConfigError(Exception):
    """Invalid or conflicting instance-flag configuration.

    Messages never include the flag value.
    """


def load_flag_file(path: str) -> str:
    """Read one runtime instance flag from a platform-supplied file.

    The value is not logged, returned in replies, or exposed to JavaScript.
    A single trailing newline (LF or CRLF) is stripped for conveniences such as
    Docker/Kubernetes secret files.  Empty files and NUL bytes are rejected
    because they cannot be injected safely into a worker environment.
    """
    try:
        with open(path, "rb") as f:
            data = f.read(MAX_FLAG_FILE_BYTES + 1)
    except FileNotFoundError as exc:
        raise FlagConfigError(f"flag file not found: {path}") from exc
    except IsADirectoryError as exc:
        raise FlagConfigError(f"flag file is not a regular file: {path}") from exc
    except PermissionError as exc:
        raise FlagConfigError(f"flag file is not readable: {path}") from exc
    except OSError as exc:
        detail = exc.strerror or str(exc)
        raise FlagConfigError(f"cannot read flag file {path}: {detail}") from exc
    if len(data) > MAX_FLAG_FILE_BYTES:
        raise FlagConfigError(
            f"flag file exceeds {MAX_FLAG_FILE_BYTES} bytes: {path}")
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise FlagConfigError(
            f"flag file is not valid UTF-8: {path}") from exc
    if text.endswith("\r\n"):
        text = text[:-2]
    elif text.endswith("\n"):
        text = text[:-1]
    if not text:
        raise FlagConfigError(f"flag file is empty: {path}")
    if "\x00" in text:
        raise FlagConfigError(f"flag file contains a NUL byte: {path}")
    return text


def resolve_flag(flag_env: str, flag_file: str | None,
                 environ=None) -> tuple[str | None, str]:
    """Resolve exactly one flag source.  Returns (value, redacted source label).

    File mode is preferred for deployment.  Supplying a file while the
    environment variable also carries a non-empty value is a configuration
    error rather than a silent precedence rule.
    """
    env = os.environ if environ is None else environ
    env_value = env.get(flag_env) if flag_env else None
    if not env_value:
        env_value = None
    if flag_file:
        file_value = load_flag_file(flag_file)
        if env_value:
            raise FlagConfigError(
                "conflicting flag sources: --flag-file and environment "
                f"variable {flag_env} are both set")
        return file_value, f"file:{flag_file}"
    if env_value:
        return env_value, f"env:{flag_env}"
    return None, "none"


def _error(name: str, message: str, **extra):
    err = {"name": name, "message": message}
    err.update(extra)
    return err


def _fatal_reply(name: str, message: str):
    return {"ok": False, "error": _error(name, message), "fatal": True}


def _nonfatal_reply(name: str, message: str):
    return {"ok": False, "error": _error(name, message)}


class Worker:
    """One qjs_runner process plus the request/response framing."""

    def __init__(self, runner: str, timeout_s: float, flag_env: str,
                 flag_value: str | None):
        # Deliberately do not inherit the adapter environment.  The worker gets
        # a fixed minimal environment plus only the instance flag variable.
        env = {"LC_ALL": "C", "LANG": "C"}
        if flag_env and flag_value:
            env[flag_env] = flag_value
        try:
            self.proc = subprocess.Popen(
                [runner],
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                env=env,
                bufsize=0,
                close_fds=True,
                start_new_session=True,
            )
        except (OSError, ValueError):
            raise
        self.timeout_s = timeout_s
        self._closed = False
        # The runner's first stderr line is a flag-presence handshake.  Failing
        # closed here proves the configured flag actually reached the worker
        # OS environment without ever exposing its value to JavaScript.
        try:
            startup = self._read_startup_line(5.0)
        except WorkerClosed as exc:
            self.kill()
            raise OSError(f"worker startup handshake failed: {exc}") from exc
        self.flag_present = b"instance flag present" in startup
        if not self.flag_present and b"instance flag absent" not in startup:
            self.kill()
            raise OSError("worker startup handshake was not recognized")
        expected_present = bool(flag_env and flag_value)
        if self.flag_present != expected_present:
            self.kill()
            raise OSError("worker flag injection mismatch")
        # Non-blocking writes let the per-evaluation deadline cover a worker
        # that stops draining its stdin, not only response reads.
        assert self.proc.stdin is not None
        os.set_blocking(self.proc.stdin.fileno(), False)

    def _read_startup_line(self, timeout_s: float) -> bytes:
        assert self.proc.stderr is not None
        try:
            ready, _, _ = select.select([self.proc.stderr], [], [], timeout_s)
            if not ready:
                raise WorkerClosed("worker did not report startup")
            line = self.proc.stderr.readline()
        except (OSError, ValueError) as exc:
            raise WorkerClosed(str(exc)) from exc
        if not line:
            raise WorkerClosed("worker stderr closed during startup")
        return line

    def _write_all(self, data: bytes, deadline: float) -> None:
        assert self.proc.stdin is not None
        fd = self.proc.stdin.fileno()
        view = memoryview(data)
        while view:
            left = deadline - time.monotonic()
            if left <= 0:
                raise WorkerTimeout()
            try:
                _, ready, _ = select.select([], [fd], [], left)
            except (OSError, ValueError) as exc:
                raise WorkerClosed(str(exc)) from exc
            if not ready:
                raise WorkerTimeout()
            try:
                n = os.write(fd, view)
            except BlockingIOError:
                continue
            except (OSError, ValueError) as exc:
                raise WorkerClosed(str(exc)) from exc
            if n <= 0:
                raise WorkerClosed("worker stdin closed")
            view = view[n:]

    def _read_exact(self, n: int, deadline: float) -> bytes:
        assert self.proc.stdout is not None
        fd = self.proc.stdout.fileno()
        chunks = []
        remaining = n
        while remaining:
            left = deadline - time.monotonic()
            if left <= 0:
                raise WorkerTimeout()
            try:
                ready, _, _ = select_read(fd, left)
            except (OSError, ValueError) as exc:
                raise WorkerClosed(str(exc)) from exc
            if not ready:
                raise WorkerTimeout()
            try:
                chunk = os.read(fd, remaining)
            except (OSError, ValueError) as exc:
                raise WorkerClosed(str(exc)) from exc
            if not chunk:
                raise WorkerClosed("worker stdout closed")
            chunks.append(chunk)
            remaining -= len(chunk)
        return b"".join(chunks)

    def evaluate(self, code: str):
        """Returns (reply_dict, close_connection)."""
        try:
            source = code.encode("utf-8")
        except UnicodeEncodeError:
            return (_nonfatal_reply("ProtocolError",
                                    "code is not valid UTF-8"), False)
        if len(source) > MAX_SOURCE_BYTES:
            return (_nonfatal_reply(
                "InputLimitError",
                f"source exceeds {MAX_SOURCE_BYTES} UTF-8 bytes"), False)

        frame = struct.pack(">I", len(source)) + source
        deadline = time.monotonic() + self.timeout_s
        try:
            self._write_all(frame, deadline)
            header = self._read_exact(5, deadline)
            status = header[:1]
            length = struct.unpack(">I", header[1:])[0]
            if length > MAX_WORKER_PAYLOAD:
                raise WorkerProtocolError(
                    f"worker payload length {length} exceeds limit")
            payload = self._read_exact(length, deadline) if length else b""
        except WorkerTimeout:
            self.kill()
            return (_fatal_reply(
                "TimeoutError",
                f"evaluation exceeded {self.timeout_s:g}s; worker terminated"),
                True)
        except WorkerClosed as exc:
            self.kill()
            return (_fatal_reply("WorkerClosedError", str(exc)), True)
        except WorkerProtocolError as exc:
            self.kill()
            return (_fatal_reply("ProtocolError", str(exc)), True)

        if status == STATUS_RESULT:
            try:
                result = json.loads(payload.decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError) as exc:
                self.kill()
                return (_fatal_reply(
                    "ProtocolError",
                    f"worker returned invalid JSON: {exc}"), True)
            return ({"ok": True, "result": result}, False)

        if status in (STATUS_EXCEPTION, STATUS_LIMIT):
            try:
                err = json.loads(payload.decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError) as exc:
                self.kill()
                return (_fatal_reply(
                    "ProtocolError",
                    f"worker returned invalid error JSON: {exc}"), True)
            if not isinstance(err, dict):
                err = _error("Error", "worker returned a non-object error")
            # The runner exits after an input-limit reply because the rejected
            # body cannot be resynchronized.  Output-limit replies are
            # recoverable and the worker continues.
            fatal = (status == STATUS_LIMIT and
                     err.get("name") == "InputLimitError")
            reply = {"ok": False, "error": err}
            if fatal:
                reply["fatal"] = True
            return (reply, fatal)

        if status == STATUS_FATAL:
            self.kill()
            try:
                err = json.loads(payload.decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError):
                err = _error("InternalError", "worker reported a fatal error")
            if not isinstance(err, dict):
                err = _error("InternalError", "worker reported a fatal error")
            return ({"ok": False, "error": err, "fatal": True}, True)

        self.kill()
        return (_fatal_reply(
            "ProtocolError",
            f"unknown worker status byte {status!r}"), True)

    def kill(self) -> None:
        """Terminate the worker and its process group; idempotent."""
        if self._closed:
            return
        self._closed = True
        if self.proc.poll() is None:
            try:
                os.killpg(self.proc.pid, signal.SIGKILL)
            except (ProcessLookupError, PermissionError):
                try:
                    self.proc.kill()
                except ProcessLookupError:
                    pass
        try:
            self.proc.wait(timeout=2.0)
        except subprocess.TimeoutExpired:
            pass
        self._close_pipes()

    def close(self) -> None:
        """Graceful shutdown for a worker that is not stuck."""
        if self._closed:
            return
        self._closed = True
        if self.proc.poll() is None:
            try:
                if self.proc.stdin is not None:
                    self.proc.stdin.close()
            except OSError:
                pass
            try:
                self.proc.wait(timeout=1.0)
            except subprocess.TimeoutExpired:
                try:
                    os.killpg(self.proc.pid, signal.SIGKILL)
                except (ProcessLookupError, PermissionError):
                    pass
                try:
                    self.proc.wait(timeout=2.0)
                except subprocess.TimeoutExpired:
                    pass
        self._close_pipes()

    def _close_pipes(self) -> None:
        for stream in (self.proc.stdin, self.proc.stdout, self.proc.stderr):
            if stream is not None:
                try:
                    stream.close()
                except OSError:
                    pass


def select_read(fd: int, timeout_s: float):
    return select.select([fd], [], [], timeout_s)


class ConnectionHandler(socketserver.BaseRequestHandler):
    def handle(self) -> None:
        server: "AdapterServer" = self.server
        self.request.settimeout(IDLE_READ_TIMEOUT)
        if not server.try_acquire_slot():
            self._send({
                "ok": False,
                "error": _error("BusyError", "connection limit reached"),
                "fatal": True,
            })
            return

        worker = None
        try:
            try:
                worker = Worker(server.runner, server.timeout_s,
                                server.flag_env, server.flag_value)
            except (OSError, ValueError) as exc:
                self._send(_fatal_reply(
                    "WorkerStartError",
                    f"could not start worker: {exc}"))
                return
            server.track(worker)
            self._serve(server, worker)
        finally:
            if worker is not None:
                server.untrack(worker)
                worker.close()
            server.release_slot()

    def _serve(self, server: "AdapterServer", worker: Worker) -> None:
        buf = b""
        while True:
            line, buf, too_large = self._read_line(buf)
            if too_large:
                self._send(_fatal_reply(
                    "InputLimitError",
                    f"request line exceeds {MAX_LINE_BYTES} bytes"))
                return
            if line is None:
                return
            if not line.strip():
                self._send(_nonfatal_reply(
                    "ProtocolError", "empty request line"))
                continue
            try:
                obj = json.loads(line.decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError) as exc:
                self._send(_nonfatal_reply(
                    "ProtocolError", f"invalid JSON request: {exc}"))
                continue
            if not isinstance(obj, dict):
                self._send(_nonfatal_reply(
                    "ProtocolError", "request must be a JSON object"))
                continue
            code = obj.get("code")
            if not isinstance(code, str):
                self._send(_nonfatal_reply(
                    "ProtocolError", "request field 'code' must be a string"))
                continue

            reply, close_connection = worker.evaluate(code)
            if not self._send(reply):
                return
            if close_connection:
                return

    def _read_line(self, buf: bytes):
        """Returns (line_or_None, remaining_buffer, too_large)."""
        while True:
            idx = buf.find(b"\n")
            if idx >= 0:
                line = buf[:idx]
                rest = buf[idx + 1:]
                return line, rest, len(line) > MAX_LINE_BYTES
            if len(buf) > MAX_LINE_DRAIN:
                return None, b"", True
            try:
                chunk = self.request.recv(65536)
            except OSError:
                return None, b"", False
            if not chunk:
                return None, b"", False
            buf += chunk

    def _send(self, reply: dict) -> bool:
        # JSON can represent lone UTF-16 surrogates that UTF-8 cannot encode.
        # Fall back to full ASCII escaping so such a result does not kill the
        # session.
        try:
            encoded = json.dumps(reply, ensure_ascii=False,
                                 separators=(",", ":")).encode("utf-8")
        except UnicodeEncodeError:
            try:
                encoded = json.dumps(reply, ensure_ascii=True,
                                     separators=(",", ":")).encode("ascii")
            except (TypeError, ValueError):
                encoded = b'{"ok":false,"error":{"name":"InternalError","message":"reply encoding failed"},"fatal":true}'
        except (TypeError, ValueError):
            encoded = b'{"ok":false,"error":{"name":"InternalError","message":"reply encoding failed"},"fatal":true}'
        if len(encoded) > MAX_REPLY_BYTES:
            encoded = b'{"ok":false,"error":{"name":"OutputLimitError","message":"reply exceeds adapter limit"},"fatal":true}'
        try:
            self.request.sendall(encoded + b"\n")
            return True
        except OSError:
            return False


class AdapterServer(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True
    request_queue_size = 128

    def __init__(self, address, runner: str, timeout_s: float,
                 flag_env: str, flag_value: str | None):
        self.runner = runner
        self.timeout_s = timeout_s
        self.flag_env = flag_env
        self.flag_value = flag_value
        self._slots = threading.BoundedSemaphore(MAX_CONNECTIONS)
        self._workers_lock = threading.Lock()
        self._workers: set[Worker] = set()
        self._closing = False
        super().__init__(address, ConnectionHandler)

    def try_acquire_slot(self) -> bool:
        return self._slots.acquire(blocking=False)

    def release_slot(self) -> None:
        self._slots.release()

    def track(self, worker: Worker) -> None:
        with self._workers_lock:
            if self._closing:
                # A connection thread raced with shutdown.  Do not let its
                # worker escape server_close(); kill it immediately.
                worker.kill()
                return
            self._workers.add(worker)

    def untrack(self, worker: Worker) -> None:
        with self._workers_lock:
            self._workers.discard(worker)

    def cleanup_workers(self) -> None:
        with self._workers_lock:
            self._closing = True
            workers = list(self._workers)
            self._workers.clear()
        for worker in workers:
            worker.kill()

    def server_close(self) -> None:
        self.cleanup_workers()
        super().server_close()


def parse_args(argv=None):
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host", default="127.0.0.1",
                        help="bind address (default: loopback 127.0.0.1)")
    parser.add_argument("--port", type=int, default=8000)
    parser.add_argument("--runner", default=os.path.join(root, "build",
                                                         "qjs_runner"))
    parser.add_argument("--timeout", type=float, default=DEFAULT_TIMEOUT,
                        help=f"per-evaluation wall clock seconds (max {MAX_TIMEOUT:g})")
    parser.add_argument("--flag-env", default="QJS_CTF_FLAG",
                        help="adapter environment variable to read the instance "
                             "flag from (empty string disables environment "
                             "mode)")
    parser.add_argument("--flag-file",
                        help="read the instance flag from this platform-supplied "
                             "file instead of the environment; the file must be "
                             "readable and should be mounted read-only")
    args = parser.parse_args(argv)
    if not (0 < args.timeout <= MAX_TIMEOUT):
        parser.error(f"--timeout must be in (0, {MAX_TIMEOUT:g}]")
    if not os.path.isfile(args.runner):
        parser.error(f"runner not found: {args.runner}")
    if not os.access(args.runner, os.X_OK):
        parser.error(f"runner is not executable: {args.runner}")
    return args


def main(argv=None) -> int:
    args = parse_args(argv)
    try:
        flag_value, flag_source = resolve_flag(args.flag_env, args.flag_file)
    except FlagConfigError as exc:
        print(f"qjs-adapter: flag configuration error: {exc}",
              file=sys.stderr)
        return 2

    if args.flag_file:
        try:
            mode = os.stat(args.flag_file).st_mode
        except OSError:
            mode = 0
        if mode & 0o222:
            print("qjs-adapter: WARNING flag file is writable; mount it "
                  "read-only in deployment", file=sys.stderr)

    def _stop(_signum, _frame):
        raise KeyboardInterrupt

    signal.signal(signal.SIGTERM, _stop)
    signal.signal(signal.SIGINT, _stop)

    server = AdapterServer((args.host, args.port), args.runner, args.timeout,
                           WORKER_FLAG_ENV, flag_value)
    host, port = server.server_address[:2]
    if host not in ("127.0.0.1", "::1", "localhost"):
        print(f"qjs-adapter: WARNING non-loopback bind on {host}:{port}",
              file=sys.stderr)
    print(f"qjs-adapter: listening on {host}:{port}", file=sys.stderr)
    print(f"qjs-adapter: runner={args.runner} timeout={args.timeout:g}s",
          file=sys.stderr)
    print(f"qjs-adapter: flag source {flag_source}: "
          f"{'configured' if flag_value else 'not set'}", file=sys.stderr)
    sys.stderr.flush()

    try:
        server.serve_forever(poll_interval=0.2)
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
