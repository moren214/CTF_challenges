"""Unit tests for evaluator/egress_policy.py (legacy iptables backend).

These tests exercise pure rule construction, namespace-FD safety, legacy
``iptables-save`` readback validation and bounded nsenter invocation.  They do
not claim that a Linux container engine or netfilter ran.
"""

from __future__ import annotations

import hashlib
import importlib.util
import os
import re
import subprocess
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SPEC = importlib.util.spec_from_file_location(
    "egress_policy", ROOT / "evaluator" / "egress_policy.py")
egress = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = egress
SPEC.loader.exec_module(egress)

MARKER = "QJS_instance_1_marker"
TARGET = "10.0.0.2"
GATEWAY = "172.18.0.1"
SENTINEL = "10.9.0.2"


def save_from_batch(batch: str, *, ipv6: bool = False) -> str:
    """Render a restore batch as counted ``iptables-save`` output.

    This deliberately adds the harmless representation changes real save
    output performs (full-length masks, ``-m tcp`` and a different conntrack
    state order) so validation is tested against canonicalized input.
    """
    suffix = "/128" if ipv6 else "/32"
    lines = []
    counter = 0

    def mask(match):
        return match.group(1) + match.group(2) + suffix

    for line in batch.splitlines():
        if line.startswith("-A "):
            counter += 1
            line = re.sub(r"(-[sd] )([0-9A-Fa-f:.]+)(?= )", mask, line)
            if "-p tcp " in line:
                line = line.replace("-p tcp ", "-p tcp -m tcp ")
            line = line.replace(
                "--ctstate NEW,ESTABLISHED",
                "--ctstate ESTABLISHED,NEW")
            line = f"[{counter}:{counter * 10}] " + line
        lines.append(line)
    return "\n".join(lines) + "\n"


def v4_batch(**kwargs) -> str:
    options = {"gateway_ip": GATEWAY, "sentinel_ip": SENTINEL}
    options.update(kwargs)
    return egress.render_ipv4_policy(MARKER, TARGET, **options)


def v6_batch(**kwargs) -> str:
    return egress.render_ipv6_policy(MARKER, **kwargs)


def validate(v4: str | None = None, v6: str | None = None, **kwargs):
    return egress.validate_readback(
        save_from_batch(v4 if v4 is not None else v4_batch()),
        save_from_batch(v6 if v6 is not None else v6_batch(), ipv6=True),
        MARKER, TARGET, gateway_ip=GATEWAY, sentinel_ip=SENTINEL,
        **kwargs)


class BatchConstructionTests(unittest.TestCase):
    def test_legacy_backend_and_binaries_are_explicit(self):
        self.assertEqual(egress.BACKEND, "iptables-legacy")
        self.assertEqual(egress.LEGACY_BINARIES["ipv4_restore"],
                         "iptables-legacy-restore")
        self.assertEqual(egress.LEGACY_BINARIES["ipv4_save"],
                         "iptables-legacy-save")
        self.assertEqual(egress.LEGACY_BINARIES["ipv6_restore"],
                         "ip6tables-legacy-restore")
        self.assertEqual(egress.LEGACY_BINARIES["ipv6_save"],
                         "ip6tables-legacy-save")
        self.assertNotIn("nft", " ".join(egress.LEGACY_BINARIES.values()))

    def test_ipv4_full_filter_table_defaults_to_drop(self):
        batch = v4_batch()
        self.assertTrue(batch.startswith("*filter\n"))
        self.assertIn(":INPUT DROP [0:0]", batch)
        self.assertIn(":OUTPUT DROP [0:0]", batch)
        self.assertIn(":FORWARD DROP [0:0]", batch)
        self.assertIn(f":{MARKER} - [0:0]", batch)
        self.assertIn("COMMIT", batch)
        self.assertNotIn("flush", batch.lower())

    def test_ipv4_only_endpoint_and_established_replies_are_accepted(self):
        batch = v4_batch()
        accepts = [line for line in batch.splitlines()
                   if line.endswith("-j ACCEPT")]
        self.assertEqual(len(accepts), 2)
        self.assertIn(
            f"-A OUTPUT -d {TARGET} -p tcp --dport {egress.TARGET_PORT} "
            f"-m conntrack --ctstate NEW,ESTABLISHED "
            f"-j ACCEPT", batch)
        self.assertIn(
            f"-A INPUT -s {TARGET} -p tcp --sport {egress.TARGET_PORT} "
            f"-m conntrack --ctstate ESTABLISHED "
            f"-j ACCEPT", batch)

    def test_forward_chain_has_no_accept_rule(self):
        batch = v4_batch()
        forward_lines = [
            line for line in batch.splitlines()
            if line.startswith("-A FORWARD ")]
        self.assertTrue(forward_lines)
        self.assertFalse(any(line.endswith("-j ACCEPT")
                             for line in forward_lines))
        self.assertTrue(all(line.endswith("-j DROP")
                            for line in forward_lines))

    def test_ipv4_denials_have_distinct_counters(self):
        batch = v4_batch()
        for required in (
                f"-A OUTPUT -d {TARGET} -j DROP",
                f"-A OUTPUT -d {GATEWAY} -j DROP",
                f"-A OUTPUT -d {SENTINEL} -j DROP",
                f"-A OUTPUT -d {egress.DOCKER_DNS} "
                f"-j DROP",
                f"-A OUTPUT -d {egress.LOOPBACK_V4} "
                f"-j DROP",
                f"-A OUTPUT -p udp -j DROP",
                f"-A OUTPUT -j DROP",
                f"-A INPUT -d {egress.LOOPBACK_V4} "
                f"-j DROP",
                f"-A INPUT -j DROP",
                f"-A FORWARD -j DROP"):
            self.assertIn(required, batch)

    def test_ipv6_table_has_no_accept_and_explicit_test_counters(self):
        batch = v6_batch()
        self.assertTrue(batch.startswith("*filter\n"))
        self.assertNotIn("-j ACCEPT", batch)
        self.assertIn(":INPUT DROP [0:0]", batch)
        self.assertIn(":OUTPUT DROP [0:0]", batch)
        self.assertIn(":FORWARD DROP [0:0]", batch)
        self.assertIn(
            f"-A OUTPUT -d {egress.IPV6_LOOPBACK} "
            f"-j DROP", batch)
        self.assertIn(
            f"-A OUTPUT -d {egress.IPV6_TEST_ADDRESS} "
            f"-j DROP", batch)
        self.assertIn(f"-A OUTPUT -p udp "
                      f"-j DROP", batch)
        self.assertIn(f"-A FORWARD -j DROP",
                      batch)

    def test_numeric_endpoint_is_required(self):
        self.assertEqual(egress.validate_ipv4("10.0.0.2"), "10.0.0.2")
        for bad in ("::1", "target:8000", "", "not-an-ip"):
            with self.assertRaises(egress.EgressPolicyError):
                egress.validate_ipv4(bad)
        with self.assertRaises(egress.EgressPolicyError):
            egress.render_ipv4_policy(MARKER, "::1")
        self.assertEqual(egress.validate_ipv6("::1"), "::1")
        with self.assertRaises(egress.EgressPolicyError):
            egress.validate_ipv6("10.0.0.2")

    def test_marker_is_a_unique_chain_name(self):
        marker = egress.policy_marker("abcdef")
        expected = "QJS_" + hashlib.sha256(b"abcdef").hexdigest()[:20]
        self.assertEqual(marker, expected)
        self.assertLessEqual(len(marker), 28)
        self.assertEqual(egress.policy_marker("abcdef"), marker)
        self.assertNotEqual(egress.policy_marker("abcdef"),
                            egress.policy_marker("abcdeg"))
        self.assertNotEqual(egress.policy_marker("a-b/c"),
                            egress.policy_marker("a_b_c"))
        with self.assertRaises(egress.EgressPolicyError):
            egress.validate_marker("bad name")
        with self.assertRaises(egress.EgressPolicyError):
            egress.validate_marker("X" * 29)
        with self.assertRaises(egress.EgressPolicyError):
            egress.render_ipv4_policy("bad name", TARGET)

    def test_marker_chain_is_declared_and_never_referenced(self):
        for batch in (v4_batch(), v6_batch()):
            self.assertIn(f":{MARKER} - [0:0]", batch)
            rules = [line for line in batch.splitlines()
                     if line.startswith("-A ")]
            self.assertFalse(any(MARKER in line for line in rules))
        self.assertNotIn("--comment", v4_batch())
        self.assertNotIn("--comment", v6_batch())

    def test_marker_chain_missing_fails_closed(self):
        text = save_from_batch(v4_batch())
        text = "\n".join(
            line for line in text.splitlines()
            if not line.startswith(f":{MARKER} ")) + "\n"
        result = egress.validate_readback(
            text, save_from_batch(v6_batch(), ipv6=True),
            MARKER, TARGET, gateway_ip=GATEWAY, sentinel_ip=SENTINEL)
        self.assertFalse(result["ok"])

    def test_marker_chain_with_rule_fails_closed(self):
        text = save_from_batch(v4_batch()).replace(
            "COMMIT", f"-A {MARKER} -j DROP\nCOMMIT")
        text = "[1:1] " + text if False else text
        # Give the injected marker-chain rule kernel counters so parsing
        # reaches ownership validation.
        text = text.replace(f"-A {MARKER} -j DROP",
                            f"[1:1] -A {MARKER} -j DROP")
        result = egress.validate_readback(
            text, save_from_batch(v6_batch(), ipv6=True),
            MARKER, TARGET, gateway_ip=GATEWAY, sentinel_ip=SENTINEL)
        self.assertFalse(result["ok"])

    def test_wrong_marker_chain_fails_closed(self):
        text = save_from_batch(v4_batch()).replace(
            f":{MARKER} - [0:0]", ":QJS_other_marker_name - [0:0]")
        result = egress.validate_readback(
            text, save_from_batch(v6_batch(), ipv6=True),
            MARKER, TARGET, gateway_ip=GATEWAY, sentinel_ip=SENTINEL)
        self.assertFalse(result["ok"])

    def test_atomicity_is_reported_honestly(self):
        atomicity = egress.atomicity_property()
        self.assertTrue(atomicity["ipv4_restore_atomic"])
        self.assertTrue(atomicity["ipv6_restore_atomic"])
        self.assertFalse(atomicity["cross_family_sequence_atomic"])
        self.assertIn("never starts the solver",
                      atomicity["safety_property"])


class NamespaceFdTests(unittest.TestCase):
    def test_nsenter_enters_only_the_network_namespace(self):
        argv = egress.nsenter_argv(
            7, ["iptables-legacy-restore", "--wait=5"])
        self.assertEqual(argv[:3], [
            "nsenter", "--net=/proc/self/fd/7", "--"])
        joined = " ".join(argv)
        for forbidden in ("--mount", "--pid", "--user", "--ipc"):
            self.assertNotIn(forbidden, joined)
        with self.assertRaises(egress.EgressPolicyError):
            egress.nsenter_argv(2, ["iptables-legacy-save"])

    def test_install_argv_uses_bounded_wait_and_explicit_binaries(self):
        argv4 = egress.install_v4_argv(9)
        argv6 = egress.install_v6_argv(9)
        self.assertEqual(argv4[-2:], ["iptables-legacy-restore", "--wait=5"])
        self.assertEqual(argv6[-2:],
                         ["ip6tables-legacy-restore", "--wait=5"])
        self.assertEqual(egress.readback_v4_argv(9)[-4:],
                         ["iptables-legacy-save", "-t", "filter", "-c"])
        self.assertIn("-c", egress.readback_v4_argv(9))
        self.assertIn("ip6tables-legacy-save", egress.readback_v6_argv(9))

    def test_open_namespace_rejects_host_namespace(self):
        class Stat:
            def __init__(self, inode):
                self.st_ino = inode

        closed = []

        def opener(path, flags):
            return 9

        def closer(fd):
            closed.append(fd)

        with self.assertRaises(egress.EgressPolicyError):
            egress.open_network_namespace(
                123, open_fn=opener, fstat_fn=lambda fd: Stat(5),
                stat_fn=lambda path: Stat(5), close_fn=closer)
        self.assertEqual(closed, [9])

        handle = egress.open_network_namespace(
            123, open_fn=opener, fstat_fn=lambda fd: Stat(6),
            stat_fn=lambda path: Stat(5), close_fn=closer)
        self.assertEqual(handle.fd, 9)
        self.assertEqual(handle.inode, 6)
        self.assertEqual(handle.host_inode, 5)
        self.assertTrue(handle.distinct_from_host)
        handle.close()
        self.assertEqual(closed, [9, 9])

    def test_open_namespace_rejects_stdio_fd_without_closing_real_stderr(self):
        closed = []

        def closer(fd):
            closed.append(fd)

        stderr_open = True
        try:
            os.fstat(2)
        except OSError:
            stderr_open = False
        with self.assertRaises(egress.EgressPolicyError):
            egress.open_network_namespace(
                123, open_fn=lambda path, flags: 2,
                fstat_fn=lambda fd: object(),
                stat_fn=lambda path: type("S", (), {"st_ino": 1})(),
                close_fn=closer)
        self.assertEqual(closed, [2])
        self.assertTrue(stderr_open)
        # The native test process must still have usable stderr.
        os.fstat(2)

    def test_pid_reuse_recheck_uses_held_inode(self):
        class Handle:
            closed = False
            fd = 9
            inode = 6

        class Stat:
            def __init__(self, inode):
                self.st_ino = inode

        self.assertTrue(egress.namespace_matches_pid(
            Handle(), 123, stat_fn=lambda path: Stat(6),
            fstat_fn=lambda fd: Stat(6)))
        self.assertFalse(egress.namespace_matches_pid(
            Handle(), 123, stat_fn=lambda path: Stat(7),
            fstat_fn=lambda fd: Stat(6)))
        self.assertFalse(egress.namespace_matches_pid(
            Handle(), 0, stat_fn=lambda path: Stat(6),
            fstat_fn=lambda fd: Stat(6)))
        self.assertFalse(egress.namespace_matches_pid(
            Handle(), 123, stat_fn=lambda path: Stat(7),
            fstat_fn=lambda fd: Stat(7)))


class ReadbackValidationTests(unittest.TestCase):
    def test_valid_readback_and_counters(self):
        result = validate()
        self.assertTrue(result["ok"], result["errors"])
        self.assertEqual(result["counters"]["output_allow"]["packets"], 1)
        self.assertEqual(result["counters"]["output_allow"]["bytes"], 10)
        self.assertIn("output_gateway", result["counters"])
        self.assertIn("output_second_network", result["counters"])
        self.assertIn("output_docker_dns", result["counters"])
        self.assertIn("output_loopback", result["counters"])
        self.assertIn("output_udp", result["counters"])
        self.assertIn("output_default", result["counters"])
        self.assertIn("input_established", result["counters"])
        self.assertIn("output_v6_loopback", result["counters"])
        self.assertIn("output_v6_test_address", result["counters"])
        self.assertEqual(result["families"]["ipv4"]["ok"], True)
        self.assertEqual(result["families"]["ipv6"]["ok"], True)
        self.assertEqual(result["chains"]["ipv4"]["OUTPUT"]["policy"], "DROP")

    def test_ipv4_accept_tamper_fails_closed(self):
        tampered = (save_from_batch(v4_batch())
                    .replace("-j ACCEPT", "-j DROP", 1))
        result = egress.validate_readback(
            tampered, save_from_batch(v6_batch(), ipv6=True),
            MARKER, TARGET, gateway_ip=GATEWAY, sentinel_ip=SENTINEL)
        self.assertFalse(result["ok"])
        self.assertTrue(any("output_allow" in error
                            for error in result["errors"]))

    def test_ipv6_accept_tamper_fails_closed(self):
        v6 = save_from_batch(v6_batch(), ipv6=True).replace(
            "COMMIT", "-A OUTPUT -j ACCEPT\nCOMMIT")
        result = egress.validate_readback(
            save_from_batch(v4_batch()), v6, MARKER, TARGET,
            gateway_ip=GATEWAY, sentinel_ip=SENTINEL)
        self.assertFalse(result["ok"])

    def test_missing_ipv6_rule_fails_closed(self):
        v6_text = save_from_batch(v6_batch(), ipv6=True)
        v6_text = "\n".join(
            line for line in v6_text.splitlines()
            if egress.IPV6_TEST_ADDRESS not in line) + "\n"
        result = egress.validate_readback(
            save_from_batch(v4_batch()), v6_text, MARKER, TARGET,
            gateway_ip=GATEWAY, sentinel_ip=SENTINEL)
        self.assertFalse(result["ok"])
        self.assertTrue(any("ipv6" in error for error in result["errors"]))

    def test_wrong_endpoint_fails_closed(self):
        result = egress.validate_readback(
            save_from_batch(egress.render_ipv4_policy(
                MARKER, "10.0.0.99", gateway_ip=GATEWAY,
                sentinel_ip=SENTINEL)),
            save_from_batch(v6_batch(), ipv6=True),
            MARKER, TARGET, gateway_ip=GATEWAY, sentinel_ip=SENTINEL)
        self.assertFalse(result["ok"])

    def test_chain_policy_accept_fails_closed(self):
        v4_text = save_from_batch(v4_batch()).replace(
            ":OUTPUT DROP [0:0]", ":OUTPUT ACCEPT [0:0]")
        result = egress.validate_readback(
            v4_text, save_from_batch(v6_batch(), ipv6=True),
            MARKER, TARGET, gateway_ip=GATEWAY, sentinel_ip=SENTINEL)
        self.assertFalse(result["ok"])
        self.assertTrue(any("policy" in error.lower()
                            for error in result["errors"]))

    def test_missing_counter_fails_closed(self):
        v4_text = save_from_batch(v4_batch())
        v4_text = v4_text.replace(
            f"[1:10] -A OUTPUT -d {TARGET}/32",
            f"-A OUTPUT -d {TARGET}/32", 1)
        result = egress.validate_readback(
            v4_text, save_from_batch(v6_batch(), ipv6=True),
            MARKER, TARGET, gateway_ip=GATEWAY, sentinel_ip=SENTINEL)
        self.assertFalse(result["ok"])

    def test_extra_rule_fails_closed(self):
        v4_text = save_from_batch(v4_batch()).replace(
            "COMMIT", "-A OUTPUT -d 198.51.100.9 -j ACCEPT\nCOMMIT")
        result = egress.validate_readback(
            v4_text, save_from_batch(v6_batch(), ipv6=True),
            MARKER, TARGET, gateway_ip=GATEWAY, sentinel_ip=SENTINEL)
        self.assertFalse(result["ok"])

    def test_rule_order_tamper_fails_closed(self):
        batch = v4_batch().splitlines()
        output_allow = next(
            index for index, line in enumerate(batch)
            if line.endswith("-j ACCEPT") and line.startswith("-A OUTPUT"))
        default_drop = next(
            index for index, line in enumerate(batch)
            if line == "-A OUTPUT -j DROP")
        batch[output_allow], batch[default_drop] = (
            batch[default_drop], batch[output_allow])
        tampered = save_from_batch("\n".join(batch) + "\n")
        result = egress.validate_readback(
            tampered, save_from_batch(v6_batch(), ipv6=True),
            MARKER, TARGET, gateway_ip=GATEWAY, sentinel_ip=SENTINEL)
        self.assertFalse(result["ok"])

    def test_parse_rejects_non_filter_table(self):
        with self.assertRaises(egress.EgressPolicyError):
            egress.parse_filter_save(
                "*nat\n:INPUT DROP [0:0]\nCOMMIT\n", "ipv4", MARKER)

    def test_parse_rejects_multiple_tables(self):
        text = save_from_batch(v4_batch()) + "*nat\nCOMMIT\n"
        with self.assertRaises(egress.EgressPolicyError):
            egress.parse_filter_save(text, "ipv4", MARKER)

    def test_parse_rejects_unknown_chain(self):
        text = save_from_batch(v4_batch()).replace(
            "COMMIT", ":USERCHAIN - [0:0]\nCOMMIT")
        with self.assertRaises(egress.EgressPolicyError):
            egress.parse_filter_save(text, "ipv4", MARKER)

    def test_counter_helpers(self):
        view = {"counters": {"output_allow": {"packets": 7}}}
        self.assertEqual(egress.counter_packets(view, "output_allow"), 7)
        self.assertIsNone(egress.counter_packets(view, "missing"))


class PolicyRuntimeTests(unittest.TestCase):
    class FakeRunner:
        def __init__(self, v4_text="", v6_text=""):
            self.calls = []
            self.v4_text = v4_text
            self.v6_text = v6_text

        def __call__(self, argv, input_text=None, timeout=None,
                     pass_fds=()):
            self.calls.append({
                "argv": list(argv), "input": input_text,
                "timeout": timeout, "pass_fds": tuple(pass_fds),
            })
            if "ip6tables-legacy-save" in argv:
                return subprocess.CompletedProcess(
                    argv, 0, self.v6_text, "")
            if "iptables-legacy-save" in argv:
                return subprocess.CompletedProcess(
                    argv, 0, self.v4_text, "")
            if "-6" in argv and "addr" in argv:
                return subprocess.CompletedProcess(
                    argv, 0, f"inet6 {egress.IPV6_TEST_ADDRESS}/128 "
                             "scope global\n", "")
            return subprocess.CompletedProcess(argv, 0, "", "")

    class Handle:
        fd = 9
        inode = 6
        host_inode = 5
        closed = False

        @property
        def distinct_from_host(self):
            return bool(self.inode and self.host_inode
                        and not (self.inode == self.host_inode))

    def test_runtime_passes_fd_batches_and_bounded_timeout(self):
        runner = self.FakeRunner()
        runtime = egress.PolicyRuntime(timeout=12.0, runner=runner)
        handle = self.Handle()
        runtime.install_v4(handle, v4_batch())
        runtime.install_v6(handle, v6_batch())
        runtime.readback_v4(handle)
        runtime.readback_v6(handle)
        runtime.host_readback_v4()
        runtime.host_readback_v6()
        install4, install6, read4, read6, host4, host6 = runner.calls
        self.assertEqual(install4["argv"][:3], [
            "nsenter", "--net=/proc/self/fd/9", "--"])
        self.assertEqual(install4["argv"][-2:],
                         ["iptables-legacy-restore", "--wait=5"])
        self.assertEqual(install4["input"], v4_batch())
        self.assertEqual(install4["pass_fds"], (9,))
        self.assertEqual(install4["timeout"], 12.0)
        self.assertEqual(install6["argv"][-2:],
                         ["ip6tables-legacy-restore", "--wait=5"])
        self.assertEqual(install6["input"], v6_batch())
        self.assertIn("iptables-legacy-save", read4["argv"])
        self.assertIn("-c", read4["argv"])
        self.assertEqual(read4["pass_fds"], (9,))
        self.assertIn("ip6tables-legacy-save", read6["argv"])
        self.assertEqual(host4["argv"],
                         ["iptables-legacy-save", "-t", "filter"])
        self.assertEqual(host4["pass_fds"], ())
        self.assertEqual(host6["argv"],
                         ["ip6tables-legacy-save", "-t", "filter"])

    def test_runtime_rejects_closed_or_host_handle(self):
        runtime = egress.PolicyRuntime(runner=self.FakeRunner())
        closed = self.Handle()
        closed.closed = True
        with self.assertRaises(egress.EgressPolicyError):
            runtime.install_v4(closed, "batch")
        host = self.Handle()
        host.inode = host.host_inode
        self.assertFalse(host.distinct_from_host)
        with self.assertRaises(egress.EgressPolicyError):
            runtime.readback_v4(host)

    def test_ipv6_address_setup_and_readback_use_namespace(self):
        runner = self.FakeRunner()
        runtime = egress.PolicyRuntime(timeout=5.0, runner=runner)
        handle = self.Handle()
        proc = runtime.configure_ipv6_address(
            handle, egress.IPV6_TEST_ADDRESS)
        self.assertEqual(proc.returncode, 0)
        readback = runtime.readback_ipv6_address(handle)
        self.assertIn(egress.IPV6_TEST_ADDRESS, readback.stdout)
        link, address, read = runner.calls
        self.assertEqual(link["argv"][:3], [
            "nsenter", "--net=/proc/self/fd/9", "--"])
        self.assertIn("link", link["argv"])
        self.assertIn("lo", link["argv"])
        self.assertIn("addr", address["argv"])
        self.assertIn(f"{egress.IPV6_TEST_ADDRESS}/128", address["argv"])
        self.assertIn("show", read["argv"])
        self.assertEqual(link["pass_fds"], (9,))

    def test_ipv6_address_setup_stops_when_link_fails(self):
        class LinkFailRunner(self.FakeRunner):
            def __call__(self, argv, input_text=None, timeout=None,
                         pass_fds=()):
                self.calls.append({"argv": list(argv)})
                return subprocess.CompletedProcess(argv, 1, "", "bad link")

        runner = LinkFailRunner()
        runtime = egress.PolicyRuntime(timeout=5.0, runner=runner)
        proc = runtime.configure_ipv6_address(
            self.Handle(), egress.IPV6_TEST_ADDRESS)
        self.assertEqual(proc.returncode, 1)
        self.assertEqual(len(runner.calls), 1)

    def test_firewall_digest_and_marker_helpers(self):
        first = egress.firewall_digest("a", "b")
        self.assertEqual(first, egress.firewall_digest("a", "b"))
        self.assertNotEqual(first, egress.firewall_digest("a", "c"))
        self.assertTrue(egress.marker_present("rule " + MARKER, MARKER))
        self.assertFalse(egress.marker_present("other", MARKER))
        with self.assertRaises(egress.EgressPolicyError):
            egress.marker_present("x", "bad marker")

    def test_firewall_digest_ignores_comments_counters_and_timestamps(self):
        first = egress.firewall_digest(
            "# Generated by iptables-save on Mon\n*filter\n"
            ":INPUT DROP [3:30]\n[9:90] -A OUTPUT -j DROP\nCOMMIT\n",
            "# second\n*filter\n:INPUT DROP [0:0]\nCOMMIT\n")
        second = egress.firewall_digest(
            "# Generated by iptables-save on Tue\n*filter\n"
            ":INPUT DROP [77:770]\n[1:2] -A OUTPUT -j DROP\nCOMMIT\n",
            "# other comment\n*filter\n:INPUT DROP [4:40]\nCOMMIT\n")
        self.assertEqual(first, second)
        self.assertNotEqual(
            first,
            egress.firewall_digest(
                "*filter\n:INPUT ACCEPT [0:0]\nCOMMIT\n",
                "*filter\n:INPUT DROP [0:0]\nCOMMIT\n"))
        self.assertEqual(
            egress.normalize_firewall_text(
                "\n# note\n:INPUT DROP [1:2]\n"),
            ":INPUT DROP [0:0]")


if __name__ == "__main__":
    unittest.main(verbosity=2)
