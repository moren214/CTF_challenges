"""End-to-end tests for the minimal runner and the TCP adapter.

Native-only baseline: these tests exercise the host build.  They do not
validate the Ubuntu 24.04 / x86-64 container (see README).
"""

from __future__ import annotations

import json
import os
import select
import socket
import struct
import subprocess
import sys
import tempfile
import time
import unittest
import uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
RUNNER = ROOT / "build" / "qjs_runner"
SERVER = ROOT / "adapter" / "server.py"
sys.path.insert(0, str(ROOT / "adapter"))
import server as adapter_server  # noqa: E402

DUMMY_FLAG = "qjs-test-flag-" + uuid.uuid4().hex
EVAL_TIMEOUT = 1.0


def free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def read_available_line(stream, timeout: float) -> bytes:
    ready, _, _ = select.select([stream], [], [], timeout)
    if not ready:
        raise TimeoutError("no line available")
    return stream.readline()


class Session:
    """One TCP connection == one worker and one persistent JS runtime."""

    def __init__(self, port: int, timeout: float = 10.0):
        self.sock = socket.create_connection(("127.0.0.1", port),
                                            timeout=timeout)
        self.sock.settimeout(timeout)
        self.reader = self.sock.makefile("rb")

    def send_raw(self, data: bytes) -> None:
        self.sock.sendall(data)

    def eval(self, code: str):
        self.send_raw((json.dumps({"code": code}) + "\n").encode("utf-8"))
        line = self.reader.readline()
        if not line:
            raise EOFError("connection closed")
        return json.loads(line)

    def read_line(self) -> bytes:
        return self.reader.readline()

    def close(self) -> None:
        try:
            self.reader.close()
        finally:
            self.sock.close()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()


class AdapterTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        if not RUNNER.is_file():
            raise unittest.SkipTest(f"runner not built: {RUNNER}")
        cls.port = free_port()
        # The verifier runs this suite against a read-only source bind mount,
        # so the adapter's diagnostic log must live outside the source tree.
        cls.log_dir = tempfile.TemporaryDirectory(prefix="qjs-adapter-log-")
        cls.log_path = Path(cls.log_dir.name) / "test-adapter.log"
        cls.log = cls.log_path.open("w")
        env = dict(os.environ)
        env["QJS_CTF_FLAG"] = DUMMY_FLAG
        env["PYTHONUNBUFFERED"] = "1"
        cls.proc = subprocess.Popen(
            [sys.executable, str(SERVER), "--port", str(cls.port),
             "--timeout", f"{EVAL_TIMEOUT:g}"],
            cwd=ROOT, env=env, stdout=subprocess.DEVNULL, stderr=cls.log)
        deadline = time.monotonic() + 10
        while time.monotonic() < deadline:
            if cls.proc.poll() is not None:
                cls.log.flush()
                raise RuntimeError(
                    f"adapter exited early; see {cls.log_path}")
            try:
                with socket.create_connection(("127.0.0.1", cls.port),
                                              timeout=0.2):
                    return
            except OSError:
                time.sleep(0.05)
        raise RuntimeError(f"adapter did not listen; see {cls.log_path}")

    @classmethod
    def tearDownClass(cls):
        cls.proc.terminate()
        try:
            cls.proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            cls.proc.kill()
            cls.proc.wait(timeout=5)
        cls.log.close()
        cls.log_dir.cleanup()

    def session(self) -> Session:
        return Session(self.port)

    # ---- language and data processing -------------------------------

    def test_arithmetic(self):
        with self.session() as s:
            reply = s.eval("({a: 1 + 2 * 3, b: 2 ** 10, c: 10 / 4, d: 0.1 + 0.2})")
            self.assertTrue(reply["ok"], reply)
            self.assertEqual(reply["result"], {
                "a": 7, "b": 1024, "c": 2.5, "d": 0.30000000000000004})

    def test_source_length_boundaries(self):
        # Regression: the runner must NUL-terminate the source buffer; some
        # lengths otherwise made the lexer read one byte past the input.
        with self.session() as s:
            for n in range(0, 65):
                reply = s.eval("1 + 1" + ";" * n)
                self.assertTrue(reply["ok"], (n, reply))
                self.assertEqual(reply["result"], 2, n)
            reply = s.eval("")
            self.assertTrue(reply["ok"], reply)
            self.assertEqual(reply["result"], {"$type": "undefined"})

    def test_json_processing(self):
        with self.session() as s:
            code = """
            (() => {
              const src = '{"a":[1,2,3],"b":{"ok":true}}';
              const d = JSON.parse(src);
              return {
                sum: d.a.reduce((x, y) => x + y, 0),
                keys: Object.keys(d),
                roundtrip: JSON.stringify(d)
              };
            })()
            """
            reply = s.eval(code)
            self.assertTrue(reply["ok"], reply)
            self.assertEqual(reply["result"]["sum"], 6)
            self.assertEqual(reply["result"]["keys"], ["a", "b"])
            self.assertEqual(json.loads(reply["result"]["roundtrip"]),
                             {"a": [1, 2, 3], "b": {"ok": True}})

    def test_objects_arrays_typedarrays_callbacks(self):
        with self.session() as s:
            reply = s.eval(
                "({mapped: Array.from(new Uint8Array([1,2,3]).map(x => x * 2)),"
                " sq: [1,2,3].map(x => x * x),"
                " fn: typeof ((x) => x),"
                " big: 123456789012345678901234567890n,"
                " inf: Infinity, nan: NaN, when: new Date(0)})")
            self.assertTrue(reply["ok"], reply)
            result = reply["result"]
            self.assertEqual(result["mapped"], [2, 4, 6])
            self.assertEqual(result["sq"], [1, 4, 9])
            self.assertEqual(result["fn"], "function")
            self.assertEqual(result["big"],
                             {"$type": "bigint",
                              "value": "123456789012345678901234567890"})
            self.assertEqual(result["inf"], {"$type": "number", "value": "Infinity"})
            self.assertEqual(result["nan"], {"$type": "number", "value": "NaN"})
            self.assertEqual(result["when"], {"$type": "Date",
                                              "value": "1970-01-01T00:00:00.000Z"})

    def test_lone_surrogate_result_survives(self):
        # JSON can carry a lone surrogate but UTF-8 cannot encode it directly;
        # the adapter must fall back to ASCII escaping and keep the session.
        with self.session() as s:
            reply = s.eval('"\\ud800"')
            self.assertTrue(reply["ok"], reply)
            self.assertEqual(reply["result"], "\ud800")
            self.assertEqual(s.eval("1 + 1")["result"], 2)

    def test_typedarray_serialization(self):
        with self.session() as s:
            reply = s.eval("new Uint8Array([4, 5, 6])")
            self.assertTrue(reply["ok"], reply)
            self.assertEqual(reply["result"], {
                "$type": "Uint8Array", "length": 3, "data": [4, 5, 6]})

    def test_callbacks_persist_across_evaluations(self):
        with self.session() as s:
            self.assertEqual(s.eval("globalThis.twice = (fn, x) => fn(fn(x));"
                                    " typeof twice")["result"], "function")
            reply = s.eval("twice(n => n + 5, 1)")
            self.assertTrue(reply["ok"], reply)
            self.assertEqual(reply["result"], 11)

    def test_cycles_are_reported_not_fatal(self):
        with self.session() as s:
            reply = s.eval("const a = {}; a.self = a; a")
            self.assertTrue(reply["ok"], reply)
            self.assertEqual(reply["result"], {"self": {"$type": "cycle"}})
            self.assertEqual(s.eval("1 + 1")["result"], 2)

    # ---- session semantics ------------------------------------------

    def test_state_persists_on_one_connection(self):
        with self.session() as s:
            self.assertEqual(s.eval("globalThis.counter = 41; counter")["result"], 41)
            self.assertEqual(s.eval("counter + 1")["result"], 42)
            self.assertEqual(s.eval("globalThis.obj = {n: 7}; obj.n")["result"], 7)
            self.assertEqual(s.eval("obj.n *= 6; obj.n")["result"], 42)

    def test_connections_are_isolated_and_have_distinct_workers(self):
        with self.session() as a, self.session() as b:
            self.assertEqual(a.eval("globalThis.leak = 99; leak")["result"], 99)
            self.assertEqual(b.eval("typeof leak")["result"], "undefined")
            self.assertEqual(b.eval("globalThis.leak = 'b'; leak")["result"], "b")
            self.assertEqual(a.eval("leak")["result"], 99)

    # ---- exceptions and recovery ------------------------------------

    def test_js_exception_then_recovery(self):
        with self.session() as s:
            self.assertEqual(s.eval("globalThis.keep = 7; keep")["result"], 7)
            reply = s.eval('throw new TypeError("boom")')
            self.assertFalse(reply["ok"])
            self.assertEqual(reply["error"]["name"], "TypeError")
            self.assertEqual(reply["error"]["message"], "boom")
            self.assertIn("stack", reply["error"])
            self.assertEqual(s.eval("keep + 1")["result"], 8)

    def test_syntax_error_then_recovery(self):
        with self.session() as s:
            reply = s.eval("let = ;")
            self.assertFalse(reply["ok"])
            self.assertEqual(reply["error"]["name"], "SyntaxError")
            self.assertEqual(s.eval('"still alive"')["result"], "still alive")

    def test_thrown_primitive_then_recovery(self):
        with self.session() as s:
            reply = s.eval("throw 42")
            self.assertFalse(reply["ok"])
            self.assertEqual(reply["error"]["name"], "ThrownValue")
            self.assertEqual(reply["error"]["message"], "42")
            self.assertEqual(s.eval("40 + 2")["result"], 42)

    def test_stack_overflow_is_bounded_and_recoverable(self):
        with self.session() as s:
            reply = s.eval("function r() { return r(); } r()")
            self.assertFalse(reply["ok"])
            self.assertEqual(reply["error"]["name"], "InternalError")
            self.assertIn("stack overflow", reply["error"]["message"])
            self.assertLessEqual(len(reply["error"]["stack"]), 9000)
            self.assertEqual(s.eval("6 * 7")["result"], 42)

    # ---- host surface ------------------------------------------------

    def test_no_host_apis_or_module_loader(self):
        with self.session() as s:
            code = """
            (() => {
              const names = Object.getOwnPropertyNames(globalThis);
              const forbidden = ['std', 'os', 'require', 'process', 'module',
                                 'readFile', 'read', 'write', 'console', 'Deno', 'Bun'];
              return {
                types: [typeof std, typeof os, typeof require, typeof process,
                        typeof module, typeof readFile, typeof Deno, typeof Bun],
                globals: names.filter(k => forbidden.indexOf(k) >= 0),
                requireError: (() => {
                  try { require('fs'); return 'no-error'; }
                  catch (e) { return e.name; }
                })(),
                evalType: new Function('return typeof process')()
              };
            })()
            """
            reply = s.eval(code)
            self.assertTrue(reply["ok"], reply)
            result = reply["result"]
            self.assertEqual(result["types"],
                             ["undefined"] * 8)
            self.assertEqual(result["globals"], [])
            self.assertEqual(result["requireError"], "ReferenceError")
            self.assertEqual(result["evalType"], "undefined")

    def test_instance_flag_is_not_visible_to_javascript(self):
        with self.session() as s:
            flag_literal = json.dumps(DUMMY_FLAG)
            code = f"""
            (() => {{
              const hits = [];
              for (const k of Object.getOwnPropertyNames(globalThis)) {{
                try {{
                  if (String(globalThis[k]).indexOf({flag_literal}) >= 0) hits.push(k);
                }} catch (e) {{}}
              }}
              return {{
                hits,
                probe: typeof process + ',' + typeof std + ',' + typeof os,
                globals: Object.getOwnPropertyNames(globalThis).join(',')
              }};
            }})()
            """
            reply = s.eval(code)
            self.assertTrue(reply["ok"], reply)
            self.assertEqual(reply["result"]["hits"], [])
            self.assertEqual(reply["result"]["probe"],
                             "undefined,undefined,undefined")
            self.assertNotIn(DUMMY_FLAG, json.dumps(reply))

    # ---- limits ------------------------------------------------------

    def test_oversized_source_is_rejected_and_session_survives(self):
        with self.session() as s:
            reply = s.eval("x" * (adapter_server.MAX_SOURCE_BYTES + 1))
            self.assertFalse(reply["ok"])
            self.assertEqual(reply["error"]["name"], "InputLimitError")
            self.assertNotIn("fatal", reply)
            self.assertEqual(s.eval("40 + 2")["result"], 42)

    def test_oversized_output_is_rejected_and_session_survives(self):
        with self.session() as s:
            self.assertEqual(s.eval("globalThis.marker = 'alive'; marker")["result"],
                             "alive")
            reply = s.eval('"x".repeat(2 * 1024 * 1024)')
            self.assertFalse(reply["ok"])
            self.assertEqual(reply["error"]["name"], "OutputLimitError")
            self.assertNotIn("fatal", reply)
            self.assertEqual(s.eval("marker + '!'")["result"], "alive!")

    def test_memory_limit_is_enforced_and_session_recovers(self):
        with self.session() as s:
            reply = s.eval("new Uint8Array(256 * 1024 * 1024)")
            self.assertFalse(reply["ok"])
            self.assertEqual(reply["error"]["name"], "InternalError")
            self.assertIn("out of memory", reply["error"]["message"])
            self.assertEqual(s.eval("6 * 7")["result"], 42)

    def test_oversized_request_line_is_fatal_and_worker_is_cleaned_up(self):
        with Session(self.port) as s:
            payload = (b'{"code":"' +
                       b"a" * (adapter_server.MAX_LINE_BYTES + 1024) +
                       b'"}\n')
            s.send_raw(payload)
            line = s.read_line()
            self.assertTrue(line)
            reply = json.loads(line)
            self.assertFalse(reply["ok"])
            self.assertEqual(reply["error"]["name"], "InputLimitError")
            self.assertTrue(reply["fatal"])
            self.assertEqual(s.read_line(), b"")
        # The adapter is still healthy and can start a fresh worker.
        with self.session() as s:
            self.assertEqual(s.eval("5 + 5")["result"], 10)

    def test_timeout_terminates_worker_and_cleans_up(self):
        with Session(self.port) as s:
            reply = s.eval("while (true) {}")
            self.assertFalse(reply["ok"])
            self.assertEqual(reply["error"]["name"], "TimeoutError")
            self.assertTrue(reply["fatal"])
            self.assertEqual(s.read_line(), b"")
        # The adapter is still healthy and can start a fresh worker.
        with self.session() as s:
            self.assertEqual(s.eval("5 + 5")["result"], 10)
        with self.session() as s:
            self.assertEqual(s.eval("21 * 2")["result"], 42)

    # ---- framing -----------------------------------------------------

    def test_invalid_json_is_nonfatal(self):
        with self.session() as s:
            s.send_raw(b"not json\n")
            reply = json.loads(s.read_line())
            self.assertFalse(reply["ok"])
            self.assertEqual(reply["error"]["name"], "ProtocolError")
            self.assertNotIn("fatal", reply)
            self.assertEqual(s.eval("1 + 1")["result"], 2)

    def test_missing_code_field_is_nonfatal(self):
        with self.session() as s:
            s.send_raw(b'{"nope": 1}\n')
            reply = json.loads(s.read_line())
            self.assertFalse(reply["ok"])
            self.assertEqual(reply["error"]["name"], "ProtocolError")
            self.assertEqual(s.eval("2 + 2")["result"], 4)

    def test_invalid_utf8_request_is_nonfatal(self):
        with self.session() as s:
            s.send_raw(b'{"code":"\xff\xfe"}\n')
            reply = json.loads(s.read_line())
            self.assertFalse(reply["ok"])
            self.assertEqual(reply["error"]["name"], "ProtocolError")
            self.assertEqual(s.eval("3 + 3")["result"], 6)


class RunnerFlagTest(unittest.TestCase):
    """The runner, not JavaScript, sees the injected instance flag."""

    def _spawn(self, env_extra):
        env = {"LC_ALL": "C", "LANG": "C"}
        env.update(env_extra)
        proc = subprocess.Popen([str(RUNNER)], stdin=subprocess.PIPE,
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                env=env, bufsize=0)
        line = read_available_line(proc.stderr, 5.0)
        return proc, line

    @staticmethod
    def _read_exact(stream, n: int) -> bytes:
        chunks = []
        remaining = n
        while remaining:
            chunk = stream.read(remaining)
            if not chunk:
                raise EOFError("runner closed stdout")
            chunks.append(chunk)
            remaining -= len(chunk)
        return b"".join(chunks)

    @classmethod
    def _eval(cls, proc, code: str):
        raw = code.encode("utf-8")
        proc.stdin.write(struct.pack(">I", len(raw)) + raw)
        proc.stdin.flush()
        header = cls._read_exact(proc.stdout, 5)
        status = header[:1]
        length = struct.unpack(">I", header[1:])[0]
        payload = cls._read_exact(proc.stdout, length) if length else b""
        return status, payload

    @staticmethod
    def _close_proc(proc) -> None:
        try:
            proc.stdin.close()
        except OSError:
            pass
        proc.wait(timeout=5)
        for stream in (proc.stdout, proc.stderr):
            try:
                stream.close()
            except OSError:
                pass

    def test_flag_present_at_os_level_not_js_visible(self):
        if not RUNNER.is_file():
            self.skipTest(f"runner not built: {RUNNER}")
        proc, line = self._spawn({"QJS_CTF_FLAG": DUMMY_FLAG})
        try:
            self.assertIn(b"instance flag present", line)
            self.assertNotIn(DUMMY_FLAG.encode(), line)
            status, payload = self._eval(
                proc, "typeof process + ',' + typeof std + ',' + typeof os")
            self.assertEqual(status, b"O")
            self.assertEqual(json.loads(payload),
                             "undefined,undefined,undefined")
            self.assertNotIn(DUMMY_FLAG.encode(), payload)
        finally:
            self._close_proc(proc)

    def test_runner_rejects_oversized_source_header(self):
        if not RUNNER.is_file():
            self.skipTest(f"runner not built: {RUNNER}")
        proc, _line = self._spawn({})
        try:
            proc.stdin.write(struct.pack(">I",
                                         adapter_server.MAX_SOURCE_BYTES + 1))
            proc.stdin.flush()
            header = self._read_exact(proc.stdout, 5)
            self.assertEqual(header[:1], b"L")
            length = struct.unpack(">I", header[1:])[0]
            payload = self._read_exact(proc.stdout, length)
            err = json.loads(payload)
            self.assertEqual(err["name"], "InputLimitError")
            self.assertEqual(proc.stdout.read(1), b"")
        finally:
            self._close_proc(proc)

    def test_flag_absent_diagnostic(self):
        if not RUNNER.is_file():
            self.skipTest(f"runner not built: {RUNNER}")
        proc, line = self._spawn({})
        try:
            self.assertIn(b"instance flag absent", line)
        finally:
            self._close_proc(proc)


class FlagFileAdapterTest(unittest.TestCase):
    """File-based flag injection, conflicting modes, and failure behavior."""

    @classmethod
    def setUpClass(cls):
        if not RUNNER.is_file():
            raise unittest.SkipTest(f"runner not built: {RUNNER}")

    def _start(self, extra_args, env_extra=None, log_path=None):
        port = free_port()
        env = dict(os.environ)
        env.pop(adapter_server.WORKER_FLAG_ENV, None)
        env.pop("QJS_TEST_SOURCE_FLAG", None)
        env["PYTHONUNBUFFERED"] = "1"
        env.update(env_extra or {})
        log = open(log_path, "w") if log_path else subprocess.DEVNULL
        proc = subprocess.Popen(
            [sys.executable, str(SERVER), "--port", str(port),
             "--timeout", "2", *extra_args],
            cwd=ROOT, env=env, stdout=subprocess.DEVNULL, stderr=log)
        deadline = time.monotonic() + 10
        while time.monotonic() < deadline:
            if proc.poll() is not None:
                raise RuntimeError("adapter exited before listening")
            try:
                with socket.create_connection(("127.0.0.1", port), timeout=0.2):
                    return proc, port, log
            except OSError:
                time.sleep(0.05)
        proc.kill()
        raise RuntimeError("adapter did not listen")

    @staticmethod
    def _stop(proc, log):
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait(timeout=5)
        if log is not subprocess.DEVNULL:
            log.close()

    def _run_failing(self, extra_args, env_extra=None):
        env = dict(os.environ)
        env.pop(adapter_server.WORKER_FLAG_ENV, None)
        env.pop("QJS_TEST_SOURCE_FLAG", None)
        env.update(env_extra or {})
        proc = subprocess.Popen(
            [sys.executable, str(SERVER), "--port", str(free_port()),
             "--timeout", "2", *extra_args],
            cwd=ROOT, env=env, stdout=subprocess.PIPE,
            stderr=subprocess.PIPE, text=True)
        out, err = proc.communicate(timeout=10)
        return proc.returncode, out, err

    def test_flag_file_mode_reaches_worker_and_is_not_visible(self):
        flag = "FILE-FLAG-" + uuid.uuid4().hex
        with tempfile.TemporaryDirectory() as td:
            flag_path = Path(td) / "instance-flag"
            flag_path.write_text(flag + "\n")
            os.chmod(flag_path, 0o400)
            log_path = Path(td) / "adapter.log"
            proc, port, log = self._start(
                ["--flag-file", str(flag_path)], log_path=log_path)
            try:
                with Session(port) as s:
                    reply = s.eval(
                        "({had: typeof process != 'undefined',"
                        " names: Object.getOwnPropertyNames(globalThis).join(',')})")
                    self.assertTrue(reply["ok"], reply)
                    self.assertFalse(reply["result"]["had"])
                    self.assertNotIn(flag, json.dumps(reply))
                    self.assertEqual(s.eval("1 + 1")["result"], 2)
            finally:
                self._stop(proc, log)
            log_text = log_path.read_text(errors="replace")
            self.assertNotIn(flag, log_text)
            self.assertIn("flag source file:", log_text)
            self.assertIn("configured", log_text)
            self.assertNotIn("flag file is writable", log_text)

    def test_nondefault_env_name_is_forwarded_to_worker(self):
        flag = "ENV-NAME-" + uuid.uuid4().hex
        with tempfile.TemporaryDirectory() as td:
            log_path = Path(td) / "adapter.log"
            proc, port, log = self._start(
                ["--flag-env", "QJS_TEST_SOURCE_FLAG"],
                env_extra={"QJS_TEST_SOURCE_FLAG": flag}, log_path=log_path)
            try:
                with Session(port) as s:
                    reply = s.eval("6 * 7")
                    self.assertTrue(reply["ok"], reply)
                    self.assertEqual(reply["result"], 42)
                    self.assertNotIn(flag, json.dumps(reply))
            finally:
                self._stop(proc, log)
            self.assertNotIn(flag, log_path.read_text(errors="replace"))

    def test_conflicting_file_and_env_modes_fail(self):
        flag = "CONFLICT-" + uuid.uuid4().hex
        with tempfile.TemporaryDirectory() as td:
            flag_path = Path(td) / "instance-flag"
            flag_path.write_text(flag)
            code, out, err = self._run_failing(
                ["--flag-file", str(flag_path)],
                env_extra={adapter_server.WORKER_FLAG_ENV: flag})
            self.assertNotEqual(code, 0)
            self.assertIn("conflicting flag sources", err)
            self.assertNotIn(flag, out + err)

    def test_missing_flag_file_fails_visibly(self):
        missing = str(Path(tempfile.gettempdir()) /
                      ("missing-flag-" + uuid.uuid4().hex))
        code, out, err = self._run_failing(["--flag-file", missing])
        self.assertNotEqual(code, 0)
        self.assertIn("flag file not found", err)
        self.assertNotIn(missing, out)

    def test_directory_as_flag_file_fails_visibly(self):
        with tempfile.TemporaryDirectory() as td:
            code, out, err = self._run_failing(["--flag-file", td])
            self.assertNotEqual(code, 0)
            self.assertIn("not a regular file", err)

    def test_empty_flag_file_fails_visibly(self):
        with tempfile.TemporaryDirectory() as td:
            flag_path = Path(td) / "empty"
            flag_path.write_text("\n")
            code, out, err = self._run_failing(["--flag-file", str(flag_path)])
            self.assertNotEqual(code, 0)
            self.assertIn("flag file is empty", err)

    def test_unreadable_flag_file_fails_visibly(self):
        if os.geteuid() == 0:
            self.skipTest("root can read mode-000 files")
        with tempfile.TemporaryDirectory() as td:
            flag_path = Path(td) / "unreadable"
            flag_path.write_text("secret-value")
            os.chmod(flag_path, 0)
            try:
                code, out, err = self._run_failing(
                    ["--flag-file", str(flag_path)])
            finally:
                os.chmod(flag_path, 0o600)
            self.assertNotEqual(code, 0)
            self.assertIn("not readable", err)
            self.assertNotIn("secret-value", out + err)


class FlagFileLoaderUnitTest(unittest.TestCase):
    """Pure unit tests for flag-file parsing and source resolution."""

    def test_strips_one_trailing_newline(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "f"
            path.write_bytes(b"FLAG{abc}\n")
            self.assertEqual(adapter_server.load_flag_file(str(path)), "FLAG{abc}")
            path.write_bytes(b"FLAG{abc}\r\n")
            self.assertEqual(adapter_server.load_flag_file(str(path)), "FLAG{abc}")
            path.write_bytes(b"FLAG{abc}")
            self.assertEqual(adapter_server.load_flag_file(str(path)), "FLAG{abc}")

    def test_rejects_empty_nul_and_non_utf8(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "f"
            for data, message in ((b"", "empty"), (b"a\x00b", "NUL"),
                                   (b"\xff", "UTF-8")):
                path.write_bytes(data)
                with self.assertRaises(adapter_server.FlagConfigError) as cm:
                    adapter_server.load_flag_file(str(path))
                self.assertIn(message, str(cm.exception))

    def test_rejects_oversized_file(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "f"
            path.write_bytes(b"x" * (adapter_server.MAX_FLAG_FILE_BYTES + 1))
            with self.assertRaises(adapter_server.FlagConfigError) as cm:
                adapter_server.load_flag_file(str(path))
            self.assertIn("exceeds", str(cm.exception))

    def test_resolve_prefers_file_and_rejects_conflict(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "f"
            path.write_text("FILE-VALUE")
            value, source = adapter_server.resolve_flag(
                "QJS_TEST_SOURCE_FLAG", str(path), environ={})
            self.assertEqual(value, "FILE-VALUE")
            self.assertTrue(source.startswith("file:"))
            with self.assertRaises(adapter_server.FlagConfigError):
                adapter_server.resolve_flag(
                    "QJS_TEST_SOURCE_FLAG", str(path),
                    environ={"QJS_TEST_SOURCE_FLAG": "ENV-VALUE"})

    def test_resolve_env_mode_and_disabled_mode(self):
        value, source = adapter_server.resolve_flag(
            "QJS_TEST_SOURCE_FLAG", None,
            environ={"QJS_TEST_SOURCE_FLAG": "ENV-VALUE"})
        self.assertEqual(value, "ENV-VALUE")
        self.assertEqual(source, "env:QJS_TEST_SOURCE_FLAG")
        value, source = adapter_server.resolve_flag(
            "QJS_TEST_SOURCE_FLAG", None, environ={})
        self.assertIsNone(value)
        self.assertEqual(source, "none")
        value, source = adapter_server.resolve_flag(
            "", None, environ={"QJS_TEST_SOURCE_FLAG": "ENV-VALUE"})
        self.assertIsNone(value)


class AdapterShutdownRaceTest(unittest.TestCase):
    """Regression: a worker tracked after cleanup must not escape shutdown."""

    class FakeWorker:
        def __init__(self):
            self.killed = False

        def kill(self):
            self.killed = True

    def test_track_after_cleanup_kills_worker_immediately(self):
        server = adapter_server.AdapterServer(
            ("127.0.0.1", 0), str(RUNNER), 1.0,
            adapter_server.WORKER_FLAG_ENV, None)
        try:
            server.cleanup_workers()
            racing = self.FakeWorker()
            server.track(racing)
            self.assertTrue(racing.killed)
            self.assertEqual(server._workers, set())
        finally:
            server.server_close()

    def test_normal_track_and_untrack(self):
        server = adapter_server.AdapterServer(
            ("127.0.0.1", 0), str(RUNNER), 1.0,
            adapter_server.WORKER_FLAG_ENV, None)
        worker = self.FakeWorker()
        try:
            server.track(worker)
            self.assertIn(worker, server._workers)
            server.untrack(worker)
            self.assertNotIn(worker, server._workers)
            self.assertFalse(worker.killed)
        finally:
            server.server_close()


class WorkerLifecycleTest(unittest.TestCase):
    """Direct worker tests for cleanup, timeout kill, and isolation."""

    def setUp(self):
        if not RUNNER.is_file():
            self.skipTest(f"runner not built: {RUNNER}")

    def test_timeout_sigkills_worker(self):
        worker = adapter_server.Worker(str(RUNNER), 0.3,
                                       "QJS_CTF_FLAG", DUMMY_FLAG)
        try:
            reply, close = worker.evaluate("while (true) {}")
            self.assertTrue(close)
            self.assertEqual(reply["error"]["name"], "TimeoutError")
            self.assertIsNotNone(worker.proc.poll())
            self.assertLess(worker.proc.returncode, 0,
                            "timed-out worker should die from a signal")
        finally:
            worker.kill()

    def test_flag_presence_handshake(self):
        with_flag = adapter_server.Worker(str(RUNNER), 2.0,
                                          "QJS_CTF_FLAG", DUMMY_FLAG)
        no_flag = adapter_server.Worker(str(RUNNER), 2.0,
                                        "QJS_CTF_FLAG", None)
        try:
            self.assertTrue(with_flag.flag_present)
            self.assertFalse(no_flag.flag_present)
        finally:
            with_flag.close()
            no_flag.close()

    def test_normal_close_exits_cleanly(self):
        worker = adapter_server.Worker(str(RUNNER), 2.0,
                                       "QJS_CTF_FLAG", DUMMY_FLAG)
        reply, close = worker.evaluate("6 * 7")
        self.assertFalse(close)
        self.assertEqual(reply["result"], 42)
        worker.close()
        self.assertIsNotNone(worker.proc.poll())
        self.assertEqual(worker.proc.returncode, 0)
        self.assertTrue(worker.proc.stdin.closed)

    def test_workers_have_separate_processes_and_state(self):
        w1 = adapter_server.Worker(str(RUNNER), 2.0, "QJS_CTF_FLAG", DUMMY_FLAG)
        w2 = adapter_server.Worker(str(RUNNER), 2.0, "QJS_CTF_FLAG", DUMMY_FLAG)
        try:
            self.assertNotEqual(w1.proc.pid, w2.proc.pid)
            r1, _ = w1.evaluate("globalThis.only = 1; only")
            r2, _ = w2.evaluate("typeof only")
            self.assertEqual(r1["result"], 1)
            self.assertEqual(r2["result"], "undefined")
        finally:
            w1.close()
            w2.close()


if __name__ == "__main__":
    unittest.main(verbosity=2)
