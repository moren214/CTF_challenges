"""Unit regressions for scripts/verify_runtime.py.

These are test-double and pure-function checks.  They do not claim that a
runtime image was built or run; real-engine results live in the report
produced by scripts/verify_runtime.py on a Docker-capable host.
"""

from __future__ import annotations

import importlib.util
import json
import os
import socket
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest import mock

ROOT = Path(__file__).resolve().parent.parent
SPEC = importlib.util.spec_from_file_location(
    "verify_runtime", ROOT / "scripts" / "verify_runtime.py")
verify_runtime = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(verify_runtime)


class FakeEngine:
    path = "/usr/bin/fake-engine"

    def __init__(self, responses=None):
        self.calls = []
        self.responses = responses or {}

    def run(self, argv, timeout=None, env=None):
        self.calls.append(list(argv))
        key = " ".join(argv)
        for pattern, response in self.responses.items():
            if pattern in key:
                rc, out, err = response
                return subprocess.CompletedProcess(argv, rc, out, err)
        return subprocess.CompletedProcess(argv, 0, "", "")

    def version(self):
        return "fake 1.0"


class BuildCommandTests(unittest.TestCase):
    def test_build_selects_runtime_stage_and_explicit_platform(self):
        argv = verify_runtime.build_argv(
            "docker", "tag:local", "ubuntu:24.04@sha256:" + "a" * 64,
            "linux/amd64", "/src/Dockerfile", "/src")
        self.assertEqual(argv[:4], ["docker", "build", "--platform",
                                    "linux/amd64"])
        self.assertIn("--target", argv)
        self.assertEqual(argv[argv.index("--target") + 1], "runtime")
        self.assertIn("BASE_IMAGE=ubuntu:24.04@sha256:" + "a" * 64, argv)
        self.assertEqual(argv[-1], "/src")
        self.assertNotIn("verify", argv)

    def test_build_offline_and_frontend_are_explicit(self):
        argv = verify_runtime.build_argv(
            "docker", "tag:local", "base@sha256:" + "b" * 64,
            "linux/amd64", "Dockerfile", ".", skip_apt=True,
            build_network="none", frontend="mirror/frontend@sha256:" + "c" * 64)
        self.assertIn("SKIP_APT=1", argv)
        self.assertIn("none", argv)
        self.assertIn(
            "BUILDKIT_SYNTAX=mirror/frontend@sha256:" + "c" * 64, argv)
        joined = " ".join(argv)
        self.assertNotIn("docker/dockerfile:1", joined)


class RuntimeCommandTests(unittest.TestCase):
    def runtime_argv(self, flag_path="/private/tmp/flag", detach=True):
        return verify_runtime.runtime_container_argv(
            "docker", "qjs-runtime-check-abc", "img:local", "linux/amd64",
            "instance-123", cpus=2.0, memory="2g", pids_limit=64,
            flag_host_path=flag_path, detach=detach)

    def test_runtime_container_is_hardened_and_unpublished(self):
        argv = self.runtime_argv()
        joined = " ".join(argv)
        self.assertIn("--network none", joined)
        self.assertIn("--read-only", joined)
        self.assertIn("--cap-drop ALL", joined)
        self.assertIn("--security-opt no-new-privileges:true", joined)
        self.assertIn("--memory 2g", joined)
        self.assertIn("--cpus 2", joined)
        self.assertIn("--pids-limit 64", joined)
        self.assertIn("--pull=never", joined)
        self.assertNotIn("--publish", argv)
        self.assertNotIn("-p", argv)
        self.assertIn("--name", argv)
        self.assertIn("type=bind,source=/private/tmp/flag,"
                      "target=/run/secrets/qjs_ctf_flag,readonly", argv)

    def test_missing_flag_control_does_not_mount_a_secret(self):
        argv = self.runtime_argv(flag_path=None, detach=False)
        joined = " ".join(argv)
        self.assertIn("--rm", argv)
        self.assertIn("--name", argv)
        self.assertNotIn("type=bind", joined)
        self.assertIn("--flag-file", argv)
        self.assertIn("/run/secrets/qjs_ctf_flag", argv)

    def test_flag_value_is_never_in_the_engine_command(self):
        flag = "FLAG{" + "d" * 32 + "}"
        argv = self.runtime_argv(flag_path="/private/tmp/secret-flag")
        self.assertNotIn(flag, " ".join(argv))


class ImageInspectionTests(unittest.TestCase):
    def image(self, user="qjs", cmd=None, env=None, entrypoint=None):
        return {
            "Architecture": "amd64",
            "Os": "linux",
            "User": user,
            "Cmd": cmd if cmd is not None else list(
                verify_runtime.EXPECTED_IMAGE_CMD),
            "Env": env or [],
            "Entrypoint": entrypoint,
        }

    def test_nonroot_user_detection(self):
        self.assertTrue(verify_runtime.is_nonroot_user("qjs"))
        self.assertTrue(verify_runtime.is_nonroot_user("10001:10001"))
        self.assertFalse(verify_runtime.is_nonroot_user(""))
        self.assertFalse(verify_runtime.is_nonroot_user("root"))
        self.assertFalse(verify_runtime.is_nonroot_user("0"))
        self.assertFalse(verify_runtime.is_nonroot_user("0:0"))

    def test_expected_command_must_match_exactly(self):
        self.assertTrue(verify_runtime.expected_command_matches(
            list(verify_runtime.EXPECTED_IMAGE_CMD)))
        self.assertFalse(verify_runtime.expected_command_matches(
            ["python3", "/app/adapter/server.py"]))

    def test_expected_command_is_the_image_default_not_file_mode(self):
        # The image CMD preserves environment mode; --flag-file belongs only
        # to the verifier's explicit runtime override.
        self.assertNotIn("--flag-file",
                         verify_runtime.EXPECTED_IMAGE_CMD)
        self.assertIn("--flag-file", verify_runtime.RUNTIME_FILE_CMD)
        self.assertEqual(
            verify_runtime.RUNTIME_FILE_CMD[:-2],
            verify_runtime.EXPECTED_IMAGE_CMD)
        self.assertEqual(verify_runtime.RUNTIME_FILE_CMD[-2:],
                         ["--flag-file",
                          verify_runtime.FLAG_PATH])

    def test_expected_image_command_matches_dockerfile_default(self):
        dockerfile = (ROOT / "Dockerfile").read_text().splitlines()
        cmd_lines = [line.strip() for line in dockerfile
                     if line.strip().startswith("CMD [")]
        self.assertTrue(cmd_lines, "Dockerfile has no JSON CMD")
        runtime_cmd = json.loads(cmd_lines[-1][len("CMD "):])
        self.assertEqual(runtime_cmd,
                         verify_runtime.IMAGE_DEFAULT_CMD)

    def test_image_security_summary_detects_baked_in_flag(self):
        flag = "FLAG{" + "e" * 32 + "}"
        summary = verify_runtime.image_security_summary(
            self.image(env=["QJS_CTF_FLAG=" + flag]), flag)
        self.assertTrue(summary["env_has_flag_variable"])
        self.assertTrue(summary["env_has_synthetic_flag"])
        self.assertTrue(summary["non_root_user"])
        summary = verify_runtime.image_security_summary(
            self.image(cmd=list(verify_runtime.EXPECTED_IMAGE_CMD) + [flag]),
            flag)
        self.assertTrue(summary["command_has_synthetic_flag"])

    def test_report_image_record_redacts_env_values_and_unexpected_cmd(self):
        record = verify_runtime.redacted_image_record({
            "Architecture": "amd64", "Os": "linux", "User": "qjs",
            "Cmd": ["evil", "FLAG{secret}"],
            "Entrypoint": ["/bin/evil"],
            "Env": ["SECRET_VALUE=top-secret"],
        })
        text = json.dumps(record)
        self.assertNotIn("top-secret", text)
        self.assertNotIn("FLAG{secret}", text)
        self.assertIn("SECRET_VALUE", record["env_names"])
        self.assertIn("redacted", record["Cmd"])
        self.assertIn("redacted", record["Entrypoint"])

    def test_parse_image_inspect_records_actual_identities(self):
        data = {
            "Id": "sha256:" + "f" * 64,
            "RepoDigests": [],
            "Architecture": "amd64",
            "Os": "linux",
            "Config": {"User": "qjs", "Cmd": list(
                verify_runtime.EXPECTED_IMAGE_CMD), "Env": []},
        }
        record = verify_runtime.parse_image_inspect(json.dumps(data))
        self.assertEqual(record["Id"], "sha256:" + "f" * 64)
        self.assertEqual(record["RepoDigests"], [])
        self.assertEqual(record["User"], "qjs")


class ProbeCheckTests(unittest.TestCase):
    def wire(self, result):
        return {"ok": True, "result": result}

    def test_runtime_probe_checks_require_real_behavior(self):
        flag = "FLAG{" + "a" * 32 + "}"
        probe = {
            "arithmetic": self.wire(7),
            "state_set": self.wire(41),
            "state_get": self.wire(42),
            "exception": {"ok": False,
                          "error": {"name": "Error",
                                    "message": "runtime-probe"}},
            "recovery": self.wire(3),
            "separate_connection": self.wire("undefined"),
            "host_apis": self.wire({name: "undefined" for name in
                                    verify_runtime.ABSENT_HOST_APIS}),
            "reply_blob": "safe",
        }
        checks = verify_runtime.runtime_probe_checks(probe, flag)
        self.assertTrue(checks["health_arithmetic"])
        self.assertTrue(checks["state_persistence"])
        self.assertTrue(checks["separate_connection_state"])
        self.assertTrue(checks["exception_recovered"])
        self.assertTrue(checks["host_apis_absent"])
        self.assertTrue(checks["flag_not_in_replies"])

        probe["reply_blob"] = "leak " + flag
        self.assertFalse(
            verify_runtime.runtime_probe_checks(probe, flag)
            ["flag_not_in_replies"])

    def test_bare_primitive_fixtures_are_rejected(self):
        # Regression for the original defect: the generated probe returns
        # adapter wire objects, so primitive fixtures must not be accepted.
        flag = "FLAG{" + "c" * 32 + "}"
        probe = {
            "arithmetic": 7,
            "state_set": 41,
            "state_get": 42,
            "exception": {"ok": False},
            "recovery": 3,
            "separate_connection": "undefined",
            "host_apis": {name: "undefined" for name in
                          verify_runtime.ABSENT_HOST_APIS},
            "reply_blob": "safe",
        }
        checks = verify_runtime.runtime_probe_checks(probe, flag)
        self.assertFalse(checks["health_arithmetic"])
        self.assertFalse(checks["state_persistence"])
        self.assertFalse(checks["separate_connection_state"])
        self.assertFalse(checks["exception_recovered"])
        self.assertFalse(checks["host_apis_absent"])

    def test_wrong_values_are_rejected(self):
        flag = "FLAG{" + "b" * 32 + "}"
        probe = {
            "arithmetic": self.wire(8),
            "state_get": self.wire(41),
            "state_set": self.wire(40),
            "separate_connection": self.wire(41),
            "exception": {"ok": True},
            "recovery": self.wire(4),
            "host_apis": self.wire({"require": "function"}),
            "reply_blob": "",
        }
        checks = verify_runtime.runtime_probe_checks(probe, flag)
        self.assertFalse(checks["health_arithmetic"])
        self.assertFalse(checks["state_persistence"])
        self.assertFalse(checks["separate_connection_state"])
        self.assertFalse(checks["exception_recovered"])
        self.assertFalse(checks["host_apis_absent"])


    def test_missing_flag_failure_must_be_visible(self):
        self.assertTrue(verify_runtime.missing_flag_visible(
            2, "qjs-adapter: flag configuration error: flag file not found: "
               "/run/secrets/qjs_ctf_flag\n"))
        self.assertFalse(verify_runtime.missing_flag_visible(
            1, "flag configuration error: flag file not found\n"))
        self.assertFalse(verify_runtime.missing_flag_visible(0, "started\n"))
        self.assertFalse(verify_runtime.missing_flag_visible(
            2, "some other error\n"))


def free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        return sock.getsockname()[1]


class NativeAdapterProbeRegressionTest(unittest.TestCase):
    """Exercise the generated probe against a real native adapter process."""

    @classmethod
    def setUpClass(cls):
        cls.runner = ROOT / "build" / "qjs_runner"
        if not cls.runner.is_file():
            raise unittest.SkipTest(f"runner not built: {cls.runner}")
        cls.flag = "FLAG{" + "d" * 32 + "}"
        cls.tempdir = tempfile.TemporaryDirectory()
        flag_path = Path(cls.tempdir.name) / "flag"
        flag_path.write_text(cls.flag + "\n")
        cls.port = free_port()
        env = dict(os.environ)
        env["PYTHONUNBUFFERED"] = "1"
        cls.proc = subprocess.Popen(
            [sys.executable, str(ROOT / "adapter" / "server.py"),
             "--host", "127.0.0.1", "--port", str(cls.port),
             "--runner", str(cls.runner), "--flag-file", str(flag_path)],
            cwd=ROOT, env=env,
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        deadline = time.monotonic() + 10
        while time.monotonic() < deadline:
            if cls.proc.poll() is not None:
                raise RuntimeError("native adapter exited during startup")
            try:
                with socket.create_connection(("127.0.0.1", cls.port),
                                              timeout=0.2):
                    return
            except OSError:
                time.sleep(0.05)
        raise RuntimeError("native adapter did not listen")

    @classmethod
    def tearDownClass(cls):
        cls.proc.terminate()
        try:
            cls.proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            cls.proc.kill()
            cls.proc.wait(timeout=5)
        cls.tempdir.cleanup()

    def test_generated_probe_satisfies_wire_checks(self):
        script = verify_runtime.runtime_probe_script(self.port)
        proc = subprocess.run([sys.executable, "-c", script],
                              capture_output=True, text=True, timeout=30)
        self.assertEqual(proc.returncode, 0, proc.stderr)
        probe = verify_runtime.parse_runtime_probe(proc.stdout)
        # The raw probe really carries wire envelopes, not primitives.
        self.assertEqual(probe["arithmetic"],
                         {"ok": True, "result": 7})
        self.assertEqual(probe["state_get"],
                         {"ok": True, "result": 42})
        self.assertEqual(probe["separate_connection"],
                         {"ok": True, "result": "undefined"})
        self.assertIsInstance(probe["host_apis"], dict)
        self.assertTrue(probe["host_apis"]["ok"])
        checks = verify_runtime.runtime_probe_checks(probe, self.flag)
        for key in ("health_arithmetic", "state_persistence",
                    "separate_connection_state", "exception_recovered",
                    "host_apis_absent", "flag_not_in_replies"):
            self.assertTrue(checks[key], key)

    def test_generated_health_script_uses_parameterized_port(self):
        script = verify_runtime.health_script(self.port)
        proc = subprocess.run([sys.executable, "-c", script],
                              capture_output=True, text=True, timeout=15)
        self.assertEqual(proc.returncode, 0, proc.stderr)
        self.assertIn("HEALTH_OK", proc.stdout)

class RuntimeConfigTests(unittest.TestCase):
    def inspect_data(self, cpus=2.0, memory=2 * 1024 ** 3, pids=64):
        return {
            "Config": {"User": "qjs"},
            "HostConfig": {
                "NetworkMode": "none",
                "Privileged": False,
                "ReadonlyRootfs": True,
                "CapDrop": ["ALL"],
                "SecurityOpt": ["no-new-privileges:true"],
                "Memory": memory,
                "NanoCpus": int(cpus * 1_000_000_000),
                "PidsLimit": pids,
                "PortBindings": {},
            },
            "Mounts": [{
                "Destination": "/run/secrets/qjs_ctf_flag",
                "RW": False,
                "Type": "bind",
            }],
        }

    def test_hardening_flags_are_read_from_actual_inspect(self):
        checks = verify_runtime.runtime_config_checks(self.inspect_data())
        for key in ("non_root_config", "network_none", "readonly_rootfs",
                    "cap_drop_all", "no_new_privileges",
                    "port_bindings_empty", "flag_mount_readonly"):
            self.assertTrue(checks[key], key)
        self.assertFalse(checks["privileged"])

    def test_limits_must_match_the_request(self):
        checks = verify_runtime.runtime_config_checks(self.inspect_data())
        self.assertTrue(verify_runtime.limits_match(checks, 2.0, "2g", 64))
        self.assertFalse(verify_runtime.limits_match(checks, 1.0, "2g", 64))
        self.assertFalse(verify_runtime.limits_match(checks, 2.0, "1g", 64))
        self.assertFalse(verify_runtime.limits_match(checks, 2.0, "2g", 32))

    def test_memory_parsing(self):
        self.assertEqual(verify_runtime.parse_memory_bytes("2g"),
                         2 * 1024 ** 3)
        self.assertEqual(verify_runtime.parse_memory_bytes("512m"),
                         512 * 1024 ** 2)
        self.assertEqual(verify_runtime.parse_memory_bytes("1024"), 1024)


class CleanupTests(unittest.TestCase):
    def make_verification(self, responses=None):
        report = {"commands": []}
        args = SimpleNamespace(
            container_prefix="qjs-runtime-check", cpus=2.0, memory="2g",
            pids_limit=64, platform="linux/amd64", startup_timeout=1.0)
        engine = FakeEngine(responses)
        verifier = verify_runtime.Verification(engine, args, report)
        verifier.container_name = "qjs-runtime-check-abc"
        verifier.missing_name = "qjs-runtime-check-missing-abc"
        return verifier, engine

    def test_cleanup_is_scoped_idempotent_and_removes_secret(self):
        verifier, engine = self.make_verification()
        first_dir = Path(tempfile.mkdtemp(prefix="qjs-runtime-flag-test-"))
        (first_dir / "flag").write_text("FLAG{redacted}")
        verifier.secret_dir = first_dir
        self.assertTrue(verifier.cleanup()["ok"])
        self.assertFalse(first_dir.exists())
        second_dir = Path(tempfile.mkdtemp(prefix="qjs-runtime-flag-test-"))
        verifier.secret_dir = second_dir
        result = verifier.cleanup()
        self.assertTrue(result["ok"])
        self.assertFalse(second_dir.exists())
        flat = " ".join(" ".join(call) for call in engine.calls)
        self.assertIn("rm -f", flat)
        self.assertNotIn("prune", flat)
        self.assertNotIn("kill", flat)
        for call in engine.calls:
            self.assertIn(call[0], ("/usr/bin/fake-engine",))
            self.assertEqual(call[1], "rm")

    def test_cleanup_failure_is_reported_without_global_actions(self):
        verifier, engine = self.make_verification({
            "rm": (1, "", "daemon busy"),
        })
        verifier.secret_dir = Path(tempfile.mkdtemp(
            prefix="qjs-runtime-flag-test-"))
        with mock.patch.object(verify_runtime.shutil, "rmtree"):
            result = verifier.cleanup()
        self.assertFalse(result["ok"])
        self.assertTrue(result["errors"])
        flat = " ".join(" ".join(call) for call in engine.calls)
        self.assertNotIn("prune", flat)
        self.assertNotIn("kill", flat)


class SkippedReportTests(unittest.TestCase):
    def test_no_engine_writes_skipped_report_and_exits_2(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "report.json"
            argv = [
                "verify_runtime.py", "--engine", str(
                    Path(td) / "no-such-engine"),
                "--base-image", "ubuntu:24.04", "--report", str(path),
            ]
            with mock.patch.object(sys, "argv", argv), \
                    mock.patch("sys.stderr"):
                code = verify_runtime.main()
            self.assertEqual(code, 2)
            report = json.loads(path.read_text())
            self.assertEqual(report["status"], "skipped")
            self.assertEqual(report["build"]["status"], "skipped")
            self.assertIn("nothing was built or run",
                          " ".join(report["limitations"]))


class ReportRedactionTests(unittest.TestCase):
    def make_verification(self, responses=None):
        report = {"commands": []}
        args = SimpleNamespace(
            container_prefix="qjs-runtime-check", cpus=2.0, memory="2g",
            pids_limit=64, platform="linux/amd64", startup_timeout=1.0)
        engine = FakeEngine(responses)
        verifier = verify_runtime.Verification(engine, args, report)
        return verifier, engine, report

    def test_retained_output_is_redacted_at_capture(self):
        flag = "FLAG{" + "1" * 32 + "}"
        verifier, engine, report = self.make_verification({
            "probe": (0, "reply " + flag + "\n",
                      "error tail " + flag + "\n"),
        })
        verifier.flag_value = flag
        verifier.run(["fake", "probe"], "probe", retain_output=True)
        serialized = json.dumps(report)
        self.assertNotIn(flag, serialized)
        self.assertIn("<redacted-flag>", serialized)

    def test_cleanup_errors_never_include_the_flag(self):
        flag = "FLAG{" + "2" * 32 + "}"
        verifier, engine, report = self.make_verification({
            "rm": (1, "", "daemon error with " + flag),
        })
        verifier.flag_value = flag
        verifier.container_name = "owned-runtime"
        verifier.secret_dir = Path(tempfile.mkdtemp(
            prefix="qjs-runtime-flag-test-"))
        result = verifier.cleanup()
        self.assertFalse(result["ok"])
        self.assertNotIn(flag, json.dumps(result))

    def test_final_report_redaction_covers_leak_paths(self):
        flag = "FLAG{" + "3" * 32 + "}"
        report = {
            "error": "failed with " + flag,
            "commands": [{"stdout_tail": "reply " + flag,
                          "stderr_tail": "log " + flag}],
            "runtime": {"probes": {"reply": "leak " + flag}},
            "cleanup": {"errors": [{"error": "cleanup " + flag}]},
        }
        redacted = verify_runtime.redact_value(report, flag)
        text = json.dumps(redacted)
        self.assertNotIn(flag, text)
        self.assertNotIn("FLAG{", text)
        self.assertIn("<redacted-flag>", text)

    def test_flag_literal_is_redacted_without_a_known_flag(self):
        text = verify_runtime.redact_text(
            "prefix FLAG{" + "a" * 32 + "} suffix")
        self.assertNotIn("FLAG{", text)
        self.assertIn("<redacted-flag>", text)


class ScanHelperTests(unittest.TestCase):
    def make_verification(self, responses=None):
        report = {"commands": []}
        args = SimpleNamespace(
            container_prefix="qjs-runtime-check", cpus=2.0, memory="2g",
            pids_limit=64, platform="linux/amd64", startup_timeout=1.0)
        engine = FakeEngine(responses)
        verifier = verify_runtime.Verification(engine, args, report)
        return verifier, engine, report

    def scan_payload(self):
        return json.dumps({
            "roots": ["/app", "/run/secrets"],
            "files_scanned": 12,
            "bytes_scanned": 345,
            "max_files": 5000,
            "max_file_bytes": 1024 * 1024,
            "files_limit_reached": False,
            "skipped_oversized_files": 1,
            "findings": [],
            "flag_path_exists": False,
        })

    def test_scan_helper_is_named_and_labelled(self):
        verifier, engine, report = self.make_verification({
            "qjsctf.role=scan": (0, self.scan_payload(), ""),
        })
        verifier.scan_image("img:local")
        argv = engine.calls[-1]
        self.assertIn("--name", argv)
        name = argv[argv.index("--name") + 1]
        self.assertIn(name, verifier.helper_names)
        self.assertIn(verify_runtime.LABEL_INSTANCE + "="
                      + verifier.instance_id, argv)
        self.assertIn(verify_runtime.LABEL_ROLE + "=scan", argv)
        self.assertNotIn("--rm", argv)
        self.assertIn(name, verifier.owned_references())

    def test_scan_bounds_are_reported_explicitly(self):
        verifier, engine, report = self.make_verification({
            "qjsctf.role=scan": (0, self.scan_payload(), ""),
        })
        result = verifier.scan_image("img:local")
        self.assertTrue(result["bounded"])
        self.assertEqual(result["max_files"], 5000)
        self.assertEqual(result["max_file_bytes"], 1024 * 1024)
        self.assertFalse(result["files_limit_reached"])
        self.assertEqual(result["skipped_oversized_files"], 1)
        self.assertEqual(result["status"], "clean")


class CleanupRobustnessTests(unittest.TestCase):
    def make_verification(self, engine):
        report = {"commands": []}
        args = SimpleNamespace(
            container_prefix="qjs-runtime-check", cpus=2.0, memory="2g",
            pids_limit=64, platform="linux/amd64", startup_timeout=1.0)
        verifier = verify_runtime.Verification(engine, args, report)
        verifier.container_name = "qjs-runtime-check-abc"
        verifier.missing_name = "qjs-runtime-check-missing-abc"
        verifier.helper_names = ["qjs-runtime-check-scan-abc"]
        verifier.secret_dir = Path(tempfile.mkdtemp(
            prefix="qjs-runtime-flag-test-"))
        (verifier.secret_dir / "flag").write_text("FLAG{redacted}")
        return verifier

    def test_first_rm_timeout_does_not_skip_later_resources_or_secret(self):
        class TimeoutFirstEngine(FakeEngine):
            def __init__(self):
                super().__init__()
                self.failed = False

            def run(self, argv, timeout=None, env=None):
                self.calls.append(list(argv))
                if "rm" in argv and not self.failed:
                    self.failed = True
                    raise subprocess.TimeoutExpired(argv, timeout or 1)
                return subprocess.CompletedProcess(argv, 0, "", "")

        engine = TimeoutFirstEngine()
        verifier = self.make_verification(engine)
        secret_dir = verifier.secret_dir
        result = verifier.cleanup()
        self.assertFalse(result["ok"])
        self.assertFalse(secret_dir.exists())
        rm_calls = [call for call in engine.calls if "rm" in call]
        # Every owned reference is attempted despite the first timeout.
        self.assertEqual(len(rm_calls), 3)

    def test_not_found_is_confirmed_and_unknown_failure_is_error(self):
        engine = FakeEngine({
            "qjs-runtime-check-abc": (1, "", "No such container"),
            "missing-abc": (1, "", "permission denied"),
        })
        # Match on the container names; the fake joins the argv.
        engine.responses = {
            "missing-abc": (1, "", "permission denied"),
            "qjs-runtime-check-abc": (1, "", "No such container"),
        }
        verifier = self.make_verification(engine)
        result = verifier.cleanup()
        self.assertFalse(result["ok"])
        self.assertIn("qjs-runtime-check-abc", result["confirmed_absent"])
        self.assertEqual(len(result["errors"]), 1)
        self.assertIn("permission denied", result["errors"][0]["error"])

    def test_inspect_transport_failure_is_not_absence(self):
        engine = FakeEngine()

        def run(argv, timeout=None, env=None):
            engine.calls.append(list(argv))
            if "inspect" in argv:
                raise OSError("transport unavailable")
            return subprocess.CompletedProcess(argv, 0, "", "")

        engine.run = run
        verifier = self.make_verification(engine)
        result = verifier.cleanup_verified()
        self.assertFalse(result["ok"])
        self.assertFalse(result["owned_containers_absent"])
        self.assertTrue(result["inspection_errors"])
        self.assertNotIn("qjs-runtime-check-abc", result["confirmed_absent"])

    def test_cleanup_is_retryable_after_engine_recovers(self):
        class FlakyEngine(FakeEngine):
            def __init__(self):
                super().__init__()
                self.fail = True

            def run(self, argv, timeout=None, env=None):
                self.calls.append(list(argv))
                if "rm" in argv and self.fail:
                    return subprocess.CompletedProcess(
                        argv, 1, "", "daemon busy")
                return subprocess.CompletedProcess(argv, 0, "", "")

        engine = FlakyEngine()
        verifier = self.make_verification(engine)
        first = verifier.cleanup()
        self.assertFalse(first["ok"])
        # The secret is gone even while engine cleanup is incomplete.
        self.assertIsNone(verifier.secret_dir)
        engine.fail = False
        second = verifier.cleanup()
        self.assertTrue(second["ok"])


class ImageConfigInvariantTests(unittest.TestCase):
    def test_volumes_are_reported(self):
        summary = verify_runtime.image_security_summary({
            "Architecture": "amd64", "Os": "linux", "User": "qjs",
            "Cmd": list(verify_runtime.EXPECTED_IMAGE_CMD),
            "Entrypoint": None, "Env": [],
            "Volumes": {"/data": {}},
        })
        self.assertTrue(summary["has_image_volumes"])
        self.assertEqual(summary["image_volumes"], ["/data"])

    def test_meaningful_invariants_fail_without_synthetic_flag(self):
        report = {
            "images": {"runtime": {"Architecture": "amd64", "Os": "linux"}},
            "image_checks": {
                "non_root_user": True,
                "expected_command": True,
                "entrypoint_empty": False,
                "env_has_flag_variable": True,
                "env_has_flag_literal": False,
                "command_has_flag_literal": True,
                "has_image_volumes": True,
            },
            "baked_in_secret_scan": {"status": "clean"},
            "runtime": {"probes": {}},
            "missing_flag": {},
            "cleanup": {},
        }
        _ok, failures = verify_runtime.evaluate_required(report)
        self.assertIn("image defines an unexpected entrypoint", failures)
        self.assertIn("image environment defines the flag variable", failures)
        self.assertIn("flag-like content found in image config", failures)
        self.assertIn(
            "image defines writable VOLUMEs that --read-only does not cover",
            failures)


class LogReadRegressionTests(unittest.TestCase):
    def probe(self):
        return {
            "arithmetic": {"ok": True, "result": 7},
            "state_set": {"ok": True, "result": 41},
            "state_get": {"ok": True, "result": 42},
            "exception": {"ok": False},
            "recovery": {"ok": True, "result": 3},
            "separate_connection": {"ok": True, "result": "undefined"},
            "host_apis": {"ok": True, "result": {
                name: "undefined"
                for name in verify_runtime.ABSENT_HOST_APIS}},
            "reply_blob": "safe",
        }

    def test_failed_log_read_is_unverified_and_fails_checks(self):
        flag = "FLAG{" + "4" * 32 + "}"
        report = {"commands": [], "runtime": {}}
        args = SimpleNamespace(
            container_prefix="qjs-runtime-check", cpus=2.0, memory="2g",
            pids_limit=64, platform="linux/amd64", startup_timeout=1.0)
        engine = FakeEngine({
            "PORT =": (0, json.dumps(self.probe()), ""),
            "os.getuid()": (0, "10001 10001\n", ""),
            " logs ": (1, "", "log driver unavailable"),
        })
        verifier = verify_runtime.Verification(engine, args, report)
        checks = verifier.run_probes("owned-runtime", flag)
        self.assertFalse(checks["logs_read_ok"])
        self.assertTrue(checks["log_read_failed"])
        self.assertFalse(checks["flag_not_in_logs"])

        required = {
            "images": {"runtime": {"Architecture": "amd64", "Os": "linux"}},
            "image_checks": {
                "non_root_user": True, "expected_command": True,
                "entrypoint_empty": True, "env_has_flag_variable": False,
                "env_has_flag_literal": False,
                "command_has_flag_literal": False,
                "has_image_volumes": False,
            },
            "baked_in_secret_scan": {"status": "clean"},
            "runtime": {"probes": checks},
            "missing_flag": {},
            "cleanup": {"ok": True, "owned_containers_absent": True},
        }
        _ok, failures = verify_runtime.evaluate_required(required)
        self.assertIn(
            "runtime logs could not be read; disclosure unverified",
            failures)


class VolumePreflightRegressionTests(unittest.TestCase):
    def test_volume_is_rejected_before_scan_or_runtime_start(self):
        image = {
            "Id": "sha256:" + "f" * 64,
            "Architecture": "amd64",
            "Os": "linux",
            "Config": {
                "User": "qjs",
                "Cmd": list(verify_runtime.EXPECTED_IMAGE_CMD),
                "Env": [],
                "Volumes": {"/data": {}},
            },
        }
        engine = FakeEngine({
            "image inspect --format {{json .}} img:local":
                (0, json.dumps(image), ""),
        })
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "report.json"
            argv = [
                "verify_runtime.py", "--engine", "fake-engine",
                "--prebuilt-image", "img:local",
                "--platform", "linux/amd64", "--report", str(path),
            ]
            with mock.patch.object(sys, "argv", argv), \
                    mock.patch.object(verify_runtime, "find_engine",
                                      return_value=("/usr/bin/fake-engine", "")), \
                    mock.patch.object(verify_runtime, "Engine",
                                      return_value=engine), \
                    mock.patch("sys.stderr"):
                code = verify_runtime.main()
            self.assertEqual(code, 1)
            report = json.loads(path.read_text())
            self.assertEqual(report["status"], "failed")
            self.assertIn("VOLUME", report.get("error", ""))
            flat = [" ".join(call) for call in engine.calls]
            self.assertFalse(any("role=scan" in call for call in flat))
            self.assertFalse(any("role=runtime" in call for call in flat))
            self.assertFalse(any("--entrypoint python3" in call
                                 for call in flat))
            # Rejection happens before any Flag is generated or mounted.
            self.assertNotIn("secret_mount", report)
            self.assertTrue(report["cleanup"]["ok"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
