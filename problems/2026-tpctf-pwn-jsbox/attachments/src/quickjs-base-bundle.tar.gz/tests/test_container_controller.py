"""Unit regressions for evaluator/container_controller.py.

These use command builders, fabricated engine responses, and local Python
processes.  They do not claim that a container ran.  Real-engine evidence is
produced separately by the container_controller boundary command.
"""

from __future__ import annotations

import importlib.util
import io
import json
import os
import re
import secrets
import shutil
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parent.parent
SPEC = importlib.util.spec_from_file_location(
    "container_controller",
    ROOT / "evaluator" / "container_controller.py")
container = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(container)


class FakeEngine:
    path = "/usr/bin/fake-engine"

    def __init__(self, responses=None):
        self.calls = []
        self.responses = responses or []

    def run(self, argv, timeout=None, env=None):
        self.calls.append(list(argv))
        joined = " ".join(argv)
        for needle, (rc, out, err) in self.responses:
            if needle in joined:
                return subprocess.CompletedProcess(argv, rc, out, err)
        return subprocess.CompletedProcess(argv, 0, "", "")

    def require(self, argv, name, timeout=None, env=None):
        proc = self.run(argv, timeout=timeout, env=env)
        if not (proc.returncode == 0):
            raise container.ContainerError(
                f"{name} failed with exit code {proc.returncode}")
        return proc

    def image_exists(self, reference):
        proc = self.run([self.path, "image", "inspect", reference])
        return proc.returncode == 0

    def version(self):
        return "fake 1.0"


def labels(instance_id, role="target"):
    return {container.LABEL_INSTANCE: instance_id,
            container.LABEL_ROLE: role}


def save_policy_text(batch: str, *, ipv6: bool = False) -> str:
    """Convert a legacy restore batch to counted iptables-save output."""
    suffix = "/128" if ipv6 else "/32"
    lines = []
    counter = 0

    def mask(match):
        return match.group(1) + match.group(2) + suffix

    for line in batch.splitlines():
        if line.startswith("-A "):
            counter += 1
            line = re.sub(r"(-[sd] )([0-9A-Fa-f:.]+)(?= )", mask, line)
            if "-p tcp " in line:
                line = line.replace("-p tcp ", "-p tcp -m tcp ")
            line = line.replace("--ctstate NEW,ESTABLISHED",
                                "--ctstate ESTABLISHED,NEW")
            line = f"[{counter}:{counter * 10}] " + line
        lines.append(line)
    return "\n".join(lines) + "\n"


# Strict-egress fixtures use the same derived ownership marker the controller
# computes for the fixture instance id ("instance-1").
TEST_MARKER = container.egress_policy.policy_marker("instance-1")


def policy_texts(marker: str, target: str, gateway: str,
                 sentinel: str | None = None) -> tuple[str, str]:
    v4 = container.egress_policy.render_ipv4_policy(
        marker, target, gateway_ip=gateway, sentinel_ip=sentinel)
    v6 = container.egress_policy.render_ipv6_policy(marker)
    return save_policy_text(v4), save_policy_text(v6, ipv6=True)


class NetworkAndSandboxCommandTests(unittest.TestCase):
    def test_network_is_internal_and_labelled(self):
        argv = container.network_create_argv(
            "docker", "qjs-ctf-net-abc", "instance-1")
        self.assertEqual(argv[:4], ["docker", "network", "create",
                                    "--internal"])
        self.assertIn("--driver", argv)
        self.assertIn("bridge", argv)
        self.assertIn("qjsctf.instance=instance-1", argv)
        self.assertNotIn("--publish", argv)

    def test_target_has_no_published_port_and_readonly_flag_mount(self):
        argv = container.target_run_argv(
            "docker", "target-abc", "runtime:img", "net-abc", "instance-1",
            "/private/secret/flag", user="10001:10001", cpus=2.0,
            memory="2g", pids_limit=64, platform="linux/amd64")
        joined = " ".join(argv)
        self.assertNotIn("--publish", argv)
        self.assertNotIn("-p", argv)
        self.assertIn("--network net-abc", joined)
        self.assertIn("--network-alias target", joined)
        self.assertIn("--user 10001:10001", joined)
        self.assertIn("--cap-drop ALL", joined)
        self.assertIn("--security-opt no-new-privileges:true", joined)
        self.assertIn("--read-only", joined)
        self.assertIn("--cpus 2", joined)
        self.assertIn("--memory 2g", joined)
        self.assertIn("--pids-limit 64", joined)
        self.assertIn("--pull=never", joined)
        self.assertIn("type=bind,source=/private/secret/flag,"
                      "target=/run/secrets/qjs_ctf_flag,readonly", argv)
        self.assertIn("--flag-file", argv)
        self.assertIn("/run/secrets/qjs_ctf_flag", argv)

    def test_solver_gets_endpoint_only_and_no_secret(self):
        flag = "FLAG{" + "a" * 32 + "}"
        argv = container.solver_container_argv(
            "docker", "solver-abc", "solver:img", "net-abc", "instance-1",
            ["/opt/solve", "--arg"], user="10001:10001", cpus=1.0,
            memory="1g", pids_limit=128, platform="linux/amd64")
        joined = " ".join(argv)
        self.assertEqual(argv[-1], container.TARGET_ENDPOINT)
        self.assertEqual(argv.count(container.TARGET_ENDPOINT), 1)
        self.assertEqual(argv[argv.index("solver:img") + 1], "/opt/solve")
        self.assertNotIn(flag, joined)
        self.assertNotIn("/run/secrets", joined)
        self.assertNotIn("QJS_CTF_FLAG", joined)
        self.assertNotIn("docker.sock", joined)
        self.assertNotIn("--privileged", argv)
        self.assertNotIn("--pid host", joined)
        self.assertNotIn("--network host", joined)
        self.assertNotIn("--publish", argv)
        self.assertIn("--user 10001:10001", joined)
        self.assertIn("--cap-drop ALL", joined)
        self.assertIn("--security-opt no-new-privileges:true", joined)
        self.assertIn("--read-only", joined)
        self.assertIn("--workdir /tmp", joined)
        self.assertIn("--log-driver none", joined)

    def test_solver_create_uses_the_same_sandbox(self):
        argv = container.solver_container_argv(
            "docker", "solver-config", "solver:img", "net-abc",
            "instance-1", None, user="10001:10001", cpus=1.0,
            memory="1g", pids_limit=128, platform="linux/amd64", create=True)
        self.assertEqual(argv[1], "create")
        self.assertIn("--read-only", argv)
        self.assertIn("--cap-drop", argv)
        self.assertIn("--network", argv)
        self.assertIn("--log-driver", argv)
        self.assertNotIn(container.TARGET_ENDPOINT, argv)

    def test_owned_removal_removes_anonymous_volumes(self):
        argv = container.remove_argv("docker", "owned-name")
        self.assertEqual(argv[:2], ["docker", "rm"])
        self.assertIn("-v", argv)
        self.assertNotIn("prune", argv)

    def test_probe_container_has_no_secret_or_flag_env(self):
        argv = container.probe_container_argv(
            "docker", "probe", "probe:img", "net-abc", "instance-1",
            user="10001:10001", cpus=1.0, memory="1g", pids_limit=128,
            platform="linux/amd64")
        joined = " ".join(argv)
        self.assertNotIn("/run/secrets", joined)
        self.assertNotIn("QJS_CTF_FLAG", joined)
        self.assertNotIn("--publish", argv)
        self.assertIn("--read-only", joined)

    def test_helper_containers_disable_baked_healthchecks(self):
        # A baked HEALTHCHECK is arbitrary image code.  It must not run in
        # the pre-policy holder/sentinel or in helper probes.
        holder = container.holder_container_argv(
            "docker", "holder", "holder:img", "net-abc", "instance-1",
            user="10001:10001", cpus=0.5, memory="128m", pids_limit=32,
            platform="linux/amd64")
        probe = container.probe_container_argv(
            "docker", "probe", "solver:img", "net-abc", "instance-1",
            user="10001:10001", cpus=1.0, memory="1g", pids_limit=128,
            platform="linux/amd64", role="control-probe")
        sentinel = container.sentinel_container_argv(
            "docker", "sentinel", "holder:img", "net-abc", "instance-1",
            9000, user="10001:10001", platform="linux/amd64", udp_port=9001)
        for argv in (holder, probe, sentinel):
            self.assertIn("--no-healthcheck", argv)

    def test_pre_control_image_identity_requires_exact_image_id(self):
        engine = FakeEngine([
            ("inspect --format {{json .}} sentinel-abc",
             (0, json.dumps({
                 "Image": "sha256:holder",
                 "Config": {"Labels": labels(
                     "instance-1", "sentinel")},
             }), "")),
        ])
        instance = InstanceFixture().instance(engine)
        self.addCleanup(shutil.rmtree, instance.secret_dir, True)
        self.assertEqual(
            instance._inspect_container_image(
                "sentinel-abc", "second-network sentinel"),
            "sha256:holder")

    def test_pre_control_image_identity_rejects_missing_or_invalid(self):
        instance = InstanceFixture().instance(FakeEngine([
            ("inspect --format {{json .}} sentinel-abc",
             (0, json.dumps({"Config": {}}), "")),
        ]))
        self.addCleanup(shutil.rmtree, instance.secret_dir, True)
        with self.assertRaises(container.ContainerError) as caught:
            instance._inspect_container_image(
                "sentinel-abc", "second-network sentinel")
        self.assertIn("no immutable image identity", str(caught.exception))

        broken = InstanceFixture().instance(FakeEngine([
            ("inspect --format {{json .}} sentinel-abc",
             (0, "not-json", "")),
        ]))
        self.addCleanup(shutil.rmtree, broken.secret_dir, True)
        with self.assertRaises(container.ContainerError) as caught:
            broken._inspect_container_image(
                "sentinel-abc", "second-network sentinel")
        self.assertIn("invalid JSON", str(caught.exception))


class SolverArgvTests(unittest.TestCase):
    def test_endpoint_is_appended_once_and_flag_is_rejected(self):
        flag = "FLAG{" + "b" * 32 + "}"
        parsed = container.parse_solver_json('["/opt/solve"]')
        self.assertEqual(parsed, ["/opt/solve"])
        with self.assertRaises(container.ContainerError):
            container.validate_solver_argv([], flag)
        with self.assertRaises(container.ContainerError):
            container.validate_solver_argv("/opt/solve", flag)
        with self.assertRaises(container.ContainerError):
            container.validate_solver_argv([flag], flag)
        with self.assertRaises(container.ContainerError):
            container.parse_solver_json("not json")


class JudgingTests(unittest.TestCase):
    flag = "FLAG{" + "c" * 32 + "}"

    def result(self, stdout="", returncode=0, truncated=False,
               timed_out=False):
        return {
            "stdout": stdout,
            "stdout_bytes": len(stdout.encode()),
            "stdout_retained_bytes": len(stdout.encode()),
            "stdout_truncated": truncated,
            "stderr_bytes": 0,
            "stderr_truncated": False,
            "returncode": returncode,
            "timed_out": timed_out,
            "timeout_cleanup_error": False,
            "duration_s": 0.01,
        }

    def test_exact_empty_wrong_and_error(self):
        self.assertEqual(
            container.judge_execution(self.result(self.flag + "\n"),
                                      self.flag)["reason"], "match")
        self.assertEqual(
            container.judge_execution(self.result(""), self.flag)["reason"],
            "empty")
        self.assertEqual(
            container.judge_execution(self.result("nope"), self.flag)
            ["reason"], "wrong")
        self.assertEqual(
            container.judge_execution(self.result("", returncode=3),
                                      self.flag)["reason"], "error")
        self.assertEqual(
            container.judge_execution(
                self.result(self.flag, timed_out=True), self.flag)
            ["reason"], "timeout")

    def test_overflow_rejected_even_with_exact_prefix(self):
        verdict = container.judge_execution(
            self.result(self.flag + " " * 70000, truncated=True), self.flag)
        self.assertEqual(verdict["reason"], "output_limit")
        self.assertFalse(verdict["ok"])
        self.assertNotIn("stdout", verdict)

    def test_verdict_never_contains_raw_output(self):
        verdict = container.judge_execution(
            self.result(self.flag), self.flag)
        self.assertNotIn(self.flag, json.dumps(verdict))
        self.assertNotIn("stdout", verdict)


class BoundedExecutionTests(unittest.TestCase):
    def test_timeout_kills_owned_process_and_runs_cleanup(self):
        with tempfile.TemporaryDirectory() as td:
            pidfile = Path(td) / "pid"
            script = (
                "import os, time\n"
                f"open({str(pidfile)!r}, 'w').write(str(os.getpid()))\n"
                "time.sleep(60)\n"
            )
            called = []
            start = time.monotonic()
            result = container.execute_solver(
                [sys.executable, "-c", script], 0.4,
                on_timeout=lambda: called.append(True))
            elapsed = time.monotonic() - start
            self.assertTrue(result["timed_out"])
            self.assertTrue(called)
            self.assertLess(elapsed, 10)
            pid = int(pidfile.read_text())
            with self.assertRaises(ProcessLookupError):
                os.kill(pid, 0)

    def test_overflow_is_bounded_and_flagged(self):
        limit = container.SOLVER_OUTPUT_LIMIT
        script = (
            "import sys\n"
            f"sys.stdout.write('x' * {limit + 5000})\n"
        )
        result = container.execute_solver(
            [sys.executable, "-c", script], 10.0)
        self.assertTrue(result["stdout_truncated"])
        self.assertGreater(result["stdout_bytes"], limit)
        self.assertEqual(result["stdout_retained_bytes"], limit)
        self.assertFalse(result["timed_out"])

    def test_nonzero_exit_is_error(self):
        result = container.execute_solver(
            [sys.executable, "-c", "import sys; sys.exit(3)"], 10.0)
        verdict = container.judge_execution(result, "FLAG{x}")
        self.assertEqual(verdict["reason"], "error")
        self.assertFalse(verdict["ok"])

    def test_timeout_cleanup_failure_is_recorded(self):
        def failing_cleanup():
            raise RuntimeError("container removal failed")
        result = container.execute_solver(
            [sys.executable, "-c", "import time; time.sleep(60)"], 0.3,
            on_timeout=failing_cleanup)
        self.assertTrue(result["timed_out"])
        self.assertTrue(result["timeout_cleanup_error"])


class InstanceFixture:
    def instance(self, engine, token="abc", instance_id="instance-1"):
        return container.ContainerInstance(
            engine, instance_id, token, "target:img", "solver:img",
            "probe:img", f"net-{token}", f"target-{token}",
            f"cid-{token}", "FLAG{" + "d" * 32 + "}",
            Path(tempfile.mkdtemp(prefix="qjs-ctf-secret-test-")),
            platform="linux/amd64", target_user="10001:10001",
            solver_user="10001:10001",
            target_limits={"cpus": 2.0, "memory": "2g", "pids_limit": 64},
            solver_limits={"cpus": 1.0, "memory": "1g", "pids_limit": 128},
            startup_timeout=0.3, name_prefix="qjs-ctf")


class CleanupTests(unittest.TestCase):
    def inspect_response(self, instance_id, role="target"):
        return (0, json.dumps({
            "Id": "container-id",
            "Config": {"Labels": labels(instance_id, role)},
        }), "")

    def test_stop_is_idempotent_scoped_and_removes_secret(self):
        engine = FakeEngine([
            ("inspect --format {{json .}} target-abc",
             self.inspect_response("instance-1")),
            ("network inspect --format {{json .}} net-abc",
             (0, json.dumps({"Labels": labels("instance-1", "network")}), "")),
        ])
        fixture = InstanceFixture()
        instance = fixture.instance(engine)
        secret_dir = instance.secret_dir
        result = instance.stop()
        self.assertTrue(result["ok"])
        self.assertFalse(secret_dir.exists())
        call_count = len(engine.calls)
        self.assertTrue(instance.stop()["ok"])
        self.assertEqual(len(engine.calls), call_count)
        flat = " ".join(" ".join(call) for call in engine.calls)
        self.assertIn("rm -f", flat)
        self.assertIn("network rm", flat)
        self.assertNotIn("prune", flat)
        self.assertNotIn("kill", flat)

    def test_ownership_mismatch_refuses_removal(self):
        engine = FakeEngine([
            ("inspect --format {{json .}} target-abc",
             self.inspect_response("someone-else")),
            ("network inspect --format {{json .}} net-abc",
             (0, json.dumps({"Labels": labels("someone-else", "network")}),
              "")),
        ])
        fixture = InstanceFixture()
        instance = fixture.instance(engine)
        result = instance.stop()
        self.assertFalse(result["ok"])
        messages = " ".join(error.get("error", "")
                            for error in result["errors"])
        self.assertIn("ownership label mismatch", messages)
        flat = " ".join(" ".join(call) for call in engine.calls)
        self.assertNotIn("rm -f", flat)
        self.assertNotIn("network rm", flat)

    def test_removal_failure_is_reported(self):
        engine = FakeEngine([
            ("inspect --format {{json .}} target-abc",
             self.inspect_response("instance-1")),
            ("network inspect --format {{json .}} net-abc",
             (0, json.dumps({"Labels": labels("instance-1", "network")}), "")),
            ("rm -f", (1, "", "daemon busy")),
            ("network rm", (1, "", "network busy")),
        ])
        fixture = InstanceFixture()
        instance = fixture.instance(engine)
        result = instance.stop()
        self.assertFalse(result["ok"])
        self.assertEqual(len(result["errors"]), 2)


class StartLifecycleTests(unittest.TestCase):
    def start_responses(self, health_ok=True):
        responses = [
            ("role=target", (0, "cid-1\n", "")),
        ]
        if health_ok:
            responses.append(("HEALTH_OK", (0, "HEALTH_OK\n", "")))
        else:
            responses.append(("HEALTH_OK", (1, "", "")))
            responses.append(("inspect --format {{json .}} qjs-ctf-target",
                               (0, json.dumps({"State": {"Running": True}}),
                                "")))
        return responses

    def test_start_creates_private_flag_and_health(self):
        engine = FakeEngine(self.start_responses())
        instance = container.ContainerInstance.start(
            engine, "target:img", "solver:img", startup_timeout=2.0,
            name_prefix="qjs-ctf-test", egress_mode="legacy")
        try:
            flag = instance.expected_flag
            self.assertTrue(flag.startswith("FLAG{"))
            flag_path = instance.secret_dir / "instance-flag"
            self.assertEqual(flag_path.read_text().strip(), flag)
            self.assertEqual(flag_path.stat().st_mode & 0o777, 0o444)
            self.assertEqual(instance.secret_dir.stat().st_mode & 0o777,
                             0o700)
            metadata = instance.public_metadata()
            self.assertNotIn(flag, json.dumps(metadata))
            self.assertFalse(metadata["target"]["port_published"])
            self.assertNotIn("/run/secrets", json.dumps(metadata["solver"]))
        finally:
            self.assertTrue(instance.stop()["ok"])

    def test_two_instances_receive_fresh_flags(self):
        first = container.ContainerInstance.start(
            FakeEngine(self.start_responses()), "target:img", "solver:img",
            startup_timeout=2.0, name_prefix="qjs-ctf-test", egress_mode="legacy")
        second = container.ContainerInstance.start(
            FakeEngine(self.start_responses()), "target:img", "solver:img",
            startup_timeout=2.0, name_prefix="qjs-ctf-test", egress_mode="legacy")
        try:
            self.assertNotEqual(first.expected_flag, second.expected_flag)
            self.assertNotEqual(first.instance_id, second.instance_id)
            self.assertNotEqual(first.network_name, second.network_name)
        finally:
            first.stop()
            second.stop()

    def test_missing_image_fails_before_creating_secrets(self):
        engine = FakeEngine([("image inspect target:img", (1, "", "missing"))])
        before = set(Path(tempfile.gettempdir()).glob("qjs-ctf-secret-*"))
        with self.assertRaises(container.ContainerError):
            container.ContainerInstance.start(
                engine, "target:img", "solver:img", egress_mode="legacy")
        after = set(Path(tempfile.gettempdir()).glob("qjs-ctf-secret-*"))
        self.assertEqual(before, after)
        flat = " ".join(" ".join(call) for call in engine.calls)
        self.assertNotIn("network create", flat)
        self.assertNotIn("run -d", flat)

    def test_root_users_are_rejected(self):
        with self.assertRaises(container.ContainerError):
            container.ContainerInstance.start(
                FakeEngine(), "target:img", "solver:img", target_user="0", egress_mode="legacy")
        with self.assertRaises(container.ContainerError):
            container.ContainerInstance.start(
                FakeEngine(), "target:img", "solver:img", solver_user="root", egress_mode="legacy")

    def test_health_failure_cleans_partial_instance(self):
        engine = FakeEngine(self.start_responses(health_ok=False))
        before = set(Path(tempfile.gettempdir()).glob("qjs-ctf-secret-*"))
        with self.assertRaises(container.ContainerError):
            container.ContainerInstance.start(
                engine, "target:img", "solver:img",
                startup_timeout=0.3, name_prefix="qjs-ctf-test", egress_mode="legacy")
        after = set(Path(tempfile.gettempdir()).glob("qjs-ctf-secret-*"))
        self.assertEqual(before, after)
        flat = " ".join(" ".join(call) for call in engine.calls)
        self.assertIn("rm -f", flat)
        self.assertIn("network rm", flat)
        self.assertNotIn("prune", flat)
        self.assertNotIn("kill", flat)


class BoundaryCheckTests(unittest.TestCase):
    def make_instance(self):
        engine = FakeEngine()
        fixture = InstanceFixture()
        instance = fixture.instance(engine)
        self.addCleanup(shutil.rmtree, instance.secret_dir, True)
        return instance

    def passing_data(self):
        solver = {
            "user": "10001:10001", "non_root_user": True,
            "limit_cpu": 1_000_000_000, "limit_memory": 1024 ** 3,
            "limit_pids": 128, "readonly_rootfs": True,
            "cap_drop_all": True, "no_new_privileges": True,
            "network_mode": "net-abc", "pid_mode": "", "ipc_mode": "private",
            "privileged": False, "port_bindings": {},
            "secret_mount": False, "docker_socket_mount": False,
            "flag_env_present": False, "flag_value_in_env": False,
            "flag_value_in_command": False,
        }
        target = {
            "user": "10001:10001", "non_root_user": True,
            "network_mode": "net-abc", "pid_mode": "",
            "privileged": False, "readonly_rootfs": True,
            "cap_drop_all": True, "no_new_privileges": True,
            "memory": 2 * 1024 ** 3, "nano_cpus": 2_000_000_000,
            "pids_limit": 64, "port_bindings": {},
            "flag_mount_readonly": True,
        }
        network = {"Name": "net-abc", "Internal": True}
        probe = {
            "target_reachable": True, "target_health": True, "uid": 10001,
            "secret_file_exists": False, "flag_env_variable_present": False,
            "controller_env_sentinel_present": False,
            "docker_socket_exists": False, "root_write_blocked": True,
            "pid_ns": "pid:[1]", "mnt_ns": "mnt:[1]",
            "host_gateway_reachable": False,
            "host_docker_internal_reachable": False,
            "second_network_reachable": False,
            "external_1_1_1_1_53_reachable": False,
            "external_8_8_8_8_53_reachable": False,
        }
        target_ns = {"pid_ns": "pid:[2]", "mnt_ns": "mnt:[2]"}
        return solver, target, network, probe, target_ns

    def test_all_configured_checks_pass_but_gate_stays_pending(self):
        instance = self.make_instance()
        solver, target, network, probe, target_ns = self.passing_data()
        checks = instance._boundary_checks(
            solver, target, network, probe, target_ns, "10.0.0.2",
            "172.18.0.1")
        self.assertEqual(instance._boundary_failures(checks, probe), [])
        self.assertTrue(checks["pid_namespaces_distinct"])
        self.assertTrue(checks["mount_namespaces_distinct"])
        self.assertTrue(checks["host_gateway_sentinel_unreachable"])
        self.assertTrue(checks["second_network_sentinel_unreachable"])

    def test_reachable_sentinels_and_leaks_fail(self):
        instance = self.make_instance()
        solver, target, network, probe, target_ns = self.passing_data()
        probe["host_gateway_reachable"] = True
        probe["second_network_reachable"] = True
        probe["secret_file_exists"] = True
        probe["docker_socket_exists"] = True
        probe["controller_env_sentinel_present"] = True
        probe["pid_ns"] = target_ns["pid_ns"]
        checks = instance._boundary_checks(
            solver, target, network, probe, target_ns, "10.0.0.2",
            "172.18.0.1")
        failures = instance._boundary_failures(checks, probe)
        for name in ("host_gateway_sentinel_unreachable",
                     "second_network_sentinel_unreachable",
                     "solver_secret_file_absent",
                     "docker_socket_absent",
                     "controller_env_sentinel_absent",
                     "pid_namespaces_distinct"):
            self.assertIn(name, failures)
        self.assertFalse(checks["pid_namespaces_distinct"])

    def test_solver_config_flag_is_detected(self):
        instance = self.make_instance()
        solver, target, network, probe, target_ns = self.passing_data()
        solver["flag_env_present"] = True
        solver["flag_value_in_env"] = True
        checks = instance._boundary_checks(
            solver, target, network, probe, target_ns, "10.0.0.2",
            "172.18.0.1")
        self.assertFalse(checks["solver_flag_env_absent"])
        self.assertIn("solver_flag_env_absent",
                      instance._boundary_failures(checks, probe))


class ResetTests(unittest.TestCase):
    def test_reset_stops_old_instance_and_creates_fresh_flag(self):
        created = []

        class FakeInstance:
            def __init__(self):
                self.flag = "FLAG{" + secrets.token_hex(16) + "}"
                self.stopped = False

            def public_metadata(self):
                return {"instance_id": secrets.token_hex(4),
                        "flag_length": len(self.flag)}

            def stop(self):
                self.stopped = True
                return {"ok": True, "errors": []}

        def fake_start(*args, **kwargs):
            instance = FakeInstance()
            created.append(instance)
            return instance

        evaluator = container.ContainerEvaluator(
            FakeEngine(), "target:img", "solver:img", ["/opt/solve"], egress_mode="legacy")
        with mock.patch.object(container.ContainerInstance, "start",
                               side_effect=fake_start):
            evaluator.start()
            metadata = evaluator.reset()
        self.assertEqual(len(created), 2)
        self.assertTrue(created[0].stopped)
        self.assertFalse(created[1].stopped)
        self.assertNotEqual(created[0].flag, created[1].flag)
        self.assertNotIn(created[1].flag, json.dumps(metadata))


class SolverConfigInspectionTests(unittest.TestCase):
    def make_engine(self, env=None):
        data = {
            "Config": {
                "User": "10001:10001",
                "Env": env or [],
                "Cmd": ["/bin/true", "target:8000"],
                "Entrypoint": None,
            },
            "HostConfig": {
                "NanoCpus": 1_000_000_000,
                "Memory": 1024 ** 3,
                "PidsLimit": 128,
                "ReadonlyRootfs": True,
                "CapDrop": ["ALL"],
                "SecurityOpt": ["no-new-privileges:true"],
                "NetworkMode": "net-abc",
                "PidMode": "",
                "IpcMode": "private",
                "Privileged": False,
                "PortBindings": {},
                "Tmpfs": {
                    "/tmp": "rw,noexec,nosuid,nodev,size=16m"},
                "Binds": None,
                "Mounts": None,
                "VolumesFrom": None,
                "CapAdd": None,
                "Devices": None,
                "DeviceRequests": None,
                "DeviceCgroupRules": None,
            },
            "Mounts": [],
        }
        return FakeEngine([
            ("create --name", (0, "cid", "")),
            ("inspect --format {{json .}} solver-config",
             (0, json.dumps(data), "")),
            ("rm -f solver-config", (0, "", "")),
        ])

    def instance(self, engine):
        instance = InstanceFixture().instance(engine)
        self.addCleanup(shutil.rmtree, instance.secret_dir, True)
        return instance

    def test_solver_config_is_inspected_without_execution(self):
        engine = self.make_engine()
        instance = self.instance(engine)
        instance._solver_argv = []
        config = instance._inspect_solver_config("solver-config")
        self.assertTrue(config["non_root_user"])
        self.assertTrue(config["readonly_rootfs"])
        self.assertTrue(config["cap_drop_all"])
        self.assertTrue(config["no_new_privileges"])
        self.assertFalse(config["secret_mount"])
        self.assertFalse(config["flag_env_present"])
        self.assertFalse(config["flag_value_in_env"])
        self.assertFalse(config["flag_value_in_command"])
        create_calls = [call for call in engine.calls if call[1] == "create"]
        self.assertEqual(len(create_calls), 1)
        self.assertIn("/bin/true", create_calls[0])
        self.assertIn(container.TARGET_ENDPOINT, create_calls[0])
        self.assertNotIn(instance.expected_flag,
                         " ".join(create_calls[0]))
        self.assertFalse(any(call[1] == "start" for call in engine.calls))
        self.assertFalse(any(call[1] == "run" for call in engine.calls))

    def test_baked_in_flag_env_is_detected(self):
        flag = "FLAG{" + "e" * 32 + "}"
        engine = self.make_engine(env=["QJS_CTF_FLAG=" + flag])
        instance = self.instance(engine)
        instance._flag = flag
        instance._solver_argv = []
        config = instance._inspect_solver_config("solver-config")
        self.assertTrue(config["flag_env_present"])
        self.assertTrue(config["flag_value_in_env"])


class SkippedReportTests(unittest.TestCase):
    def test_no_engine_writes_skipped_report_and_exits_2(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "report.json"
            argv = [
                "container_controller.py", "--engine",
                str(Path(td) / "no-such-engine"),
                "--target-image", "target:img",
                "--solver-image", "solver:img",
                "--egress-mode", "legacy",
                "--solver-json", '["/opt/solve"]',
                "--report", str(path),
            ]
            with mock.patch.object(sys, "argv", argv), \
                    mock.patch("sys.stderr"):
                code = container.main()
            self.assertEqual(code, 2)
            report = json.loads(path.read_text())
            self.assertEqual(report["status"], "skipped")
            self.assertIn("nothing was run", " ".join(report["limitations"]))


class ImageVolumeRejectionTests(unittest.TestCase):
    def test_image_declared_volume_is_rejected_before_start(self):
        engine = FakeEngine([
            ("image inspect --format {{json .Config.Volumes}} target:img",
             (0, json.dumps({"/data": {}}), "")),
        ])
        before = set(Path(tempfile.gettempdir()).glob("qjs-ctf-secret-*"))
        with self.assertRaises(container.ContainerError):
            container.ContainerInstance.start(
                engine, "target:img", "solver:img", egress_mode="legacy")
        after = set(Path(tempfile.gettempdir()).glob("qjs-ctf-secret-*"))
        self.assertEqual(before, after)
        flat = " ".join(" ".join(call) for call in engine.calls)
        self.assertNotIn("network create", flat)
        self.assertNotIn("run -d", flat)

    def test_volume_inspect_null_and_invalid(self):
        self.assertEqual(container.parse_image_volumes("null"), [])
        self.assertEqual(container.parse_image_volumes(""), [])
        self.assertEqual(
            container.parse_image_volumes('{"/data": {}, "/cache": {}}'),
            ["/cache", "/data"])
        with self.assertRaises(container.ContainerError):
            container.parse_image_volumes("not-json")
        with self.assertRaises(container.ContainerError):
            container.parse_image_volumes('["/data"]')


class PublicEngineCallTests(unittest.TestCase):
    def test_private_solver_marker_is_absent_from_public_report(self):
        marker = "PRIVATE_INLINE_SOLVER_SOURCE_marker_123456"
        calls = [{
            "argv": ["/usr/bin/docker", "create", "--name",
                     "solver-config", "--", "python3", "-c", marker,
                     container.TARGET_ENDPOINT],
            "returncode": 0,
        }]
        report = {"engine_calls": container.public_engine_calls(calls)}
        text = json.dumps(report)
        self.assertNotIn(marker, text)
        self.assertNotIn("python3", text)
        self.assertTrue(report["engine_calls"][0]["arguments_redacted"])
        self.assertEqual(report["engine_calls"][0]["subcommand"], "create")
        self.assertNotIn("argv", report["engine_calls"][0])

    def test_timeout_metadata_is_preserved(self):
        public = container.public_engine_calls([{
            "argv": ["/usr/bin/docker", "run", "--name", "x"],
            "returncode": None,
            "error": "timeout",
        }])
        self.assertTrue(public[0]["timed_out"])
        self.assertIsNone(public[0]["returncode"])


class StartOwnershipTests(unittest.TestCase):
    def test_create_response_lost_is_still_cleaned_by_owned_name(self):
        class LostResponseEngine(FakeEngine):
            def __init__(self):
                super().__init__()
                self.lost = False

            def run(self, argv, timeout=None, env=None):
                self.calls.append(list(argv))
                joined = " ".join(argv)
                if "network create" in joined and not self.lost:
                    self.lost = True
                    raise subprocess.TimeoutExpired(argv, 1)
                return subprocess.CompletedProcess(argv, 0, "", "")

        engine = LostResponseEngine()
        before = set(Path(tempfile.gettempdir()).glob("qjs-ctf-secret-*"))
        with self.assertRaises(subprocess.TimeoutExpired):
            container.ContainerInstance.start(
                engine, "target:img", "solver:img",
                name_prefix="qjs-ctf-lost", egress_mode="legacy")
        after = set(Path(tempfile.gettempdir()).glob("qjs-ctf-secret-*"))
        self.assertEqual(before, after)
        flat_calls = [" ".join(call) for call in engine.calls]
        self.assertTrue(any("rm -f -v qjs-ctf-lost-target-" in call
                            for call in flat_calls))
        self.assertTrue(any("network rm qjs-ctf-lost-net-" in call
                            for call in flat_calls))
        self.assertFalse(any("prune" in call for call in flat_calls))
        # No unrelated resource names were touched.
        for call in flat_calls:
            if "rm -f" in call:
                self.assertIn("qjs-ctf-lost-", call)


class RetryableCleanupTests(unittest.TestCase):
    def make_instance(self, engine):
        instance = InstanceFixture().instance(engine)
        return instance

    def test_first_rm_timeout_then_retry_succeeds(self):
        class FirstRmTimeoutEngine(FakeEngine):
            def __init__(self):
                super().__init__()
                self.timed_out = False

            def run(self, argv, timeout=None, env=None):
                self.calls.append(list(argv))
                if "rm" in argv and not self.timed_out:
                    self.timed_out = True
                    raise subprocess.TimeoutExpired(argv, 1)
                return subprocess.CompletedProcess(argv, 0, "", "")

        engine = FirstRmTimeoutEngine()
        instance = self.make_instance(engine)
        secret_dir = instance.secret_dir
        first = instance.stop()
        self.assertFalse(first["ok"])
        self.assertFalse(secret_dir.exists())
        second = instance.stop()
        self.assertTrue(second["ok"])
        rm_calls = [call for call in engine.calls if "rm" in call]
        self.assertGreaterEqual(len(rm_calls), 3)
        flat = " ".join(" ".join(call) for call in engine.calls)
        self.assertNotIn("prune", flat)

    def test_transport_failure_is_not_treated_as_absence(self):
        class TransportFailureEngine(FakeEngine):
            def run(self, argv, timeout=None, env=None):
                self.calls.append(list(argv))
                if "inspect" in argv:
                    raise OSError("transport unavailable")
                if "rm" in argv:
                    return subprocess.CompletedProcess(
                        argv, 1, "", "daemon busy")
                return subprocess.CompletedProcess(argv, 0, "", "")

        engine = TransportFailureEngine()
        instance = self.make_instance(engine)
        secret_dir = instance.secret_dir
        result = instance.stop()
        self.assertFalse(result["ok"])
        messages = " ".join(error.get("error", "")
                            for error in result["errors"])
        self.assertIn("inventory inspect failed", messages)
        self.assertIn("remove failed", messages)
        self.assertFalse(secret_dir.exists())

    def test_solver_cleanup_failure_keeps_owned_name_and_verdict(self):
        instance = self.make_instance(FakeEngine([
            ("rm -f -v", (1, "", "solver busy")),
        ]))
        instance._solver_argv = ["/opt/solve"]
        result = {
            "stdout": instance.expected_flag + "\n",
            "stdout_bytes": len(instance.expected_flag) + 1,
            "stdout_retained_bytes": len(instance.expected_flag) + 1,
            "stdout_truncated": False,
            "stderr_bytes": 0,
            "stderr_truncated": False,
            "returncode": 0,
            "timed_out": False,
            "timeout_cleanup_error": False,
            "duration_s": 0.01,
        }
        with mock.patch.object(container, "execute_solver",
                               return_value=result):
            verdict = instance.evaluate(1.0)
        self.assertTrue(verdict["ok"])
        self.assertEqual(verdict["reason"], "match")
        self.assertFalse(verdict["container_cleanup"]["ok"])
        self.assertTrue(instance._remaining_solver_names)
        solver_name = instance._remaining_solver_names[0]
        # The owned name is retained for a later retry.
        self.assertTrue(solver_name.startswith(instance.name_prefix))
        # If the engine recovers, both the retry and overall cleanup succeed.
        instance.engine = FakeEngine()
        self.assertTrue(instance.stop()["ok"])


class EvaluatorStartRecoveryTests(unittest.TestCase):
    """A failed start must leave provisional ownership for outer cleanup."""

    def test_failed_start_retains_names_and_later_cleanup_succeeds(self):
        class FirstCleanupFailsEngine(FakeEngine):
            def __init__(self):
                super().__init__()
                self.rm_attempts = 0

            def run(self, argv, timeout=None, env=None):
                self.calls.append(list(argv))
                if len(argv) > 1 and argv[1] == "run":
                    return subprocess.CompletedProcess(
                        argv, 1, "", "target start failed")
                if "rm" in argv:
                    self.rm_attempts += 1
                    if self.rm_attempts == 1:
                        return subprocess.CompletedProcess(
                            argv, 1, "", "engine busy")
                return subprocess.CompletedProcess(argv, 0, "", "")

        engine = FirstCleanupFailsEngine()
        evaluator = container.ContainerEvaluator(
            engine, "target:img", "solver:img", ["/opt/solve"],
            name_prefix="qjs-ctf-recover", egress_mode="legacy")
        before = set(Path(tempfile.gettempdir()).glob("qjs-ctf-secret-*"))
        with self.assertRaises(container.ContainerError) as caught:
            evaluator.start()
        after = set(Path(tempfile.gettempdir()).glob("qjs-ctf-secret-*"))
        # Local secret removal is unconditional even though engine cleanup
        # failed.
        self.assertEqual(before, after)
        provisional = evaluator._instance
        self.assertIsNotNone(provisional)
        self.assertIs(caught.exception.provisional_instance, provisional)
        self.assertFalse(caught.exception.cleanup_result["ok"])
        self.assertFalse(provisional._target_removed)
        references = " ".join(
            str(error.get("reference", ""))
            for error in provisional._cleanup_result["errors"])
        self.assertIn(provisional.target_name, references)
        self.assertTrue(provisional.target_name.startswith("qjs-ctf-recover"))
        # A later retry with a healthy engine removes the retained resource.
        result = evaluator.stop()
        self.assertTrue(result["ok"], result)
        self.assertIsNone(evaluator._instance)
        self.assertIsNone(provisional.secret_dir)
        self.assertTrue(provisional._target_removed)

    def test_unknown_cleanup_state_never_becomes_ok(self):
        class PersistentTimeoutEngine(FakeEngine):
            def run(self, argv, timeout=None, env=None):
                self.calls.append(list(argv))
                if len(argv) > 1 and argv[1] == "run":
                    return subprocess.CompletedProcess(
                        argv, 1, "", "target start failed")
                if len(argv) > 1 and argv[1] == "inspect":
                    raise subprocess.TimeoutExpired(argv, timeout or 1)
                if (len(argv) > 2 and argv[1] == "network"
                        and argv[2] == "inspect"):
                    raise subprocess.TimeoutExpired(argv, timeout or 1)
                if "rm" in argv:
                    raise subprocess.TimeoutExpired(argv, timeout or 1)
                return subprocess.CompletedProcess(argv, 0, "", "")

        engine = PersistentTimeoutEngine()
        evaluator = container.ContainerEvaluator(
            engine, "target:img", "solver:img", ["/opt/solve"],
            name_prefix="qjs-ctf-unknown", egress_mode="legacy")
        with self.assertRaises(container.ContainerError) as caught:
            evaluator.start()
        provisional = evaluator._instance
        self.assertIsNotNone(provisional)
        self.assertIs(caught.exception.provisional_instance, provisional)
        self.assertFalse(caught.exception.cleanup_result["ok"])
        result = evaluator.stop()
        self.assertFalse(result["ok"])
        # Ownership is retained after a failed retry, never reported clean.
        self.assertIs(evaluator._instance, provisional)
        text = json.dumps(result)
        self.assertIn("inventory inspect failed", text)
        self.assertIn("remove failed", text)
        self.assertIn("timed out", text)
        self.assertIn(provisional.target_name, text)
        self.assertIn(provisional.network_name, text)
        # Raw TimeoutExpired command contents never reach the public result.
        self.assertNotIn("TimeoutExpired", text)
        self.assertNotIn("/usr/bin/fake-engine", text)


class BoundaryTimeoutRedactionTests(unittest.TestCase):
    def test_safe_error_text_never_includes_timeout_command(self):
        marker = "PRIVATE_INLINE_SOLVER_SOURCE_timeout_marker_24680"
        exc = subprocess.TimeoutExpired(
            ["/usr/bin/docker", "create", "--name", "solver-config",
             "python3", "-c", marker], 5)
        text = container.safe_error_text(exc)
        self.assertIn("timed out", text)
        self.assertNotIn(marker, text)
        self.assertNotIn("/usr/bin/docker", text)

    def test_boundary_create_timeout_does_not_leak_solver_marker(self):
        marker = "PRIVATE_INLINE_SOLVER_SOURCE_boundary_marker_13579"

        class SolverCreateTimeoutEngine:
            path = "/usr/bin/fake-engine"

            def __init__(self):
                # Record calls in the same metadata shape as Engine.run().
                self.calls = []

            def run(self, argv, timeout=None, env=None):
                call = {"argv": list(argv), "returncode": None}
                self.calls.append(call)
                if len(argv) > 1 and argv[1] in ("create", "rm"):
                    call["error"] = "timeout"
                    raise subprocess.TimeoutExpired(argv, timeout or 1)
                if (len(argv) > 2 and argv[1] == "network"
                        and argv[2] == "rm"):
                    call["error"] = "timeout"
                    raise subprocess.TimeoutExpired(argv, timeout or 1)
                call["returncode"] = 0
                return subprocess.CompletedProcess(argv, 0, "", "")

            def require(self, argv, name, timeout=None, env=None):
                proc = self.run(argv, timeout=timeout, env=env)
                if proc.returncode != 0:
                    raise container.ContainerError(
                        f"{name} failed with exit code {proc.returncode}")
                return proc

            def image_exists(self, reference):
                return True

            def version(self):
                return "fake 1.0"

        engine = SolverCreateTimeoutEngine()
        instance = InstanceFixture().instance(engine)
        secret_dir = instance.secret_dir
        self.addCleanup(shutil.rmtree, secret_dir, True)
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "report.json"
            argv = [
                "container_controller.py", "--engine", "fake-engine",
                "--target-image", "target:img",
                "--solver-image", "solver:img",
                "--boundary-check",
                "--egress-mode", "legacy",
                "--solver-json",
                json.dumps(["python3", "-c", marker]),
                "--report", str(path),
            ]
            stderr = io.StringIO()
            with mock.patch.object(sys, "argv", argv), \
                    mock.patch.object(container, "find_engine",
                                      return_value=(
                                          "/usr/bin/fake-engine", "")), \
                    mock.patch.object(container, "Engine",
                                      return_value=engine), \
                    mock.patch.object(container.ContainerInstance, "start",
                                      return_value=instance), \
                    mock.patch("sys.stderr", stderr):
                code = container.main()
            text = path.read_text()
            public_stderr = stderr.getvalue()
            report = json.loads(text)
            self.assertEqual(code, 1)
            self.assertNotIn(marker, text)
            self.assertNotIn(marker, public_stderr)
            self.assertEqual(report["status"], "failed")
            self.assertEqual(report["boundary"]["status"], "failed")
            self.assertNotEqual(
                report["boundary"]["endpoint_only_egress"]["status"],
                "passed")
            self.assertNotEqual(
                report["boundary"]["isolation_gate"]["status"], "passed")
            self.assertIn("timed out", report["error"])
            self.assertFalse(report["cleanup"]["ok"])
            self.assertIn("timed out", json.dumps(report["cleanup"]))
            engine_calls = report["engine_calls"]
            self.assertTrue(engine_calls)
            for call in engine_calls:
                self.assertNotIn("argv", call)
                self.assertTrue(call["arguments_redacted"])
            self.assertTrue(any(call["subcommand"] == "create"
                                and call["timed_out"] for call in engine_calls))


class BoundaryOwnershipTests(unittest.TestCase):
    def solver_config(self):
        return {
            "Config": {
                "User": "10001:10001",
                "Env": [],
                "Cmd": ["/bin/true", container.TARGET_ENDPOINT],
                "Entrypoint": None,
            },
            "HostConfig": {
                "NanoCpus": 1_000_000_000,
                "Memory": 1024 ** 3,
                "PidsLimit": 128,
                "ReadonlyRootfs": True,
                "CapDrop": ["ALL"],
                "SecurityOpt": ["no-new-privileges:true"],
                "NetworkMode": "net-abc",
                "PidMode": "",
                "IpcMode": "private",
                "Privileged": False,
                "PortBindings": {},
            },
            "Mounts": [],
        }

    def target_config(self):
        return {
            "Config": {"User": "10001:10001"},
            "HostConfig": {
                "NetworkMode": "net-abc",
                "PidMode": "",
                "Privileged": False,
                "ReadonlyRootfs": True,
                "CapDrop": ["ALL"],
                "SecurityOpt": ["no-new-privileges:true"],
                "Memory": 2 * 1024 ** 3,
                "NanoCpus": 2_000_000_000,
                "PidsLimit": 64,
                "PortBindings": {},
            },
            "Mounts": [{
                "Destination": container.TARGET_FLAG_PATH,
                "RW": False,
                "Type": "bind",
            }],
        }

    def passing_probe(self):
        return {
            "target_reachable": True, "target_health": True, "uid": 10001,
            "secret_file_exists": False, "flag_env_variable_present": False,
            "controller_env_sentinel_present": False,
            "docker_socket_exists": False, "root_write_blocked": True,
            "pid_ns": "pid:[1]", "mnt_ns": "mnt:[1]",
            "host_gateway_reachable": False,
            "host_docker_internal_reachable": False,
            "second_network_reachable": False,
            "external_1_1_1_1_53_reachable": False,
            "external_8_8_8_8_53_reachable": False,
        }

    def engine(self, sentinel_ok=True, solver_config_rm_fails=False):
        responses = [
            ("create --name qjs-ctf-solver-config-abc", (0, "cid", "")),
            ("inspect --format {{json .}} qjs-ctf-solver-config-abc",
             (0, json.dumps(self.solver_config()), "")),
            ("{{json .IPAM.Config}}",
             (0, json.dumps([{"Gateway": "172.18.0.1"}]), "")),
            ("role=sentinel",
             (0 if sentinel_ok else 1, "", "" if sentinel_ok
              else "sentinel failed")),
            ("inspect --format {{json .}} qjs-ctf-sentinel-abc",
             (0, json.dumps({"NetworkSettings": {"Networks": {
                 "net2": {"IPAddress": "10.9.0.2"}}}}), "")),
            ("SENTINEL_READY", (0, "SENTINEL_READY\n", "")),
            ("host_gateway_reachable",
             (0, json.dumps(self.passing_probe()), "")),
            ("os.readlink", (0, json.dumps(
                {"pid_ns": "pid:[2]", "mnt_ns": "mnt:[2]",
                 "uid": 10001, "gid": 10001}), "")),
            ("inspect --format {{json .}} target-abc",
             (0, json.dumps(self.target_config()), "")),
            ("network inspect --format {{json .}} net-abc",
             (0, json.dumps({"Name": "net-abc", "Id": "net-id",
                             "Internal": True, "Driver": "bridge",
                             "Labels": labels("instance-1", "network")}),
              "")),
        ]
        if solver_config_rm_fails:
            responses.insert(
                0, ("rm -f -v qjs-ctf-solver-config-abc",
                    (1, "", "config busy")))
        return FakeEngine(responses)

    def make_instance(self, engine):
        instance = InstanceFixture().instance(engine)
        self.addCleanup(shutil.rmtree, instance.secret_dir, True)
        return instance

    def test_sentinel_startup_failure_still_owns_second_network(self):
        engine = self.engine(sentinel_ok=False)
        instance = self.make_instance(engine)
        with self.assertRaises(container.ContainerError):
            instance.boundary_check(5.0)
        flat = [" ".join(call) for call in engine.calls]
        self.assertTrue(any("network rm qjs-ctf-net2-abc" in call
                            for call in flat))
        self.assertTrue(any("rm -f -v qjs-ctf-sentinel-abc" in call
                            for call in flat))
        secret_dir = instance.secret_dir
        self.assertTrue(instance.stop()["ok"])
        self.assertFalse(secret_dir.exists())

    def test_filesystem_scope_is_pending_when_images_differ(self):
        instance = self.make_instance(self.engine())
        instance.probe_image = "probe:img"
        result = instance.boundary_check(5.0)
        self.assertFalse(result["probe_image_matches_solver_image"])
        self.assertEqual(result["filesystem_pid_separation"]["status"],
                         "pending_actual_solver")
        self.assertEqual(result["actual_solver_checks"]["status"], "pending")
        self.assertEqual(
            result["filesystem_pid_separation"]["probe_image_checks"],
            {name: True for name in (
                "solver_uid_nonroot", "solver_secret_file_absent",
                "controller_env_sentinel_absent", "solver_rootfs_readonly",
                "pid_namespaces_distinct", "mount_namespaces_distinct")})
        self.assertTrue(result["cleanup"]["ok"])
        self.assertTrue(instance.stop()["ok"])

    def test_filesystem_scope_is_actual_when_images_match(self):
        instance = self.make_instance(self.engine())
        instance.probe_image = instance.solver_image
        result = instance.boundary_check(5.0)
        self.assertTrue(result["probe_image_matches_solver_image"])
        self.assertEqual(result["filesystem_pid_separation"]["status"],
                         "passed")
        self.assertEqual(result["actual_solver_checks"]["status"], "passed")
        self.assertTrue(result["cleanup"]["ok"])
        self.assertTrue(instance.stop()["ok"])

    def test_expected_flag_never_reaches_probe_or_config_helper(self):
        engine = self.engine()
        instance = self.make_instance(engine)
        instance._solver_argv = ["/opt/solver", "--mode", "probe"]
        result = instance.boundary_check(5.0)
        self.assertTrue(result["cleanup"]["ok"])
        flag = instance.expected_flag
        for call in engine.calls:
            self.assertNotIn(flag, " ".join(call))
        self.assertTrue(instance.stop()["ok"])

    def test_solver_config_cleanup_failure_is_propagated(self):
        engine = self.engine(solver_config_rm_fails=True)
        instance = self.make_instance(engine)
        result = instance.boundary_check(5.0)
        self.assertFalse(result["cleanup"]["ok"])
        self.assertEqual(result["status"], "failed")
        self.assertIn("boundary_cleanup_failed", result["failures"])
        # The failed helper remains owned for a later retry.
        self.assertEqual(instance._solver_config_name,
                         "qjs-ctf-solver-config-abc")
        engine.responses = [
            response for response in engine.responses
            if "solver-config-abc" not in response[0]
        ]
        self.assertTrue(instance.stop()["ok"])


class MainReportSafetyTests(unittest.TestCase):
    def test_private_argv_and_cleanup_failure_do_not_leak_or_pass(self):
        marker = "PRIVATE_INLINE_SOLVER_SOURCE_marker_987654"
        engine = FakeEngine()
        engine.calls.append({
            "argv": ["/usr/bin/fake-engine", "create", "--name",
                     "solver-config", "--", "python3", "-c", marker],
            "returncode": 0,
        })

        class FakeInstance:
            def public_metadata(self):
                return {"instance_id": "fake"}

            def evaluate(self, timeout_s):
                raise subprocess.TimeoutExpired(
                    ["/usr/bin/fake-engine", "run", "--name", "solver",
                     "python3", "-c", marker], timeout_s)

            def stop(self):
                return {"ok": False,
                        "errors": [{"role": "test",
                                    "error": "cleanup failed"}]}

        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "report.json"
            argv = [
                "container_controller.py", "--engine", "fake-engine",
                "--target-image", "target:img",
                "--solver-image", "solver:img",
                "--egress-mode", "legacy",
                "--solver-json",
                json.dumps(["/opt/solve", "--private", marker]),
                "--timeout", "1", "--report", str(path),
            ]
            with mock.patch.object(sys, "argv", argv), \
                    mock.patch.object(container, "find_engine",
                                      return_value=(
                                          "/usr/bin/fake-engine", "")), \
                    mock.patch.object(container, "Engine",
                                      return_value=engine), \
                    mock.patch.object(container.ContainerInstance, "start",
                                      return_value=FakeInstance()), \
                    mock.patch("sys.stderr"):
                code = container.main()
            self.assertEqual(code, 1)
            text = path.read_text()
            report = json.loads(text)
            self.assertNotIn(marker, text)
            self.assertEqual(report["status"], "failed")
            self.assertIn("timed out", report["error"])
            self.assertFalse(report["cleanup"]["ok"])
            self.assertTrue(report["engine_calls"][0]["arguments_redacted"])
            self.assertNotIn("argv", report["engine_calls"][0])

    def test_strict_failure_report_refreshes_diagnostics_after_cleanup(self):
        secret = "FLAG{" + "9" * 32 + "}"

        class FakeInstance:
            def __init__(self):
                self.results = {}
                self.removed = False

            def public_metadata(self):
                return {
                    "instance_id": "strict-fake",
                    "egress": {"policy": {
                        "removed": self.removed,
                        "install_results": self.results,
                    }},
                }

            def boundary_check(self, timeout_s):
                self.results = {"ipv6": {
                    "attempted": True, "returncode": 1,
                    "stderr": "[REDACTED_FLAG] module unavailable",
                    "batch_sha256": "a" * 64, "rule_count": 7,
                }}
                raise container.ContainerError(
                    "strict install failed with output " + secret)

            def stop(self):
                self.removed = True
                return {"ok": True, "errors": []}

        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "report.json"
            argv = [
                "container_controller.py", "--engine", "fake-engine",
                "--target-image", "target:img",
                "--solver-image", "solver:img",
                "--holder-image", "holder:img",
                "--egress-mode", "strict", "--boundary-check",
                "--report", str(path),
            ]
            engine = FakeEngine()
            with mock.patch.object(sys, "argv", argv), \
                    mock.patch.object(container, "find_engine",
                                      return_value=(
                                          "/usr/bin/fake-engine", "")), \
                    mock.patch.object(container, "Engine",
                                      return_value=engine), \
                    mock.patch.object(container.ContainerInstance, "start",
                                      return_value=FakeInstance()), \
                    mock.patch("sys.stderr"):
                code = container.main()
            self.assertEqual(code, 1)
            text = path.read_text()
            report = json.loads(text)
            policy = report["instance"]["egress"]["policy"]
            self.assertTrue(policy["removed"])
            self.assertEqual(
                policy["install_results"]["ipv6"]["returncode"], 1)
            self.assertEqual(report["boundary"]["status"], "failed")
            self.assertEqual(
                report["boundary"]["endpoint_only_egress"]["status"],
                "failed")
            self.assertEqual(
                report["boundary"]["isolation_gate"]["status"], "pending")
            self.assertNotIn(secret, text)

    def test_partial_boundary_returns_distinct_exit_three(self):
        class FakeInstance:
            def public_metadata(self):
                return {"instance_id": "partial-fake"}

            def boundary_check(self, timeout_s):
                return {
                    "status": "partial",
                    "endpoint_only_egress": {"status": "passed"},
                    "isolation_gate": {"status": "pending"},
                }

            def stop(self):
                return {"ok": True, "errors": []}

        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "report.json"
            argv = [
                "container_controller.py", "--engine", "fake-engine",
                "--target-image", "target:img",
                "--solver-image", "solver:img",
                "--holder-image", "holder:img",
                "--egress-mode", "strict", "--boundary-check",
                "--report", str(path),
            ]
            engine = FakeEngine()
            with mock.patch.object(sys, "argv", argv), \
                    mock.patch.object(container, "find_engine",
                                      return_value=(
                                          "/usr/bin/fake-engine", "")), \
                    mock.patch.object(container, "Engine",
                                      return_value=engine), \
                    mock.patch.object(container.ContainerInstance, "start",
                                      return_value=FakeInstance()), \
                    mock.patch("sys.stderr"):
                code = container.main()
            report = json.loads(path.read_text())
            self.assertEqual(code, 3)
            self.assertEqual(report["status"], "partial")
            self.assertEqual(report["boundary"]["isolation_gate"]["status"],
                             "pending")


class StrictHolderTests(unittest.TestCase):
    def instance(self, engine):
        instance = InstanceFixture().instance(engine)
        self.addCleanup(shutil.rmtree, instance.secret_dir, True)
        instance.egress_mode = "strict"
        instance.holder_image = "holder:img"
        instance._image_ids = {"holder": "sha256:holder",
                               "solver": "sha256:solver"}
        return instance

    def holder_json(self):
        return {
            "Id": "holder-id",
            "Image": "sha256:holder",
            "Config": {"Labels": labels("instance-1", "holder"), "Env": []},
            "HostConfig": {
                "NetworkMode": "net-abc", "Privileged": False,
                "PortBindings": {}, "ReadonlyRootfs": True,
                "CapDrop": ["ALL"],
            },
            "State": {"Running": True, "Pid": 123},
            "NetworkSettings": {"Networks": {
                "net-abc": {"IPAddress": "10.0.0.3"}}},
            "Mounts": [],
        }

    def target_json(self):
        return {"NetworkSettings": {"Networks": {
            "net-abc": {"IPAddress": "10.0.0.2"}}}}

    def test_holder_start_failure_sets_egress_error(self):
        engine = FakeEngine([
            ("role=holder", (1, "", "holder failed")),
        ])
        instance = self.instance(engine)
        with self.assertRaises(container.ContainerError):
            instance._start_strict_holder()
        self.assertEqual(instance._egress_error,
                         "strict holder setup failed")
        self.assertIsNone(instance._policy_handle)
        holder_run = next(call for call in engine.calls
                          if "role=holder" in " ".join(call))
        self.assertIn("sha256:holder", holder_run)
        self.assertNotIn("holder:img", holder_run)

    def test_host_namespace_handle_is_rejected_and_closed(self):
        engine = FakeEngine([
            ("role=holder", (0, "holder-id\n", "")),
            ("inspect --format {{json .}} qjs-ctf-holder-abc",
             (0, json.dumps(self.holder_json()), "")),
            ("inspect --format {{json .}} target-abc",
             (0, json.dumps(self.target_json()), "")),
        ])
        instance = self.instance(engine)
        handle = FakeNamespaceHandle()
        handle.inode = handle.host_inode
        with mock.patch.object(container.egress_policy,
                               "open_network_namespace",
                               return_value=handle), \
                mock.patch.object(container.egress_policy,
                                  "namespace_matches_pid",
                                  return_value=True):
            with self.assertRaises(container.ContainerError) as caught:
                instance._start_strict_holder()
        self.assertIn("host namespace", str(caught.exception))
        self.assertTrue(handle.closed)
        self.assertIsNone(instance._policy_handle)

    def test_namespace_pid_mismatch_is_rejected_and_closed(self):
        engine = FakeEngine([
            ("role=holder", (0, "holder-id\n", "")),
            ("inspect --format {{json .}} qjs-ctf-holder-abc",
             (0, json.dumps(self.holder_json()), "")),
            ("inspect --format {{json .}} target-abc",
             (0, json.dumps(self.target_json()), "")),
        ])
        instance = self.instance(engine)
        handle = FakeNamespaceHandle()
        with mock.patch.object(container.egress_policy,
                               "open_network_namespace",
                               return_value=handle), \
                mock.patch.object(container.egress_policy,
                                  "namespace_matches_pid",
                                  return_value=False):
            with self.assertRaises(container.ContainerError) as caught:
                instance._start_strict_holder()
        self.assertIn("does not match", str(caught.exception))
        self.assertTrue(handle.closed)
        self.assertIsNone(instance._policy_handle)


class StrictResetTests(unittest.TestCase):
    def test_strict_reset_uses_holder_mode_and_fresh_flag(self):
        created = []

        class FakeInstance:
            def __init__(self):
                self.flag = "FLAG{" + secrets.token_hex(16) + "}"
                self.stopped = False

            def public_metadata(self):
                return {"instance_id": secrets.token_hex(4),
                        "flag_length": len(self.flag)}

            def stop(self):
                self.stopped = True
                return {"ok": True, "errors": []}

        def fake_start(*args, **kwargs):
            instance = FakeInstance()
            created.append(instance)
            return instance

        evaluator = container.ContainerEvaluator(
            FakeEngine(), "target:img", "solver:img", ["/opt/solve"],
            egress_mode="strict", holder_image="holder:img")
        with mock.patch.object(container.ContainerInstance, "start",
                               side_effect=fake_start):
            evaluator.start()
            metadata = evaluator.reset()
        self.assertEqual(len(created), 2)
        self.assertTrue(created[0].stopped)
        self.assertFalse(created[1].stopped)
        self.assertNotEqual(created[0].flag, created[1].flag)
        self.assertNotIn(created[1].flag, json.dumps(metadata))


class FakeNamespaceHandle:
    fd = 9
    inode = 42
    host_inode = 7
    closed = False

    @property
    def distinct_from_host(self):
        return not (self.inode == self.host_inode)

    def close(self):
        self.closed = True


class FakePolicyRuntime:
    def __init__(self, v4: str, v6: str, *, install4=0, install6=0,
                 host_v4="# host\\n", host_v6="# host6\\n",
                 install4_stderr="", install6_stderr="",
                 readback4_stderr="", readback6_stderr=""):
        self.v4 = v4
        self.v6 = v6
        self.install4 = install4
        self.install6 = install6
        self.host_v4 = host_v4
        self.host_v6 = host_v6
        self.install4_stderr = install4_stderr
        self.install6_stderr = install6_stderr
        self.readback4_stderr = readback4_stderr
        self.readback6_stderr = readback6_stderr
        self.installs = []
        self.readbacks = 0

    def install_v4(self, handle, batch):
        self.installs.append(("ipv4", batch))
        return subprocess.CompletedProcess(
            ["fake"], self.install4, "", self.install4_stderr)

    def install_v6(self, handle, batch):
        self.installs.append(("ipv6", batch))
        return subprocess.CompletedProcess(
            ["fake"], self.install6, "", self.install6_stderr)

    def readback_v4(self, handle):
        self.readbacks += 1
        return subprocess.CompletedProcess(
            ["fake"], 0, self.v4, self.readback4_stderr)

    def readback_v6(self, handle):
        return subprocess.CompletedProcess(
            ["fake"], 0, self.v6, self.readback6_stderr)

    def host_readback_v4(self):
        return subprocess.CompletedProcess(["fake"], 0, self.host_v4, "")

    def host_readback_v6(self):
        return subprocess.CompletedProcess(["fake"], 0, self.host_v6, "")


class StrictEgressActivationTests(unittest.TestCase):
    def holder_json(self, *, running=True):
        return {
            "Id": "holder-id",
            "Image": "sha256:holder",
            "Config": {"Labels": labels("instance-1", "holder"), "Env": []},
            "HostConfig": {
                "NetworkMode": "net-abc", "Privileged": False,
                "PortBindings": {}, "ReadonlyRootfs": True,
                "CapDrop": ["ALL"],
            },
            "State": {"Running": running, "Pid": 123},
            "NetworkSettings": {"Networks": {
                "net-abc": {"IPAddress": "10.0.0.3"}}},
            "Mounts": [],
        }

    def instance(self, runtime, holder_running=True):
        engine = FakeEngine([
            ("{{json .IPAM.Config}}",
             (0, json.dumps([{"Gateway": "172.18.0.1"}]), "")),
            ("inspect --format {{json .}} qjs-ctf-holder-abc",
             (0, json.dumps(self.holder_json(running=holder_running)), "")),
        ])
        instance = InstanceFixture().instance(engine)
        self.addCleanup(shutil.rmtree, instance.secret_dir, True)
        instance.egress_mode = "strict"
        instance.holder_image = "holder:img"
        instance._holder_name = "qjs-ctf-holder-abc"
        instance._holder_id = "holder-id"
        instance._holder_pid = 123
        instance._holder_ip = "10.0.0.3"
        instance._target_ip = "10.0.0.2"
        instance._policy_marker = container.egress_policy.policy_marker(
            instance.instance_id)
        instance._policy_handle = FakeNamespaceHandle()
        instance._image_ids = {"holder": "sha256:holder",
                               "solver": "sha256:solver"}
        instance._policy_runtime = runtime
        return instance

    def runtime(self, *, install4=0, install6=0, tamper_v4=False):
        v4, v6 = policy_texts(
            TEST_MARKER, "10.0.0.2", "172.18.0.1", "10.9.0.2")
        if tamper_v4:
            v4 = v4.replace("-j ACCEPT", "-j DROP", 1)
        return FakePolicyRuntime(
            v4, v6, install4=install4, install6=install6)

    def test_activate_installs_both_families_and_reports_atomicity(self):
        runtime = self.runtime()
        instance = self.instance(runtime)
        with mock.patch.object(container.egress_policy,
                               "namespace_matches_pid", return_value=True):
            instance._activate_egress_policy(
                extra_deny_ip="10.9.0.2", require_gateway=True)
        self.assertTrue(instance._policy_installed)
        self.assertEqual([name for name, _ in runtime.installs],
                         ["ipv4", "ipv6"])
        self.assertTrue(instance._policy_readback["ok"])
        self.assertFalse(instance._policy_readback["atomicity"][
            "cross_family_sequence_atomic"])
        self.assertEqual(instance._host_firewall_unchanged, True)
        self.assertFalse(instance._host_marker_present_after)
        metadata = instance._egress_public_metadata()
        self.assertEqual(metadata["backend"], "iptables-legacy")
        self.assertEqual(metadata["policy"]["marker"], TEST_MARKER)

    def test_activate_fails_when_ipv6_install_fails(self):
        runtime = self.runtime(install6=1)
        runtime.v6 = ""
        instance = self.instance(runtime)
        with mock.patch.object(container.egress_policy,
                               "namespace_matches_pid", return_value=True):
            with self.assertRaises(container.ContainerError) as caught:
                instance._activate_egress_policy(
                    extra_deny_ip="10.9.0.2", require_gateway=True)
        self.assertIn("install failed", str(caught.exception))
        self.assertFalse(instance._policy_installed)
        self.assertEqual(
            instance._policy_install_results["ipv6"]["returncode"], 1)

    def test_failed_install_diagnostics_are_bounded_redacted_and_retained(self):
        secret = "FLAG{" + "d" * 32 + "}"
        stderr = ("nsenter --net=/proc/self/fd/9: " + secret + " "
                  + ("x" * 3000))
        runtime = self.runtime(install6=1)
        runtime.install6_stderr = stderr
        runtime.readback6_stderr = stderr
        runtime.v6 = ""
        instance = self.instance(runtime, holder_running=False)
        instance._flag = secret
        with mock.patch.object(container.egress_policy,
                               "namespace_matches_pid", return_value=True):
            with self.assertRaises(container.ContainerError):
                instance._activate_egress_policy(
                    extra_deny_ip="10.9.0.2", require_gateway=True)
        record = instance._policy_install_results["ipv6"]
        self.assertEqual(record["returncode"], 1)
        self.assertEqual(record["rule_count"], 7)
        self.assertRegex(record["batch_sha256"], r"^[0-9a-f]{64}$")
        self.assertTrue(record["stderr_truncated"])
        self.assertNotIn(secret, json.dumps(record))
        self.assertNotIn("/proc/self/fd/9", json.dumps(record))
        self.assertIn("/proc/self/fd/<fd>", record["stderr"])
        before = json.loads(json.dumps(instance._egress_public_metadata()))
        self.assertEqual(instance._remove_egress_policy(), [])
        after = instance._egress_public_metadata()
        self.assertEqual(after["policy"]["install_results"],
                         before["policy"]["install_results"])
        self.assertIn("ipv6", after["policy"]["readback_results"])
        readback = after["policy"]["readback_results"]["ipv6"]
        self.assertTrue(readback["stderr_truncated"])
        self.assertNotIn(secret, json.dumps(readback))
        self.assertIn("/proc/self/fd/<fd>", readback["stderr"])
        self.assertTrue(after["policy"]["removed"])

    def test_activate_fails_on_readback_tamper(self):
        runtime = self.runtime(tamper_v4=True)
        instance = self.instance(runtime)
        with mock.patch.object(container.egress_policy,
                               "namespace_matches_pid", return_value=True):
            with self.assertRaises(container.ContainerError) as caught:
                instance._activate_egress_policy(
                    extra_deny_ip="10.9.0.2", require_gateway=True)
        self.assertIn("readback failed", str(caught.exception))
        self.assertFalse(instance._policy_installed)

    def test_activate_fails_on_wrong_namespace(self):
        runtime = self.runtime()
        instance = self.instance(runtime)
        with mock.patch.object(container.egress_policy,
                               "namespace_matches_pid", return_value=False):
            with self.assertRaises(container.ContainerError) as caught:
                instance._activate_egress_policy(
                    extra_deny_ip="10.9.0.2", require_gateway=True)
        self.assertIn("namespace changed", str(caught.exception))
        self.assertFalse(instance._policy_installed)

    def test_activate_refuses_host_marker_and_installs_nothing(self):
        v4, v6 = policy_texts(
            TEST_MARKER, "10.0.0.2", "172.18.0.1", "10.9.0.2")
        runtime = FakePolicyRuntime(
            v4, v6, host_v4=TEST_MARKER)
        instance = self.instance(runtime)
        with mock.patch.object(container.egress_policy,
                               "namespace_matches_pid", return_value=True):
            with self.assertRaises(container.ContainerError) as caught:
                instance._activate_egress_policy(
                    extra_deny_ip="10.9.0.2", require_gateway=True)
        self.assertIn("host firewall", str(caught.exception))
        self.assertEqual(runtime.installs, [])


class StrictPolicyRemovalTests(unittest.TestCase):
    def instance(self, engine):
        instance = InstanceFixture().instance(engine)
        self.addCleanup(shutil.rmtree, instance.secret_dir, True)
        instance.egress_mode = "strict"
        instance.holder_image = "holder:img"
        instance._holder_name = "qjs-ctf-holder-abc"
        instance._holder_id = "holder-id"
        instance._target_ip = "10.0.0.2"
        instance._policy_marker = "qjs_egress_instance_1"
        instance._policy_handle = FakeNamespaceHandle()
        instance._policy_install_attempted = True
        instance._policy_installed = True
        return instance

    def holder_json(self, running):
        return {
            "Id": "holder-id",
            "Config": {"Labels": labels("instance-1", "holder")},
            "State": {"Running": running, "Pid": 123},
        }

    def test_explicit_not_found_establishes_holder_gone(self):
        engine = FakeEngine([
            ("inspect --format {{json .}} qjs-ctf-holder-abc",
             (1, "", "Error: No such object: qjs-ctf-holder-abc")),
        ])
        instance = self.instance(engine)
        handle = instance._policy_handle
        self.assertEqual(instance._remove_egress_policy(), [])
        self.assertTrue(instance._policy_removed)
        self.assertFalse(instance._policy_installed)
        self.assertTrue(handle.closed)
        self.assertIsNone(instance._policy_handle)

    def test_holder_stopped_establishes_namespace_gone(self):
        engine = FakeEngine([
            ("inspect --format {{json .}} qjs-ctf-holder-abc",
             (0, json.dumps(self.holder_json(False)), "")),
        ])
        instance = self.instance(engine)
        handle = instance._policy_handle
        self.assertEqual(instance._remove_egress_policy(), [])
        self.assertTrue(instance._policy_removed)
        self.assertTrue(handle.closed)

    def test_running_holder_retains_deny_policy(self):
        engine = FakeEngine([
            ("inspect --format {{json .}} qjs-ctf-holder-abc",
             (0, json.dumps(self.holder_json(True)), "")),
        ])
        instance = self.instance(engine)
        handle = instance._policy_handle
        errors = instance._remove_egress_policy()
        self.assertTrue(errors)
        self.assertIn("still running", json.dumps(errors))
        self.assertFalse(instance._policy_removed)
        self.assertFalse(handle.closed)

    def test_inspect_timeout_is_unknown_and_retains_state(self):
        class TimeoutInspectEngine(FakeEngine):
            def run(self, argv, timeout=None, env=None):
                if "inspect" in argv:
                    raise subprocess.TimeoutExpired(argv, timeout or 1)
                return super().run(argv, timeout=timeout, env=env)

        instance = self.instance(TimeoutInspectEngine())
        handle = instance._policy_handle
        errors = instance._remove_egress_policy()
        self.assertTrue(errors)
        text = json.dumps(errors)
        self.assertIn("unknown", text)
        self.assertIn("retained", text)
        self.assertFalse(instance._policy_removed)
        self.assertFalse(handle.closed)

    def test_no_premature_removal_while_solver_remains(self):
        engine = FakeEngine([
            ("inspect --format {{json .}} solver-x",
             (0, json.dumps({"Id": "solver-x", "Config": {
                 "Labels": labels("instance-1", "solver")}}), "")),
            ("rm -f -v solver-x", (1, "", "solver busy")),
        ])
        instance = self.instance(engine)
        instance._active_solver_name = "solver-x"
        handle = instance._policy_handle
        result = instance.stop()
        self.assertFalse(result["ok"])
        self.assertFalse(instance._policy_removed)
        self.assertFalse(handle.closed)
        self.assertFalse(instance._holder_removed)
        self.assertIn("deferred", json.dumps(result["errors"]))

    def test_holder_removed_before_policy_state_is_retired(self):
        holder_name = "qjs-ctf-holder-abc"

        class LifecycleEngine(FakeEngine):
            def __init__(self):
                super().__init__()
                self.holder_removed = False

            def run(self, argv, timeout=None, env=None):
                joined = " ".join(argv)
                self.calls.append(list(argv))
                if "rm" in argv and holder_name in joined:
                    self.holder_removed = True
                    return subprocess.CompletedProcess(argv, 0, "", "")
                if "inspect" in argv and holder_name in joined:
                    if self.holder_removed:
                        return subprocess.CompletedProcess(
                            argv, 1, "", "Error: No such object")
                    return subprocess.CompletedProcess(
                        argv, 0, json.dumps({
                            "Id": holder_name,
                            "Config": {"Labels": labels(
                                "instance-1", "holder")},
                            "State": {"Running": True, "Pid": 123},
                        }), "")
                if "inspect" in argv and "solver-x" in joined:
                    return subprocess.CompletedProcess(
                        argv, 0, json.dumps({
                            "Id": "solver-x",
                            "Config": {"Labels": labels(
                                "instance-1", "solver")},
                        }), "")
                if "inspect" in argv and "target-abc" in joined:
                    return subprocess.CompletedProcess(
                        argv, 0, json.dumps({
                            "Id": "target-abc",
                            "Config": {"Labels": labels(
                                "instance-1", "target")},
                        }), "")
                if "network" in argv and "inspect" in argv:
                    return subprocess.CompletedProcess(
                        argv, 0, json.dumps({
                            "Labels": labels("instance-1", "network")}), "")
                return subprocess.CompletedProcess(argv, 0, "", "")

        engine = LifecycleEngine()
        instance = self.instance(engine)
        instance._active_solver_name = "solver-x"
        handle = instance._policy_handle
        result = instance.stop()
        self.assertTrue(result["ok"], result)
        self.assertTrue(instance._policy_removed)
        self.assertTrue(instance._holder_removed)
        self.assertTrue(handle.closed)
        rm_index = next(
            index for index, call in enumerate(engine.calls)
            if "rm" in call and holder_name in " ".join(call))
        late_inspect = [
            index for index, call in enumerate(engine.calls)
            if "inspect" in call and holder_name in " ".join(call)
            and index > rm_index]
        self.assertTrue(late_inspect)
        self.assertGreater(late_inspect[0], rm_index)


class StrictEvaluateOrderingTests(unittest.TestCase):
    def instance(self):
        engine = FakeEngine()
        instance = InstanceFixture().instance(engine)
        self.addCleanup(shutil.rmtree, instance.secret_dir, True)
        instance.egress_mode = "strict"
        instance.holder_image = "holder:img"
        instance._holder_name = "qjs-ctf-holder-abc"
        instance._holder_id = "holder-id"
        instance._holder_pid = 123
        instance._target_ip = "10.0.0.2"
        instance._policy_marker = "qjs_egress_instance_1"
        instance._policy_handle = FakeNamespaceHandle()
        instance._policy_installed = True
        instance._image_ids = {"holder": "sha256:holder",
                               "solver": "sha256:solver"}
        instance._solver_argv = ["/opt/solve"]
        return instance

    def solver_json(self, *, privileged=False, pid_mode="",
                    ipc_mode="private", mounts=None, tmpfs=None,
                    binds=None, host_mounts=None, volumes_from=None,
                    cap_add=None, devices=None, device_requests=None,
                    device_cgroup_rules=None, security_opt=None,
                    user="10001:10001"):
        return {
            "Id": "solver-cid",
            "Image": "sha256:solver",
            "Config": {
                "User": user, "Env": [],
                "Cmd": ["/opt/solve", "10.0.0.2:8000"],
                "Entrypoint": None,
                "Labels": labels("instance-1", "solver"),
            },
            "HostConfig": {
                "NanoCpus": 1_000_000_000,
                "Memory": 1024 ** 3,
                "PidsLimit": 128,
                "ReadonlyRootfs": True,
                "CapDrop": ["ALL"],
                "SecurityOpt": (security_opt if security_opt is not None
                                else ["no-new-privileges:true"]),
                "NetworkMode": "container:holder-id",
                "PidMode": pid_mode, "IpcMode": ipc_mode,
                "Privileged": privileged, "PortBindings": {},
                "Tmpfs": (tmpfs if tmpfs is not None else {
                    "/tmp": "rw,noexec,nosuid,nodev,size=16m"}),
                "Binds": binds,
                "Mounts": host_mounts,
                "VolumesFrom": volumes_from,
                "CapAdd": cap_add,
                "Devices": devices,
                "DeviceRequests": device_requests,
                "DeviceCgroupRules": device_cgroup_rules,
            },
            "Mounts": mounts or [],
        }

    def result(self, instance, *, returncode=0, timed_out=False):
        flag = instance.expected_flag
        return {
            "stdout": flag + "\n",
            "stdout_bytes": len(flag) + 1,
            "stdout_retained_bytes": len(flag) + 1,
            "stdout_truncated": False,
            "stderr_bytes": 0,
            "stderr_truncated": False,
            "returncode": returncode,
            "timed_out": timed_out,
            "timeout_cleanup_error": False,
            "duration_s": 0.01,
        }

    def test_create_inspect_start_uses_one_exact_container(self):
        instance = self.instance()
        instance.engine = FakeEngine([
            ("create --name", (0, "solver-cid\n", "")),
            ("inspect --format {{json .}} qjs-ctf-solver-",
             (0, json.dumps(self.solver_json()), "")),
            ("rm -f -v qjs-ctf-solver-", (0, "", "")),
        ])
        calls = []

        def fake_execute(argv, timeout_s, on_timeout=None):
            calls.append(list(argv))
            return self.result(instance)

        with mock.patch.object(instance, "_ensure_egress_active"), \
                mock.patch.object(container, "execute_solver",
                                  side_effect=fake_execute):
            verdict = instance.evaluate(5.0)
        self.assertTrue(verdict["ok"])
        self.assertTrue(verdict["created_container_inspected_before_start"])
        self.assertEqual(verdict["solver_image_id"], "sha256:solver")
        create_calls = [call for call in instance.engine.calls
                        if len(call) > 1 and call[1] == "create"]
        self.assertEqual(len(create_calls), 1)
        solver_name = create_calls[0][3]
        self.assertEqual(calls, [[instance.engine.path, "start", "-a",
                                  solver_name]])
        self.assertFalse(any(len(call) > 1 and call[1] == "run"
                             for call in instance.engine.calls))
        create_index = instance.engine.calls.index(create_calls[0])
        inspect_index = next(
            index for index, call in enumerate(instance.engine.calls)
            if "inspect" in call and solver_name in " ".join(call))
        self.assertLess(create_index, inspect_index)
        self.assertTrue(any("rm" in call and "solver-cid" in " ".join(call)
                            for call in instance.engine.calls))

    def test_solver_runs_only_after_policy_is_active(self):
        instance = self.instance()
        instance._policy_installed = False
        instance.engine = FakeEngine([
            ("create --name", (0, "solver-cid\n", "")),
            ("inspect --format {{json .}} qjs-ctf-solver-",
             (0, json.dumps(self.solver_json()), "")),
            ("rm -f -v qjs-ctf-solver-", (0, "", "")),
        ])
        events = []
        original_require = instance.engine.require

        def ensure_policy():
            events.append("policy")
            instance._policy_installed = True

        def require(argv, name, timeout=None, env=None):
            if len(argv) > 1 and argv[1] == "create":
                events.append("create")
            if len(argv) > 1 and argv[1] == "inspect":
                events.append("inspect")
            return original_require(argv, name, timeout=timeout, env=env)

        def fake_execute(argv, timeout_s, on_timeout=None):
            events.append("start")
            return self.result(instance)

        with mock.patch.object(instance, "_ensure_egress_active",
                               side_effect=ensure_policy), \
                mock.patch.object(instance.engine, "require",
                                  side_effect=require), \
                mock.patch.object(container, "execute_solver",
                                  side_effect=fake_execute):
            verdict = instance.evaluate(5.0)
        self.assertTrue(verdict["ok"])
        # Policy is checked before create and again after exact inspect,
        # immediately before the only start operation.
        self.assertEqual(events, [
            "policy", "create", "inspect", "policy", "start"])

    def test_post_inspect_policy_failure_removes_without_starting(self):
        instance = self.instance()
        instance.engine = FakeEngine([
            ("create --name", (0, "solver-cid\n", "")),
            ("inspect --format {{json .}} qjs-ctf-solver-",
             (0, json.dumps(self.solver_json()), "")),
            ("rm -f -v qjs-ctf-solver-", (0, "", "")),
        ])
        execute_calls = []
        checks = [None, container.ContainerError(
            "target endpoint changed after inspect")]

        def ensure_policy():
            outcome = checks.pop(0)
            if outcome is not None:
                raise outcome

        with mock.patch.object(instance, "_ensure_egress_active",
                               side_effect=ensure_policy), \
                mock.patch.object(
                    container, "execute_solver",
                    side_effect=lambda *args, **kwargs:
                    execute_calls.append(args)):
            with self.assertRaises(container.ContainerError) as caught:
                instance.evaluate(5.0)
        self.assertIn("after inspect", str(caught.exception))
        self.assertEqual(execute_calls, [])
        self.assertEqual(checks, [])
        self.assertTrue(any("rm" in call and "solver-cid" in " ".join(call)
                            for call in instance.engine.calls))

    def test_shared_pid_ipc_or_any_mount_is_rejected(self):
        cases = (
            ({"pid_mode": "host"}, "pid_namespace_not_private"),
            ({"ipc_mode": "host"}, "ipc_namespace_not_private"),
            ({"mounts": [{"Destination": "/unexpected", "RW": False,
                           "Type": "bind"}]}, "unexpected_mounts"),
        )
        for overrides, problem in cases:
            with self.subTest(problem=problem):
                instance = self.instance()
                instance.engine = FakeEngine([
                    ("create --name", (0, "solver-cid\n", "")),
                    ("inspect --format {{json .}} qjs-ctf-solver-",
                     (0, json.dumps(self.solver_json(**overrides)), "")),
                    ("rm -f -v qjs-ctf-solver-", (0, "", "")),
                ])
                execute_calls = []
                with mock.patch.object(
                        instance, "_ensure_egress_active"), \
                        mock.patch.object(
                            container, "execute_solver",
                            side_effect=lambda *args, **kwargs:
                            execute_calls.append(args)):
                    with self.assertRaises(container.ContainerError) as caught:
                        instance.evaluate(5.0)
                self.assertIn(problem, str(caught.exception))
                self.assertEqual(execute_calls, [])

    def test_exact_mount_capability_and_device_allowlist_is_enforced(self):
        safe_options = "rw,noexec,nosuid,nodev,size=16m"
        cases = (
            ({"tmpfs": {"/tmp": safe_options,
                         "/scratch": safe_options}},
             "tmpfs_not_exact"),
            ({"tmpfs": {"/tmp":
                         "rw,nosuid,nodev,size=16m"}},
             "tmpfs_not_exact"),
            ({"binds": ["/host:/container:ro"]}, "host_binds"),
            ({"host_mounts": [{"Type": "bind", "Source": "/host",
                                "Target": "/container"}]},
             "host_mounts"),
            ({"volumes_from": ["another:ro"]}, "volumes_from"),
            ({"mounts": [{"Destination": "/data", "RW": True,
                           "Type": "volume"}]},
             "unexpected_mounts"),
            ({"cap_add": ["NET_ADMIN"]}, "capabilities_added"),
            ({"devices": [{"PathOnHost": "/dev/null",
                            "PathInContainer": "/dev/x"}]},
             "devices"),
            ({"device_requests": [{"Driver": "", "Count": -1,
                                    "Capabilities": [["gpu"]]}]},
             "device_requests"),
            ({"device_cgroup_rules": ["c 1:3 rwm"]},
             "device_cgroup_rules"),
            ({"security_opt": ["no-new-privileges:false"]},
             "no_new_privileges_missing"),
            ({"security_opt": ["no-new-privileges:true",
                                "seccomp=unconfined"]},
             "no_new_privileges_missing"),
            ({"user": "10002:10002"}, "user_identity_mismatch"),
        )
        for overrides, problem in cases:
            with self.subTest(problem=problem):
                instance = self.instance()
                instance.engine = FakeEngine([
                    ("create --name", (0, "solver-cid\n", "")),
                    ("inspect --format {{json .}} qjs-ctf-solver-",
                     (0, json.dumps(self.solver_json(**overrides)), "")),
                    ("rm -f -v qjs-ctf-solver-", (0, "", "")),
                ])
                execute_calls = []
                with mock.patch.object(
                        instance, "_ensure_egress_active"), \
                        mock.patch.object(
                            container, "execute_solver",
                            side_effect=lambda *args, **kwargs:
                            execute_calls.append(args)):
                    with self.assertRaises(container.ContainerError) as caught:
                        instance.evaluate(5.0)
                self.assertIn(problem, str(caught.exception))
                self.assertEqual(execute_calls, [])

    def test_tmpfs_option_order_and_size_normalization_are_accepted(self):
        instance = self.instance()
        instance.engine = FakeEngine([
            ("create --name", (0, "solver-cid\n", "")),
            ("inspect --format {{json .}} qjs-ctf-solver-",
             (0, json.dumps(self.solver_json(tmpfs={
                 "/tmp": "nodev,size=16777216,nosuid,rw,noexec"},
                 security_opt=["NO-NEW-PRIVILEGES=TRUE"])), "")),
            ("rm -f -v qjs-ctf-solver-", (0, "", "")),
        ])
        with mock.patch.object(instance, "_ensure_egress_active"), \
                mock.patch.object(container, "execute_solver",
                                  return_value=self.result(instance)):
            verdict = instance.evaluate(5.0)
        self.assertTrue(verdict["ok"])

    def test_config_rejection_removes_container_without_starting(self):
        instance = self.instance()
        instance.engine = FakeEngine([
            ("create --name", (0, "solver-cid\n", "")),
            ("inspect --format {{json .}} qjs-ctf-solver-",
             (0, json.dumps(self.solver_json(privileged=True)), "")),
            ("rm -f -v qjs-ctf-solver-", (0, "", "")),
        ])
        execute_calls = []
        with mock.patch.object(instance, "_ensure_egress_active"), \
                mock.patch.object(
                    container, "execute_solver",
                    side_effect=lambda *args, **kwargs:
                    execute_calls.append(args)):
            with self.assertRaises(container.ContainerError) as caught:
                instance.evaluate(5.0)
        self.assertIn("configuration was rejected", str(caught.exception))
        self.assertEqual(execute_calls, [])
        self.assertTrue(any("rm" in call and "solver-cid" in " ".join(call)
                            for call in instance.engine.calls))
        self.assertNotIn(instance.expected_flag, str(caught.exception))

    def test_startup_failure_still_removes_the_container(self):
        instance = self.instance()
        instance.engine = FakeEngine([
            ("create --name", (0, "solver-cid\n", "")),
            ("inspect --format {{json .}} qjs-ctf-solver-",
             (0, json.dumps(self.solver_json()), "")),
            ("rm -f -v qjs-ctf-solver-", (0, "", "")),
        ])
        with mock.patch.object(instance, "_ensure_egress_active"), \
                mock.patch.object(
                    container, "execute_solver",
                    return_value=self.result(instance, returncode=1)):
            verdict = instance.evaluate(5.0)
        self.assertFalse(verdict["ok"])
        self.assertEqual(verdict["reason"], "error")
        self.assertTrue(verdict["container_cleanup"]["ok"])

    def test_inspect_error_is_redacted_and_secret_removed(self):
        marker = "PRIVATE_INSPECT_MARKER_13579"
        instance = self.instance()
        instance.engine = FakeEngine([
            ("create --name", (0, "solver-cid\n", "")),
            ("inspect --format {{json .}} qjs-ctf-solver-",
             (0, marker, "")),
            ("rm -f -v qjs-ctf-solver-", (0, "", "")),
        ])
        secret_dir = instance.secret_dir
        with mock.patch.object(instance, "_ensure_egress_active"):
            with self.assertRaises(container.ContainerError) as caught:
                instance.evaluate(5.0)
        self.assertIn("invalid JSON", str(caught.exception))
        self.assertNotIn(marker, str(caught.exception))
        self.assertTrue(any("rm" in call for call in instance.engine.calls))
        instance.stop()
        self.assertFalse(secret_dir.exists())


class StrictBoundaryCompositionTests(unittest.TestCase):
    def payload(self, mode, handle_inode=42):
        is_control = (mode == "control")

        def tcp(connected):
            return {"connected": connected,
                    "error": None if connected else "TimeoutError",
                    "errno": None if connected else 110}

        def loop_tcp(connected):
            return {"listener_available": True,
                    "connect_allowed": connected,
                    "connect_error": None if connected else "TimeoutError",
                    "accepts": 1 if connected else 0,
                    "listener_error": None}

        def loop_udp(received):
            if received:
                return {"listener_available": True, "sent": True,
                        "received": received, "send_error": None,
                        "listener_error": None}
            # A DROP rule on the holder OUTPUT chain surfaces a locally
            # generated UDP datagram as EPERM on this platform.
            return {"listener_available": True, "sent": False,
                    "received": 0, "send_error": "PermissionError",
                    "listener_error": None}

        def udp_sent():
            return {"sent": True, "error": None, "errno": None}

        def udp_eperm():
            return {"sent": False, "error": "PermissionError", "errno": 1}

        def dns(ok, error=None):
            return {"ok": ok,
                    "error": None if ok else (error or "TimeoutError"),
                    "errno": 1 if error == "PermissionError" else None}

        return {
            "mode": mode,
            "uid": 10001,
            "gid": 10001,
            "target_health": True,
            "target_repeated": True,
            "target_large_request": True,
            "target_large_request_source_bytes": 20019,
            "js_capabilities": {
                "json": True, "typed_array": True,
                "string": True, "callback": True},
            "target_other_port": tcp(is_control),
            "host_tcp": tcp(is_control),
            "host_udp_send": udp_sent() if is_control else udp_eperm(),
            "second_network_tcp": tcp(is_control),
            "second_network_udp_send": (
                udp_sent() if is_control else udp_eperm()),
            "default_probe_tcp": tcp(False),
            "default_probe_send": (
                udp_sent() if is_control else udp_eperm()),
            "docker_dns_udp": dns(
                is_control, None if is_control else "PermissionError"),
            "docker_dns_tcp": dns(is_control),
            "loopback_ipv4": {
                "tcp": loop_tcp(is_control),
                "udp": loop_udp(1 if is_control else 0)},
            "loopback_ipv6": {
                "tcp": loop_tcp(is_control),
                "udp": loop_udp(1 if is_control else 0)},
            "ipv6_test_address": {
                "address": container.egress_policy.IPV6_TEST_ADDRESS,
                "tcp": loop_tcp(is_control),
                "udp": loop_udp(1 if is_control else 0)},
            "mapped_forbidden_ipv4": tcp(is_control),
            "secret_file_exists": False,
            "docker_socket_exists": False,
            "flag_env_variable_present": False,
            "controller_env_sentinel_present": False,
            "root_write_blocked": True,
            "capabilities": {
                "no_cap_net_admin": True,
                "no_cap_sys_admin": True,
                "unshare_netns_denied": True,
                "setns_netns_denied": True,
                "firewall_mutation": {
                    "attempted": True, "denied": True},
            },
            "namespaces": {
                "pid_ns": "pid:[3]", "mnt_ns": "mnt:[3]",
                "net_ns": f"net:[{handle_inode}]"},
        }

    def security_config(self, image_id="sha256:solver"):
        return {
            "user": "10001:10001",
            "non_root_user": True,
            "image_id": image_id,
            "limit_cpu": 1_000_000_000,
            "limit_memory": 1024 ** 3,
            "limit_pids": 128,
            "readonly_rootfs": True,
            "cap_drop_all": True,
            "no_new_privileges": True,
            "network_mode": "container:holder-id",
            "pid_mode": "", "ipc_mode": "private",
            "privileged": False, "port_bindings": {},
            "tmpfs": {"/tmp":
                       "rw,noexec,nosuid,nodev,size=16777216"},
            "binds": None, "host_mounts": None,
            "volumes_from": None, "cap_add": None, "devices": None,
            "device_requests": None, "device_cgroup_rules": None,
            "secret_mount": False, "docker_socket_mount": False,
            "flag_env_present": False, "flag_value_in_env": False,
            "flag_value_in_command": False,
            "mounts": [],
        }

    def holder_security_config(self, image_id="sha256:holder"):
        config = self.security_config(image_id=image_id)
        config.update({
            "limit_cpu": 500_000_000,
            "limit_memory": 128 * 1024 ** 2,
            "limit_pids": 32,
        })
        return config

    def counters(self, value):
        keys = (
            "output_allow", "input_established",
            "output_target_other_port", "output_gateway",
            "output_second_network", "output_docker_dns",
            "output_loopback", "output_udp", "output_default",
            "output_v6_loopback", "output_v6_test_address",
        )
        return {key: {"packets": value, "bytes": value * 10}
                for key in keys}

    def make_instance(self, *, sentinel_network_cleanup_ok=True,
                      strict_probe_image_id="sha256:holder",
                      control_image_id="sha256:holder",
                      sentinel_image_id="sha256:holder",
                      strict_capability_overrides=None,
                      strict_config_overrides=None,
                      actual_solver_image_id="sha256:solver",
                      actual_solver_config_overrides=None,
                      ensure_error=None, trace=None,
                      probe_payload_mutator=None):
        engine = FakeEngine()
        instance = InstanceFixture().instance(engine)
        self.addCleanup(shutil.rmtree, instance.secret_dir, True)
        instance.egress_mode = "strict"
        instance.holder_image = "holder:img"
        instance._holder_name = "qjs-ctf-holder-abc"
        instance._holder_id = "holder-id"
        instance._holder_pid = 123
        instance._holder_ip = "10.0.0.3"
        instance._target_ip = "10.0.0.2"
        instance._policy_marker = "qjs_egress_instance_1"
        instance._policy_handle = FakeNamespaceHandle()
        instance._image_ids = {"holder": "sha256:holder",
                               "solver": "sha256:solver"}
        instance._policy_ipv6_test_address = (
            container.egress_policy.IPV6_TEST_ADDRESS)
        order = trace if trace is not None else []

        class HostTcp:
            def __init__(self):
                self.port = 31000
                self.accepted = 1

            def start(self):
                return self

            def stop(self):
                pass

        class HostUdp:
            def __init__(self):
                self.port = 31001
                self.received = 1

            def start(self):
                return self

            def stop(self):
                pass

        counts = {
            ("qjs-ctf-sentinel-abc", "/tmp/qjs-sentinel.tcp"): [0, 1, 1],
            ("qjs-ctf-sentinel-abc", "/tmp/qjs-sentinel.udp"): [0, 1, 1],
            ("target-abc", "other"): [0, 1, 1],
        }
        positions = {}

        def read_count(name, path):
            key = ((name, path) if path else (name, "other"))
            sequence = counts[key]
            index = positions.get(key, 0)
            positions[key] = index + 1
            return sequence[min(index, len(sequence) - 1)]

        def attempt(name, role, errors):
            order.append(("attempt", role))
            return True

        def attempt_network(name, role, errors):
            order.append(("attempt-network", role))
            if role == "sentinel-network" and not sentinel_network_cleanup_ok:
                errors.append({
                    "role": role, "reference": name,
                    "error": "cleanup deliberately failed",
                })
                return False
            return True

        def inspect_config(name, expected):
            if name.startswith("qjs-ctf-strict-"):
                config = self.holder_security_config(
                    image_id=strict_probe_image_id)
                config.update(strict_config_overrides or {})
                return config
            if name.startswith("qjs-ctf-control-"):
                return self.holder_security_config(
                    image_id=control_image_id)
            return self.security_config()

        def inspect_image(name, purpose):
            order.append(("inspect-image", purpose))
            return sentinel_image_id

        def run_probe(name, mode, config, timeout):
            order.append(("probe", mode))
            payload = self.payload(mode)
            if mode == "strict":
                payload["capabilities"].update(
                    strict_capability_overrides or {})
            if probe_payload_mutator is not None:
                probe_payload_mutator(mode, payload)
            return payload

        def ensure_egress_active():
            order.append(("ensure-egress",))
            if ensure_error is not None:
                raise ensure_error

        def inspect_actual_solver_config(name, errors=None):
            order.append(("inspect-actual-solver-config", name))
            config = self.security_config(image_id=actual_solver_image_id)
            config.update(actual_solver_config_overrides or {})
            return config

        original_require = engine.require

        def require(argv, name, timeout=None, env=None):
            if "role=strict-probe" in " ".join(argv):
                order.append(("start-container", "strict"))
            return original_require(argv, name, timeout=timeout, env=env)

        instance._ensure_egress_active = ensure_egress_active
        instance._inspect_solver_config = inspect_actual_solver_config
        engine.require = require

        with mock.patch.object(container, "HostSentinel", HostTcp), \
                mock.patch.object(container, "HostUdpSentinel", HostUdp), \
                mock.patch.object(instance, "_start_target_other_listener"), \
                mock.patch.object(instance,
                                  "_validate_owned_internal_network"), \
                mock.patch.object(instance, "_network_gateway",
                                  return_value=("172.18.0.1", None)), \
                mock.patch.object(instance, "_container_ip",
                                  return_value="10.9.0.2"), \
                mock.patch.object(instance, "_wait_container_file"), \
                mock.patch.object(instance, "_read_container_count",
                                  side_effect=read_count), \
                mock.patch.object(instance, "_connect_holder_to_network",
                                  side_effect=lambda name:
                                  (order.append(("connect", name)),
                                   instance._holder_extra_networks.add(name))), \
                mock.patch.object(instance, "_configure_ipv6_test_address",
                                  side_effect=lambda: setattr(
                                      instance,
                                      "_ipv6_test_address_configured", True)), \
                mock.patch.object(instance, "_inspect_security_config",
                                  side_effect=inspect_config), \
                mock.patch.object(instance, "_inspect_container_image",
                                  side_effect=inspect_image), \
                mock.patch.object(instance, "_run_egress_probe",
                                  side_effect=run_probe), \
                mock.patch.object(
                    instance, "_activate_egress_policy",
                    side_effect=lambda **kwargs: (
                        order.append(("activate",
                                      sorted(instance._holder_extra_networks))),
                        setattr(instance, "_policy_installed", True),
                        setattr(instance, "_host_firewall_unchanged", True),
                        setattr(instance, "_host_firewall_before", "a"),
                        setattr(instance, "_host_firewall_after", "a"),
                        setattr(instance, "_host_marker_present_after", False),
                        setattr(instance, "_policy_install_results", {
                            "ipv4": {"returncode": 0},
                            "ipv6": {"returncode": 0}}))), \
                mock.patch.object(instance, "_readback_egress_policy",
                                  side_effect=[
                                      {"ok": True,
                                       "counters": self.counters(0)},
                                      {"ok": True,
                                       "counters": self.counters(1)}]), \
                mock.patch.object(
                    instance, "_container_namespaces",
                    side_effect=lambda name: (
                        {"pid_ns": "pid:[1]", "mnt_ns": "mnt:[1]"}
                        if name == instance.target_name else
                        {"pid_ns": "pid:[2]", "mnt_ns": "mnt:[2]"})), \
                mock.patch.object(instance, "_attempt_container",
                                  side_effect=attempt), \
                mock.patch.object(instance, "_attempt_network",
                                  side_effect=attempt_network), \
                mock.patch.object(instance, "_disconnect_holder_from_network",
                                  return_value=[]), \
                mock.patch.object(container.egress_policy,
                                  "namespace_matches_pid",
                                  return_value=True):
            result = instance._strict_boundary_check(30.0)
        return instance, result, order, engine

    def test_normal_run_reports_cleanup_after_finally(self):
        instance, result, order, engine = self.make_instance()
        self.assertEqual(result["status"], "passed", result["failures"])
        self.assertTrue(result["boundary_cleanup"]["ok"])
        self.assertNotIn("boundary_helper_cleanup_failed",
                         result["failures"])
        self.assertEqual(result["isolation_gate"]["status"], "passed")
        self.assertEqual(result["endpoint_only_egress"]["status"], "passed")
        self.assertTrue(result["checks"]["control_second_network_tcp_received"])
        self.assertTrue(result["checks"]["strict_second_network_tcp_rejected"])
        self.assertTrue(result["checks"][
            "control_probe_net_namespace_is_holder"])
        self.assertTrue(result["checks"][
            "strict_probe_net_namespace_is_holder"])
        self.assertTrue(result["checks"]["strict_probe_image_is_holder_image"])
        self.assertIn("connect", [item[0] for item in order])
        connect_index = next(index for index, item in enumerate(order)
                             if item[0] == "connect")
        activate_index = next(index for index, item in enumerate(order)
                              if item[0] == "activate")
        self.assertLess(connect_index, activate_index)
        activate_networks = next(item[1] for item in order
                                 if item[0] == "activate")
        self.assertIn("qjs-ctf-net2-abc", activate_networks)
        # Both executable probes use the trusted holder image.  The actual
        # solver image is configuration-inspected but never started.
        probe_calls = [call for call in engine.calls
                       if "role=strict-probe" in " ".join(call)
                       or "role=control-probe" in " ".join(call)]
        self.assertEqual(len(probe_calls), 2)
        control_calls = [call for call in probe_calls
                         if "role=control-probe" in " ".join(call)]
        strict_calls = [call for call in probe_calls
                        if "role=strict-probe" in " ".join(call)]
        self.assertEqual(len(control_calls), 1)
        self.assertEqual(len(strict_calls), 1)
        self.assertIn("sha256:holder", " ".join(control_calls[0]))
        self.assertNotIn("holder:img", " ".join(control_calls[0]))
        self.assertNotIn("solver:img", " ".join(control_calls[0]))
        self.assertNotIn("probe:img", " ".join(control_calls[0]))
        self.assertIn("sha256:holder", " ".join(strict_calls[0]))
        self.assertNotIn("holder:img", " ".join(strict_calls[0]))
        self.assertNotIn("solver:img", " ".join(strict_calls[0]))
        self.assertNotIn("probe:img", " ".join(strict_calls[0]))
        self.assertIn("container:holder-id", " ".join(control_calls[0]))
        self.assertIn("container:holder-id", " ".join(strict_calls[0]))
        self.assertTrue(result["checks"][
            "control_probe_image_is_holder_image"])
        self.assertTrue(result["checks"]["sentinel_image_is_holder_image"])
        self.assertTrue(result["checks"]["control_probe_pre_policy"])
        self.assertTrue(result["checks"]["sentinel_pre_policy"])
        self.assertTrue(result["checks"][
            "strict_probe_started_after_policy"])
        self.assertTrue(result["checks"][
            "actual_solver_container_never_started"])
        self.assertEqual(result["execution_order"]["trusted_image"],
                         "holder:img")
        self.assertTrue(result["execution_order"][
            "strict_probe_started_after_policy"])
        self.assertFalse(result["execution_order"][
            "actual_solver_container_started"])
        self.assertEqual(result["actual_solver_checks"]["status"], "passed")
        self.assertEqual(result["actual_solver_checks"]["execution"],
                         "not-started")
        self.assertEqual(result["trusted_runtime_evidence"]["image"],
                         "holder:img")
        self.assertFalse(result["filesystem_pid_separation"][
            "solver_image_executed"])

    def test_strict_probe_revalidates_live_egress_before_start(self):
        trace = []
        instance, result, order, engine = self.make_instance(trace=trace)
        self.assertEqual(result["status"], "passed", result["failures"])
        activate_index = trace.index(next(
            item for item in trace if item[0] == "activate"))
        config_index = trace.index(next(
            item for item in trace
            if item[0] == "inspect-actual-solver-config"))
        ensure_index = trace.index(("ensure-egress",))
        start_index = trace.index(("start-container", "strict"))
        strict_probe_index = trace.index(("probe", "strict"))
        self.assertLess(activate_index, config_index)
        self.assertLess(config_index, ensure_index)
        self.assertLess(ensure_index, start_index)
        self.assertLess(start_index, strict_probe_index)

    def test_failed_live_egress_revalidation_never_starts_strict_probe(self):
        trace = []
        with self.assertRaises(container.ContainerError) as caught:
            self.make_instance(
                ensure_error=container.ContainerError(
                    "target endpoint changed before strict probe"),
                trace=trace)
        self.assertIn("target endpoint changed", str(caught.exception))
        self.assertIn(("ensure-egress",), trace)
        self.assertNotIn(("start-container", "strict"), trace)
        self.assertNotIn(("probe", "strict"), trace)

    def test_setns_denial_is_required_for_full_isolation(self):
        instance, result, order, engine = self.make_instance(
            strict_capability_overrides={"setns_netns_denied": False})
        self.assertEqual(result["endpoint_only_egress"]["status"], "passed")
        self.assertEqual(result["status"], "partial")
        self.assertEqual(result["isolation_gate"]["status"], "pending")
        self.assertFalse(result["checks"][
            "trusted_probe_setns_netns_denied"])
        self.assertIn("trusted_probe_setns_netns_denied",
                      result["pending_isolation_checks"])

    def test_trusted_probe_user_must_match_configured_solver_user(self):
        instance, result, order, engine = self.make_instance(
            strict_config_overrides={"user": "10002:10002"})
        self.assertEqual(result["endpoint_only_egress"]["status"], "passed")
        self.assertEqual(result["status"], "partial")
        self.assertEqual(result["isolation_gate"]["status"], "pending")
        self.assertFalse(result["checks"][
            "trusted_probe_config_user_exact"])

    def test_shared_namespaces_or_mount_cannot_pass_full_isolation(self):
        cases = (
            ("pid_mode", "host",
             "actual_solver_config_pid_namespace_private"),
            ("ipc_mode", "host",
             "actual_solver_config_ipc_namespace_private"),
            ("mounts", [{"destination": "/unexpected", "rw": False,
                         "type": "bind"}],
             "actual_solver_config_no_mounts"),
            ("user", "10002:10002",
             "actual_solver_config_user_exact"),
        )
        for field, value, check in cases:
            with self.subTest(field=field):
                instance, result, order, engine = self.make_instance(
                    actual_solver_config_overrides={field: value})
                self.assertEqual(
                    result["endpoint_only_egress"]["status"], "passed")
                self.assertEqual(result["status"], "partial")
                self.assertEqual(
                    result["isolation_gate"]["status"], "pending")
                self.assertFalse(result["checks"][check])
                self.assertIn(check, result["pending_isolation_checks"])

    def test_pre_policy_helpers_never_use_untrusted_solver_or_probe_images(self):
        instance, result, order, engine = self.make_instance()
        self.assertEqual(result["status"], "passed", result["failures"])
        # Distinct solver and probe images are configured, and neither is
        # allowed before policy activation.
        self.assertEqual(instance.solver_image, "solver:img")
        self.assertEqual(instance.probe_image, "probe:img")
        helper_calls = [
            call for call in engine.calls
            if any(role in " ".join(call) for role in (
                "role=sentinel", "role=control-probe",
                "role=strict-probe"))]
        self.assertEqual(len(helper_calls), 3)
        for call in helper_calls:
            joined = " ".join(call)
            self.assertIn("sha256:holder", joined)
            self.assertNotIn("holder:img", joined)
            self.assertNotIn("solver:img", joined)
            self.assertNotIn("probe:img", joined)
        # The strict probe is also trusted-holder based; no run call may use
        # the actual solver or optional probe image.
        strict_index = next(
            index for index, call in enumerate(engine.calls)
            if "role=strict-probe" in " ".join(call))
        for role in ("role=sentinel", "role=control-probe"):
            helper_index = next(
                index for index, call in enumerate(engine.calls)
                if role in " ".join(call))
            self.assertLess(helper_index, strict_index)
        run_calls = [call for call in engine.calls
                     if len(call) > 1 and call[1] == "run"]
        self.assertFalse(any("solver:img" in call for call in run_calls))
        self.assertFalse(any("probe:img" in call for call in run_calls))
        # Ordering evidence: both controls happen before activation and the
        # trusted strict probe only after it.
        activate_index = next(index for index, item in enumerate(order)
                              if item[0] == "activate")
        control_probe_index = next(index for index, item in enumerate(order)
                                   if item[:2] == ("probe", "control"))
        strict_probe_index = next(index for index, item in enumerate(order)
                                  if item[:2] == ("probe", "strict"))
        self.assertLess(control_probe_index, activate_index)
        self.assertGreater(strict_probe_index, activate_index)

    def test_pre_policy_control_image_identity_mismatch_fails_closed(self):
        with self.assertRaises(container.ContainerError) as caught:
            self.make_instance(control_image_id="sha256:not-the-holder")
        self.assertIn("control probe", str(caught.exception))
        self.assertIn("trusted holder image", str(caught.exception))

    def test_pre_policy_sentinel_image_identity_mismatch_fails_closed(self):
        with self.assertRaises(container.ContainerError) as caught:
            self.make_instance(sentinel_image_id="sha256:not-the-holder")
        self.assertIn("second-network sentinel", str(caught.exception))
        self.assertIn("trusted holder image", str(caught.exception))

    def test_strict_probe_image_identity_mismatch_fails_closed(self):
        with self.assertRaises(container.ContainerError) as caught:
            self.make_instance(
                strict_probe_image_id="sha256:not-the-holder")
        self.assertIn("strict probe", str(caught.exception))
        self.assertIn("trusted holder image", str(caught.exception))

    def test_strict_udp_eperm_is_accepted_as_policy_rejection(self):
        instance, result, order, engine = self.make_instance()
        self.assertEqual(result["status"], "passed", result["failures"])
        for check in (
                "strict_default_probe_send",
                "strict_docker_dns_udp_rejected",
                "strict_loopback_ipv4_udp_rejected",
                "strict_loopback_ipv6_udp_rejected",
                "strict_ipv6_test_address_udp_rejected"):
            self.assertTrue(result["checks"][check], check)

    def test_strict_udp_send_error_that_is_not_eperm_fails(self):
        def mutator(mode, payload):
            if mode == "strict":
                payload["default_probe_send"] = {
                    "sent": False, "error": "TimeoutError", "errno": 110}

        instance, result, order, engine = self.make_instance(
            probe_payload_mutator=mutator)
        self.assertEqual(result["status"], "failed")
        self.assertFalse(result["checks"]["strict_default_probe_send"])
        self.assertIn("strict_default_probe_send", result["failures"])

    def test_strict_loop_udp_needs_eperm_or_zero_receive(self):
        def mutator(mode, payload):
            if mode == "strict":
                payload["loopback_ipv4"]["udp"] = {
                    "listener_available": True, "sent": False,
                    "received": 0, "send_error": None,
                    "listener_error": None}

        instance, result, order, engine = self.make_instance(
            probe_payload_mutator=mutator)
        self.assertEqual(result["status"], "failed")
        self.assertFalse(
            result["checks"]["strict_loopback_ipv4_udp_rejected"])

    def test_control_udp_must_be_live_before_policy(self):
        def mutator(mode, payload):
            if mode == "control":
                payload["loopback_ipv4"]["udp"] = {
                    "listener_available": True, "sent": False,
                    "received": 0, "send_error": "PermissionError",
                    "listener_error": None}

        instance, result, order, engine = self.make_instance(
            probe_payload_mutator=mutator)
        self.assertEqual(result["status"], "failed")
        self.assertFalse(
            result["checks"]["control_loopback_ipv4_udp"])

    def test_cleanup_failure_after_finally_fails_the_run(self):
        instance, result, order, engine = self.make_instance(
            sentinel_network_cleanup_ok=False)
        self.assertEqual(result["status"], "failed")
        self.assertIn("boundary_helper_cleanup_failed", result["failures"])
        self.assertFalse(result["boundary_cleanup"]["ok"])
        self.assertEqual(result["endpoint_only_egress"]["status"], "failed")
        self.assertEqual(result["isolation_gate"]["status"], "pending")
        self.assertEqual(result["boundary_cleanup"]["errors"][0]["error"],
                         "cleanup deliberately failed")

    def test_bad_actual_solver_image_identity_keeps_isolation_pending(self):
        instance, result, order, engine = self.make_instance(
            actual_solver_image_id="sha256:not-the-solver")
        self.assertEqual(result["endpoint_only_egress"]["status"], "passed")
        self.assertEqual(result["isolation_gate"]["status"], "pending")
        self.assertEqual(result["status"], "partial")
        self.assertFalse(result["checks"][
            "actual_solver_config_image_identity"])
        self.assertIn("actual_solver_config_image_identity",
                      result["pending_isolation_checks"])
        self.assertEqual(result["actual_solver_checks"]["status"], "failed")
        self.assertEqual(result["actual_solver_checks"]["execution"],
                         "not-started")

    def test_boundary_requires_deferred_policy(self):
        instance = InstanceFixture().instance(FakeEngine())
        self.addCleanup(shutil.rmtree, instance.secret_dir, True)
        instance.egress_mode = "strict"
        instance._holder_id = "holder-id"
        instance._target_ip = "10.0.0.2"
        instance._policy_installed = True
        instance._policy_handle = FakeNamespaceHandle()
        instance._policy_marker = "qjs_egress_instance_1"
        with self.assertRaises(container.ContainerError) as caught:
            instance._strict_boundary_check(5.0)
        self.assertIn("deferred", str(caught.exception))


class EgressProbeScriptTests(unittest.TestCase):
    def test_large_request_builds_real_source_over_20k(self):
        script = container.egress_probe_script()
        self.assertIn("large_length = 20000", script)
        self.assertIn('("a" * large_length)', script)
        self.assertIn("tcp_call(large_source", script)
        self.assertNotIn('"x" * 20000', script)
        source = "var large = '" + ("a" * 20000) + "'; large.length"
        self.assertGreater(len(source.encode("utf-8")), 20000)
        self.assertTrue(source.endswith("large.length"))

    def test_probe_does_not_embed_controller_values(self):
        script = container.egress_probe_script()
        self.assertNotIn("QJS_CTF_CONTROLLER_ENV_SENTINEL =", script)
        self.assertIn("controller_env_sentinel", script)
        self.assertIn("iptables-legacy", script)
        self.assertNotIn("nft", script)


class HostSentinelResourceTests(unittest.TestCase):
    def test_tcp_bind_failure_closes_socket(self):
        sock = mock.Mock()
        sock.bind.side_effect = PermissionError("bind denied")
        with mock.patch.object(container.socket, "socket", return_value=sock):
            with self.assertRaises(PermissionError):
                container.HostSentinel()
        sock.close.assert_called_once_with()

    def test_udp_bind_failure_closes_socket(self):
        sock = mock.Mock()
        sock.bind.side_effect = PermissionError("bind denied")
        with mock.patch.object(container.socket, "socket", return_value=sock):
            with self.assertRaises(PermissionError):
                container.HostUdpSentinel()
        sock.close.assert_called_once_with()


if __name__ == "__main__":
    unittest.main(verbosity=2)
