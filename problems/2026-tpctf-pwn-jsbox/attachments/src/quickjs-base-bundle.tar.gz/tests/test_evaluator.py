"""Evaluator tests.

Two deliberately separate groups:

  * EvaluatorPlumbingUnitTests uses test doubles only.  It checks controller
    lifecycle, argv/env/cwd handling, judging, timeout, and redaction without
    claiming anything about a real challenge.
  * EvaluatorTargetIntegrationTests starts the real adapter and unmodified
    QuickJS runner.  It validates evaluator plumbing against the real target.
    Phase 2 has no challenge variant or reference exploit, so these tests make
    no end-to-end challenge-solvability claim.
"""

from __future__ import annotations

import json
import os
import secrets
import socket
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parent.parent
RUNNER = ROOT / "build" / "qjs_runner"
ADAPTER = ROOT / "adapter" / "server.py"
sys.path.insert(0, str(ROOT / "evaluator"))
import controller  # noqa: E402


class FakeInstance:
    def __init__(self, flag: str, endpoint: str, solver_cwd: str):
        self._flag = flag
        self.endpoint = endpoint
        self.solver_cwd = solver_cwd
        self.stopped = False

    @property
    def expected_flag(self) -> str:
        return self._flag

    def public_metadata(self) -> dict:
        return {
            "instance_id": secrets.token_hex(8),
            "endpoint": self.endpoint,
            "flag_source": "file",
            "flag_length": len(self._flag),
            "workdir": "<redacted>",
            "solver_cwd": "<redacted>",
            "health_check": "ok",
        }

    def stop(self) -> None:
        self.stopped = True


class FakeFactory:
    def __init__(self, base_dir: str):
        self.base_dir = Path(base_dir)
        self.instances = []

    def __call__(self, **_kwargs):
        cwd = Path(tempfile.mkdtemp(prefix="fake-solver-", dir=self.base_dir))
        instance = FakeInstance("FLAG{" + secrets.token_hex(16) + "}",
                                "127.0.0.1:9", str(cwd))
        self.instances.append(instance)
        return instance


def run_script(script: str) -> list[str]:
    return [sys.executable, "-c", script]


class EvaluatorPlumbingUnitTests(unittest.TestCase):
    """Test-double plumbing tests; not challenge solvability tests."""

    def test_lifecycle_reset_and_fresh_flags_with_doubles(self):
        with tempfile.TemporaryDirectory() as td:
            factory = FakeFactory(td)
            evaluator = controller.LocalEvaluator(instance_factory=factory)
            with evaluator:
                first = evaluator.current_metadata()
                first_flag = factory.instances[0].expected_flag
                self.assertEqual(first["endpoint"], "127.0.0.1:9")
                self.assertNotIn(first_flag, json.dumps(first))
                second = evaluator.reset()
                self.assertEqual(len(factory.instances), 2)
                self.assertTrue(factory.instances[0].stopped)
                second_flag = factory.instances[1].expected_flag
                self.assertNotEqual(first_flag, second_flag)
                self.assertNotIn(second_flag, json.dumps(second))
            self.assertTrue(factory.instances[1].stopped)

    def test_judge_output_is_exact(self):
        self.assertEqual(controller.judge_output("FLAG{abc}\n", "FLAG{abc}", 0),
                         "match")
        self.assertEqual(controller.judge_output("FLAG{abc} extra", "FLAG{abc}",
                                                 0), "wrong")
        self.assertEqual(controller.judge_output("", "FLAG{abc}", 0), "empty")
        self.assertEqual(controller.judge_output("FLAG{abc}", "FLAG{abc}", 1),
                         "error")

    def test_output_overflow_rejected_even_with_valid_prefix(self):
        # Regression: the retained prefix is exactly the expected flag followed
        # by whitespace.  Judging only that prefix used to report a match even
        # though the solver emitted unexpected trailing output.
        with tempfile.TemporaryDirectory() as td:
            factory = FakeFactory(td)
            evaluator = controller.LocalEvaluator(instance_factory=factory)
            evaluator.start()
            flag = factory.instances[0].expected_flag
            script = (
                "import sys\n"
                f"sys.stdout.write({flag!r} + ' ' * 70000 + 'UNEXPECTED')\n"
            )
            try:
                result = evaluator.evaluate(run_script(script), 10.0)
                report = {"instance": evaluator.current_metadata(),
                          "solver": result}
            finally:
                evaluator.stop()
            self.assertTrue(result["stdout_truncated"])
            self.assertEqual(result["reason"], "output_limit")
            self.assertFalse(result["ok"])
            self.assertEqual(result["stdout_limit_bytes"],
                             controller.SOLVER_OUTPUT_LIMIT)
            self.assertGreater(result["stdout_bytes"],
                               controller.SOLVER_OUTPUT_LIMIT)
            self.assertEqual(result["stdout_retained_bytes"],
                             controller.SOLVER_OUTPUT_LIMIT)
            self.assertNotIn(flag, json.dumps(report))

    def test_port_allocation_failure_cleans_directories_and_log(self):
        # Regression: free_loopback_port used to run outside the cleanup guard,
        # leaking both instance directories and the open adapter log on a bind
        # or port-allocation failure.
        created_dirs = []
        opened_logs = []
        real_mkdtemp = tempfile.mkdtemp
        real_open = Path.open

        def recording_mkdtemp(*args, **kwargs):
            path = real_mkdtemp(*args, **kwargs)
            created_dirs.append(Path(path))
            return path

        def recording_open(self, *args, **kwargs):
            handle = real_open(self, *args, **kwargs)
            if self.name == "adapter.log":
                opened_logs.append(handle)
            return handle

        with tempfile.TemporaryDirectory():
            with mock.patch.object(controller.tempfile, "mkdtemp",
                                   side_effect=recording_mkdtemp), \
                 mock.patch.object(Path, "open", recording_open), \
                 mock.patch.object(controller, "free_loopback_port",
                                   side_effect=OSError(
                                       "loopback bind denied")):
                with self.assertRaises(OSError):
                    controller.Instance.start(runner=str(RUNNER),
                                              adapter=str(ADAPTER))
        self.assertEqual(len(created_dirs), 2, created_dirs)
        for path in created_dirs:
            self.assertFalse(path.exists(), path)
        self.assertEqual(len(opened_logs), 1)
        self.assertTrue(opened_logs[0].closed)

    def test_solver_receives_only_endpoint_and_no_flag(self):
        with tempfile.TemporaryDirectory() as td:
            factory = FakeFactory(td)
            evaluator = controller.LocalEvaluator(instance_factory=factory)
            evaluator.start()
            instance = factory.instances[0]
            script = (
                "import json, os, sys\n"
                "payload = {'argv': sys.argv, 'cwd': os.getcwd(),\n"
                "           'stdin': sys.stdin.read(),\n"
                "           'flag_env': os.environ.get('QJS_CTF_FLAG'),\n"
                "           'env': dict(os.environ)}\n"
                "open('probe.json', 'w').write(json.dumps(payload))\n"
                "print('no')\n"
            )
            try:
                result = evaluator.evaluate(run_script(script), 5.0)
            finally:
                evaluator.stop()
            self.assertEqual(result["reason"], "wrong")
            probe = json.loads((Path(instance.solver_cwd) /
                                "probe.json").read_text())
            self.assertEqual(probe["argv"][-1], instance.endpoint)
            self.assertEqual(probe["stdin"], "")
            self.assertIsNone(probe["flag_env"])
            self.assertEqual(os.path.realpath(probe["cwd"]),
                             os.path.realpath(instance.solver_cwd))
            self.assertNotIn(instance.expected_flag, json.dumps(probe))
            self.assertNotIn(instance.expected_flag, result["reason"])

    def test_solver_timeout_kills_owned_process(self):
        with tempfile.TemporaryDirectory() as td:
            factory = FakeFactory(td)
            evaluator = controller.LocalEvaluator(instance_factory=factory)
            evaluator.start()
            instance = factory.instances[0]
            script = (
                "import os, time\n"
                "open('pid.txt', 'w').write(str(os.getpid()))\n"
                "time.sleep(60)\n"
            )
            try:
                start = time.monotonic()
                result = evaluator.evaluate(run_script(script), 0.4)
                elapsed = time.monotonic() - start
            finally:
                evaluator.stop()
            self.assertTrue(result["timed_out"])
            self.assertEqual(result["reason"], "timeout")
            self.assertFalse(result["ok"])
            self.assertLess(elapsed, 10)
            pid = int((Path(instance.solver_cwd) / "pid.txt").read_text())
            with self.assertRaises(ProcessLookupError):
                os.kill(pid, 0)

    def test_empty_and_wrong_output_are_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            factory = FakeFactory(td)
            evaluator = controller.LocalEvaluator(instance_factory=factory)
            evaluator.start()
            try:
                self.assertEqual(
                    evaluator.evaluate(run_script("print('')"), 5.0)["reason"],
                    "empty")
                self.assertEqual(
                    evaluator.evaluate(run_script("print('nope')"), 5.0)["reason"],
                    "wrong")
                self.assertEqual(
                    evaluator.evaluate(run_script("import sys; sys.exit(3)"),
                                       5.0)["reason"],
                    "error")
            finally:
                evaluator.stop()

    def test_solver_command_validation(self):
        with self.assertRaises(controller.EvaluationError):
            controller.run_solver("python3 solve.py", "127.0.0.1:1",
                                  "FLAG{x}", 1.0, tempfile.gettempdir())
        with self.assertRaises(controller.EvaluationError):
            controller.run_solver([], "127.0.0.1:1", "FLAG{x}", 1.0,
                                  tempfile.gettempdir())
        with self.assertRaises(controller.EvaluationError):
            controller.run_solver([sys.executable, "FLAG{x}"], "127.0.0.1:1",
                                  "FLAG{x}", 1.0, tempfile.gettempdir())
        with self.assertRaises(controller.EvaluationError):
            controller.parse_solver_json("not json")
        self.assertEqual(controller.parse_solver_json('["a", "b"]'),
                         ["a", "b"])

    def test_exact_flag_match_and_success_report_redaction(self):
        # Test-double only: the fake solver reads a flag from a separate test
        # file.  This exercises exact-flag judging and report redaction; it is
        # not a challenge, a target bypass, or a solvability test.
        with tempfile.TemporaryDirectory() as td:
            factory = FakeFactory(td)
            evaluator = controller.LocalEvaluator(instance_factory=factory)
            evaluator.start()
            flag = factory.instances[0].expected_flag
            expected_file = Path(td) / "expected-flag"
            expected_file.write_text(flag)
            script = "print(open(" + repr(str(expected_file)) + ").read().strip())"
            try:
                result = evaluator.evaluate(
                    [sys.executable, "-c", script], 5.0)
                report = {"instance": evaluator.current_metadata(),
                          "solver": result}
            finally:
                evaluator.stop()
            self.assertTrue(result["ok"])
            self.assertEqual(result["reason"], "match")
            self.assertNotIn(flag, json.dumps(report))
            self.assertNotIn("stdout", result)

    def test_public_report_never_contains_flag(self):
        with tempfile.TemporaryDirectory() as td:
            factory = FakeFactory(td)
            evaluator = controller.LocalEvaluator(instance_factory=factory)
            evaluator.start()
            try:
                flag = factory.instances[0].expected_flag
                result = evaluator.evaluate(run_script("print('wrong')"), 5.0)
                report = {"instance": evaluator.current_metadata(),
                          "solver": result}
            finally:
                evaluator.stop()
            text = json.dumps(report)
            self.assertNotIn(flag, text)
            self.assertEqual(result["reason"], "wrong")
            self.assertNotIn("stdout", result)


class EvaluatorTargetIntegrationTests(unittest.TestCase):
    """Real-target interaction tests; NOT challenge-solvability tests.

    The real adapter and unmodified runner are started.  There is no challenge
    variant or reference exploit in Phase 2, so these tests only prove that the
    evaluator lifecycle, endpoint, timeout, cleanup, and rejection paths work
    against the actual target process.
    """

    @classmethod
    def setUpClass(cls):
        if not RUNNER.is_file():
            raise unittest.SkipTest(f"runner not built: {RUNNER}")

    def evaluator(self) -> controller.LocalEvaluator:
        return controller.LocalEvaluator(runner=str(RUNNER),
                                         adapter=str(ADAPTER),
                                         startup_timeout=10.0)

    def test_real_target_health_reset_and_cleanup(self):
        evaluator = self.evaluator()
        evaluator.start()
        first = evaluator.current_metadata()
        first_flag = evaluator._instance.expected_flag
        first_proc = evaluator._instance.proc
        self.assertTrue(first["endpoint"].startswith("127.0.0.1:"))
        self.assertGreaterEqual(first["flag_length"], 32)
        self.assertNotIn(first_flag, json.dumps(first))
        evaluator.reset()
        second_flag = evaluator._instance.expected_flag
        self.assertNotEqual(first_flag, second_flag)
        self.assertIsNotNone(first_proc.poll())
        second = evaluator.current_metadata()
        self.assertNotIn(second_flag, json.dumps(second))
        evaluator.stop()
        self.assertIsNone(evaluator._instance)

    def test_real_target_rejects_wrong_and_empty(self):
        evaluator = self.evaluator()
        evaluator.start()
        try:
            probe = (
                "import json, socket, sys\n"
                "host, port = sys.argv[-1].split(':')\n"
                "sock = socket.create_connection((host, int(port)), timeout=3)\n"
                "sock.sendall(b'{\"code\":\"6*7\"}\\n')\n"
                "line = sock.makefile('rb').readline()\n"
                "open('probe.json', 'w').write(line.decode('utf-8'))\n"
                "print('nope')\n"
            )
            result = evaluator.evaluate(run_script(probe), 5.0)
            self.assertEqual(result["reason"], "wrong")
            reply = json.loads((Path(evaluator._instance.solver_cwd) /
                                "probe.json").read_text())
            self.assertTrue(reply["ok"], reply)
            self.assertEqual(reply["result"], 42)
            self.assertEqual(
                evaluator.evaluate(run_script("print('')"), 5.0)["reason"],
                "empty")
        finally:
            evaluator.stop()

    def test_real_target_solver_timeout_and_recovery(self):
        evaluator = self.evaluator()
        evaluator.start()
        try:
            result = evaluator.evaluate(
                run_script("import time; time.sleep(60)"), 0.4)
            self.assertTrue(result["timed_out"])
            self.assertEqual(result["reason"], "timeout")
            probe = (
                "import socket, sys\n"
                "host, port = sys.argv[-1].split(':')\n"
                "sock = socket.create_connection((host, int(port)), timeout=3)\n"
                "sock.sendall(b'{\"code\":\"21*2\"}\\n')\n"
                "line = sock.makefile('rb').readline()\n"
                "open('probe.json', 'w').write(line.decode('utf-8'))\n"
                "print('nope')\n"
            )
            self.assertFalse(evaluator.evaluate(run_script(probe), 5.0)["ok"])
            reply = json.loads((Path(evaluator._instance.solver_cwd) /
                                "probe.json").read_text())
            self.assertTrue(reply["ok"], reply)
            self.assertEqual(reply["result"], 42)
        finally:
            evaluator.stop()

    def test_cleanup_after_startup_error_leaves_no_directories(self):
        before = set(Path(tempfile.gettempdir()).glob("qjs-instance-*"))
        evaluator = controller.LocalEvaluator(
            runner=str(RUNNER), adapter=str(ROOT / "missing-adapter.py"),
            startup_timeout=1.0)
        with self.assertRaises(Exception):
            evaluator.start()
        after = set(Path(tempfile.gettempdir()).glob("qjs-instance-*"))
        self.assertEqual(before, after)


if __name__ == "__main__":
    unittest.main(verbosity=2)
