"""Targeted harness regressions for scripts/verify_linux.py."""

from __future__ import annotations

import importlib.util
import tempfile
import unittest
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parent.parent
SPEC = importlib.util.spec_from_file_location(
    "verify_linux", ROOT / "scripts" / "verify_linux.py")
verify_linux = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(verify_linux)

DOCKER_SPEC = importlib.util.spec_from_file_location(
    "verify_docker", ROOT / "scripts" / "verify_docker.py")
verify_docker = importlib.util.module_from_spec(DOCKER_SPEC)
DOCKER_SPEC.loader.exec_module(verify_docker)


class CleanBuildHarnessTests(unittest.TestCase):
    def test_clean_runs_before_build_with_requested_compiler(self):
        calls = []

        def fake_run_stage(name, argv, env=None, report=None):
            calls.append((name, list(argv), env))
            return {}

        with mock.patch.object(verify_linux, "run_stage", fake_run_stage):
            verify_linux.run_clean_build(
                "/usr/bin/make", 4, {"CC": "/usr/bin/clang"},
                {"stages": []})
        self.assertEqual([call[0] for call in calls], ["clean", "build"])
        self.assertEqual(calls[0][1], ["/usr/bin/make", "clean"])
        self.assertEqual(calls[1][1],
                         ["/usr/bin/make", "-j4", "runner"])
        self.assertEqual(calls[0][2], {"CC": "/usr/bin/clang"})
        self.assertEqual(calls[1][2], {"CC": "/usr/bin/clang"})


class TestedArtifactTests(unittest.TestCase):
    def test_rebuilt_binary_is_replaced_by_tested_artifact(self):
        with tempfile.TemporaryDirectory() as td:
            binary = Path(td) / "qjs_runner"
            binary.write_bytes(b"tested-binary")
            guard = verify_linux.TestedArtifact(binary)
            preserved_dir = guard._tempdir
            try:
                binary.write_bytes(b"rebuilt-during-timing")
                record = guard.ensure_final()
                self.assertTrue(record["restored_tested_artifact"])
                self.assertNotEqual(record["tested_runner_sha256"],
                                    record["post_timing_runner_sha256"])
                self.assertEqual(record["tested_runner_sha256"],
                                 record["final_runner_sha256"])
                self.assertEqual(binary.read_bytes(), b"tested-binary")
            finally:
                guard.close()
            self.assertFalse(preserved_dir.exists())

    def test_unchanged_binary_is_not_restored(self):
        with tempfile.TemporaryDirectory() as td:
            binary = Path(td) / "qjs_runner"
            binary.write_bytes(b"stable-binary")
            guard = verify_linux.TestedArtifact(binary)
            try:
                record = guard.ensure_final()
                self.assertFalse(record["restored_tested_artifact"])
                self.assertEqual(record["tested_runner_sha256"],
                                 record["post_timing_runner_sha256"])
                self.assertEqual(record["tested_runner_sha256"],
                                 record["final_runner_sha256"])
                self.assertEqual(binary.read_bytes(), b"stable-binary")
            finally:
                guard.close()


class DockerPlatformTests(unittest.TestCase):
    def test_non_amd64_platform_is_rejected_without_override(self):
        self.assertIsNone(verify_docker.platform_error("linux/amd64", False))
        problem = verify_docker.platform_error("linux/arm64", False)
        self.assertIsNotNone(problem)
        self.assertIn("linux/amd64", problem)

    def test_explicit_override_allows_other_platform(self):
        self.assertIsNone(verify_docker.platform_error("linux/arm64", True))

    def test_cpu_quota_must_be_positive(self):
        self.assertEqual(verify_docker.positive_cpus("2.5"), 2.5)
        with self.assertRaises(Exception):
            verify_docker.positive_cpus("0")
        with self.assertRaises(Exception):
            verify_docker.positive_cpus("invalid")


if __name__ == "__main__":
    unittest.main(verbosity=2)
