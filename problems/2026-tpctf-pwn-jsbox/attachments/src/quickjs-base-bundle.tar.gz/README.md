# QuickJS CTF evaluation baseline (Phase 2)

A small, reviewable baseline for a future QuickJS-based CTF environment:

- pinned, unmodified upstream QuickJS **2026-06-04**, vendored with its license;
- a minimal C embedding that accepts **source only** and exposes no std/os,
  module loader, filesystem, subprocess, environment, or bytecode APIs;
- a standard-library Python TCP adapter with one persistent worker per
  connection, bounded framing, resource limits, and an external timeout;
- integration tests, a reproducible build manifest, and repeated native build
  timings with raw samples;
- a multi-stage Ubuntu 24.04 Dockerfile with a verification stage for the Linux
  x86-64 target;
- file-based runtime flag injection as the preferred deployment interface, with
  environment mode retained for local compatibility;
- a one-command Linux verification entrypoint and a Docker verification script;
- a local evaluation controller with fresh flags, loopback endpoints, health
  checks, process cleanup, and redacted reports.

This is a baseline and local evaluation harness, not a production sandbox. See
[Security notes and non-goals](#security-notes-and-non-goals) and the
[acceptance matrix](docs/acceptance.md).

## Status and validation scope

| Check | Status |
| --- | --- |
| Native build on macOS arm64 | Executed |
| Native test suite (238 tests incl. strict legacy-egress and UDP-rejection regressions) | **Passed: 238/238**; current revision's Docker verification-image re-run pending |
| Repeated native build timings | Executed, see `docs/build-timings.md` |
| File-based flag injection and evaluator lifecycle | Executed on this host |
| Docker verification image build/run | **Passed on first strict-egress attempt** for the then-current 215-test revision; current 238-test revision pending |
| Docker runtime image build/run | **Passed**; `reports/phase3a-runtime-real.json` |
| Container-separated evaluator | Historical real negative checks passed; first strict legacy-iptables run failed closed during policy install; **fresh formal isolation run pending** |
| Ubuntu 24.04 / x86-64 execution | **Passed: 65 tests, non-root, 2 CPUs / 2 GiB**; `reports/linux-validation.json` |
| Two challenge variants with reference solutions | **Pending** |
| Real two-hour authoring experiment | **Pending** |

The baseline has been validated on **Darwin 25.4.0 arm64 with Apple clang
21.0.0** and in a **DSec Ubuntu 24.04.3 x86-64 container with GCC 13.3.0**.
The Linux run used an unprivileged user, no external network during tests,
and a 2 CPU / 2 GiB quota. Three-run medians were 20.625 s for a clean build
and 19.117 s for a core-touch build. See [Linux evidence](docs/linux-validation.md).
The Dockerfile-produced runtime and verification images were previously built
and tested in temporary Docker-capable DSec UVMs. The first frozen
strict-egress attempt reran the then-current non-root 215-test suite
successfully, but the boundary itself failed closed during policy installation
before any untrusted solver image started. Independent review then added
fail-closed, trust-boundary, configuration-allowlist and diagnostic regressions,
bringing the current native suite to 238/238. That exact revision has not yet
been rerun in the verification image. Wrong,
empty, overflowing and timed-out solvers were rejected with successful cleanup
in the earlier runtime run.
The earlier legacy boundary probe reached the host gateway. The later strict
attempt recovered a distinct holder namespace and completed scoped cleanup,
but did not install the policy, so the formal isolation gate remains pending.
The observed Linux platform does not support
nftables/Netlink; strict egress is now implemented with the legacy
`iptables-legacy-restore`/`iptables-legacy-save` and
`ip6tables-legacy-restore`/`ip6tables-legacy-save` binaries inside a held
holder network namespace. The native suite covers this implementation and now
retains bounded, redacted per-family install/readback diagnostics. The
real-engine boundary must be rerun on a fresh frozen revision; no endpoint-only
isolation outcome is claimed from native tests. Historical failures remain at
`reports/phase3a-boundary-real.json` and
`reports/phase3a-egress3-boundary-first.json`.
The install cause remains unknown: unavailable `xt_comment` is only a
hypothesis until the exact IPv4 and IPv6 restore batches are captured with
`--test`. Uploading the revised source and creating a new temporary UVM require
explicit authorization in the current chat.

The proposed next steps are [the Topic draft](docs/topic-draft.zh-CN.md) and
[the Phase 3 acceptance plan](docs/phase3-plan.md). Both remain proposals;
challenge variants and the two-hour authoring experiment are pending.

## Repository layout

```text
adapter/server.py             bounded TCP adapter, flag file/env injection
runner/qjs_runner.c           minimal QuickJS embedding and worker protocol
evaluator/controller.py       local instance lifecycle and solver judging
tests/test_integration.py     adapter, flag-file, and worker lifecycle tests
tests/test_evaluator.py       plumbing doubles + real-target evaluator tests
scripts/verify_pin.py         archive hash/version/license verifier
scripts/bench_build.py        repeated cold/no-op/core-touch timing
scripts/verify_linux.py       Linux pin/clean/build/tests/timings entrypoint
scripts/verify_docker.py      Docker target-image verification
scripts/verify_runtime.py     real runtime-image build/run verifier
evaluator/container_controller.py  separate target/solver containers
tests/test_verify_runtime.py  runtime verifier command/redaction tests
tests/test_container_controller.py  container command/judging/cleanup tests
docs/phase3a-runtime-and-isolation.md  Phase 3A commands and limitations
docs/acceptance.md            requirement-to-evidence matrix
docs/deployment.md            deployment and verification commands
docs/evaluation.md            local evaluator and solver contract
third_party/quickjs/
  quickjs-2026-06-04.tar.xz   vendored upstream archive
  SHA256SUMS                  pinned archive checksum
  PROVENANCE.md               provenance and pin policy
  src/                        extracted, unmodified upstream source + LICENSE
build-manifest.json           pinned inputs, build flags, limits, validation scope
Dockerfile                    Ubuntu 24.04 multi-stage image (target: x86-64)
docs/flag-injection.md        file/env flag injection boundary
docs/build-timings.md         measured native build timings
```

## Pinned upstream source

- Release: **2026-06-04**
- URL: <https://bellard.org/quickjs/quickjs-2026-06-04.tar.xz>
- Archive SHA-256:
  `b376e839b322978313d929fd20663b11ba58b75df5a46c126dd19ea2fa70ad2a`
- Archive size: **621500 bytes**
- License: upstream QuickJS MIT-style license, retained verbatim at
  `third_party/quickjs/src/LICENSE`
- No upstream patches are applied.

Verify the pin at any time:

```sh
python3 scripts/verify_pin.py
```

The archive is vendored, so builds do not fetch a moving branch. See
`third_party/quickjs/PROVENANCE.md` for the exact retrieval and extraction
record.

## Build (native)

Requirements: a C compiler, GNU make, Python 3.10+, and `xz`/`tar` only if you
re-extract the archive. The build links only these upstream files:
`quickjs.c`, `dtoa.c`, `libregexp.c`, `libunicode.c`, and `cutils.c`.
`quickjs-libc.c`, the `qjs` CLI, and `qjsc` are deliberately excluded.

```sh
make clean
make -j1 runner
```

Other targets:

```sh
make verify-pin    # archive and extracted-source pin checks
make check         # verify pin, then run the full test suite
make bench         # repeated cold/no-op/core-touch timing
make print-flags   # actual make variables used for the build
make verify-linux  # Linux build/pin/tests/timings entrypoint
make verify-docker UBUNTU_IMAGE=ubuntu:24.04@sha256:<digest>
make docker-build          # runtime image (explicit --target runtime)
make docker-build-verify   # validation image (explicit --target verify)
```

The Docker target is x86-64: both build targets pass `--platform
linux/amd64`. `docker-build` produces the non-root runtime service; a plain
`docker build .` also selects the runtime stage because it is last in the
Dockerfile. Verification is always an explicit `--target verify` selection.

Compiler flags are explicit in the `Makefile` (`-O2 -g -std=gnu11 -fwrapv
-funsigned-char ...`). LTO is not used. Each upstream C file is a separate
object with `-MMD` dependencies, so touching `quickjs.c` recompiles
`quickjs.o` and relinks.

### macOS note

On this host, `/usr/bin/make` was initially unable to create an `xcrun` cache
file inside the inherited sandbox. If `make` fails for that reason, invoke the
toolchain make directly:

```sh
/Library/Developer/CommandLineTools/usr/bin/make -j1 runner
/Library/Developer/CommandLineTools/usr/bin/make check
```

`scripts/bench_build.py` probes for a working make and falls back to that path,
or honours `MAKE=/path/to/make`.

## Run

The adapter binds to loopback by default:

```sh
python3 adapter/server.py \
  --host 127.0.0.1 \
  --port 8000 \
  --runner ./build/qjs_runner
```

Options:

| Option | Default | Meaning |
| --- | --- | --- |
| `--host` | `127.0.0.1` | IPv4 bind address. Non-loopback is an explicit override and logs a warning. |
| `--port` | `8000` | TCP port. |
| `--runner` | `./build/qjs_runner` | Worker binary. |
| `--timeout` | `2.0` | Per-evaluation wall-clock seconds, maximum 30. |
| `--flag-env` | `QJS_CTF_FLAG` | Adapter-side environment variable used for the instance flag; empty disables environment mode. |
| `--flag-file` | none | Read the instance flag from a platform-supplied file. Preferred deployment mode. |

One TCP connection gets one child worker and one persistent JS runtime. State
persists across evaluations on that connection. Separate connections have
separate workers and runtimes. Closing the connection shuts the worker down.

### Client example

Requests are JSON Lines with a `code` string. Replies are one JSON object per
line.

```python
import json
import socket

sock = socket.create_connection(("127.0.0.1", 8000))
reader = sock.makefile("rb")

def evaluate(source):
    sock.sendall((json.dumps({"code": source}) + "\n").encode())
    return json.loads(reader.readline())

print(evaluate("globalThis.n = 41; n"))   # {'ok': True, 'result': 41}
print(evaluate("n + 1"))                  # {'ok': True, 'result': 42}
print(evaluate('throw new TypeError("x")'))
# {'ok': False, 'error': {'name': 'TypeError', 'message': 'x', 'stack': ...}}
print(evaluate("n + 2"))                  # {'ok': True, 'result': 43}
print(evaluate('"z".repeat(2 * 1024 * 1024)'))
# {'ok': False, 'error': {'name': 'OutputLimitError', ...}}
print(evaluate("n + 3"))                  # {'ok': True, 'result': 44}

sock.close()
```

A JavaScript exception is a normal, non-fatal reply. The runtime remains
usable. A timeout is fatal for that connection: the adapter sends a
`TimeoutError` reply with `"fatal": true`, kills the worker process group, and
closes the connection.

### Result representation

The runner serializes the script completion value into JSON. Ordinary numbers,
strings, booleans, null, arrays, and objects map directly. Values JSON cannot
represent use a tagged object so they are not silently lost:

| JavaScript value | Serialized form |
| --- | --- |
| `undefined` | `{"$type":"undefined"}` |
| function | `{"$type":"function","name":"..."}` |
| BigInt | `{"$type":"bigint","value":"..."}` |
| symbol | `{"$type":"symbol","value":"..."}` |
| TypedArray | `{"$type":"Uint8Array","length":3,"data":[...]}` |
| `Date` | `{"$type":"Date","value":"1970-01-01T00:00:00.000Z"}` |
| NaN / Infinity | `{"$type":"number","value":"NaN"}` / `"Infinity"` |
| cycle | `{"$type":"cycle"}` |
| depth over 12 | `{"$type":"depth-limit"}` |

Error replies are `{"name", "message", "stack"}`. Stack text is truncated to
8192 characters. This is a JSON-safe inspection representation, not a
structured clone.

## Limits and failure behavior

Constants are mirrored in `runner/qjs_runner.c` and `adapter/server.py`; see
`build-manifest.json`.

| Limit | Value | Behavior |
| --- | --- | --- |
| Source | 65536 UTF-8 bytes | Request rejected; connection remains usable. |
| Serialized output | 1048576 bytes | `OutputLimitError`; runtime remains usable. |
| Runtime memory | 64 MiB | QuickJS out-of-memory exception; runtime is generally recoverable. |
| Runtime stack | 1 MiB | Stack-overflow exception; runtime remains usable. |
| TCP request line | 1048576 bytes | Fatal protocol error; connection closed. |
| TCP reply | 2097152 bytes | Fatal adapter error. |
| Connections | 64 | Excess connection receives `BusyError` and closes. |
| Idle request read | 60 s | Connection is closed. |
| Evaluation wall clock | 2 s default | Covers source write and response read; worker process group is SIGKILLed; connection closes. |

The TCP request line limit is larger than the source limit so a rejected
oversized source can be reported without desynchronizing the line protocol.
Oversized request lines close the connection because the adapter cannot safely
resynchronize an unbounded stream.

There is no host job queue. Promise jobs and top-level `await` are not driven,
so asynchronous callbacks that require a microtask checkpoint will not run.
Synchronous Promise construction still works. `Atomics.wait`-style blocking is
bounded only by the external timeout.

## Runtime instance flag

The preferred interface is a read-only file mounted by the platform:

```sh
python3 adapter/server.py \
  --host 127.0.0.1 --port 8000 --runner ./build/qjs_runner \
  --flag-file /run/secrets/qjs_ctf_flag
```

Environment mode remains available for local compatibility
(`QJS_CTF_FLAG=... python3 adapter/server.py`, with `--flag-env NAME` for a
different source name). Supplying a file and a non-empty environment flag at
the same time is a startup error.

The adapter reads the value once, passes it only into each worker's minimal OS
environment under the fixed `QJS_CTF_FLAG` name, and logs only the source and
presence. The runner reports presence/absence and the adapter fails closed if
the handshake does not match. JavaScript cannot read it: there is no
environment, file, process, std/os, or module-loader API. Missing, unreadable,
empty, oversized, or invalid files fail visibly without logging contents. The
value is not in the repository, Dockerfile, image layers, or script source.

The flag is shared by all connections of one adapter process. Use one adapter
or evaluator instance per challenge instance. See `docs/flag-injection.md`.

## Tests

```sh
make check
```

The current suite contains 238 tests and uses a real adapter subprocess and
real worker processes. The historical Phase 2 baseline contained 65 tests and
the first Phase 3A Docker verification image contained 150; those historical
counts are preserved as evidence rather than presented as the current suite.
The current suite covers:

- arithmetic, JSON parsing/serialization, objects, arrays, TypedArrays,
  callbacks, BigInt, Date, NaN/Infinity, cycles, and source-length boundaries;
- persistent state on one connection and isolation between connections;
- distinct worker processes and isolated runtimes;
- JavaScript exceptions, syntax errors, thrown primitives, stack overflow, and
  recovery;
- absence of `std`, `os`, `require`, `process`, module loaders, file APIs, and
  other host globals;
- file-based and environment-based flag injection, conflicting modes, missing/
  unreadable/empty files, the OS-level handshake, and invisibility to JS;
- oversized source (recoverable), oversized output (recoverable), oversized
  request line (fatal), and memory limit;
- external timeout: SIGKILL of the worker, connection close, and a healthy
  adapter afterwards;
- non-fatal protocol errors for malformed JSON, missing `code`, invalid
  UTF-8, and a lone-surrogate result that requires ASCII escaping.

A regression found during development: the runner initially passed a
non-NUL-terminated source buffer to `JS_Eval`, and certain source lengths made
the lexer read one byte past the input. The runner now allocates a NUL sentinel
and the suite includes a source-length boundary test.

Phase 2 audit fixes: the adapter now forwards a non-default `--flag-env` value
to workers under the fixed reserved worker variable (previously the handshake
failed closed), and shutdown kills a worker that races with `server_close`
instead of leaving it unowned.

## Local evaluation controller

`evaluator/controller.py` starts one target instance per evaluation with a fresh
random flag, an isolated working directory, and a random loopback endpoint. It
health-checks the target, runs an explicit operator solver argv with the
endpoint appended, enforces a strict wall-clock timeout, and cleans up owned
processes on stop/reset/timeout/error.

```sh
python3 evaluator/controller.py \
  --solver-json '["python3", "/opt/challenge/solve.py"]' \
  --timeout 30 --report build/evaluation-report.json
```

The expected flag is never placed in solver argv/environment/working directory/
stdin or in feedback. Public reports contain redacted metadata and no solver
output. There is no built-in solver. See `docs/evaluation.md` for the contract,
test separation, and same-user limitations.

## Build timings

```sh
python3 scripts/bench_build.py --runs 3 --jobs 1
```

Each run verifies the pinned archive, cleans, times a cold build, times a no-op
build, touches only `third_party/quickjs/src/quickjs.c`, and times the
recompile plus relink. Raw samples, median, maximum, host OS/distribution/
architecture, observable cgroup CPU quota, compiler version, make jobs, and
actual make variables are recorded. Original source timestamps are restored in
a `finally` block. Download and extraction are not counted. Results are written
to `docs/build-timings.md` and `build/build-timings.json`.

These are compile/link measurements only. They are **not** evidence that a
two-hour challenge-authoring workflow is achievable. That experiment remains
pending in `docs/acceptance.md`.

## Linux and Docker verification

Inside an existing Ubuntu 24.04 x86-64 container or host:

```sh
python3 scripts/verify_linux.py --runs 3 --jobs 1
```

This runs `source_pin`, `clean`, `build`, `tests`, and `timings`, fails
visibly on any stage, and writes `reports/verify-linux-report.json`. The clean
stage prevents stale objects compiled with another compiler or flags. The
runner is hashed after the clean build; if the timing stage rebuilds a
different binary, the exactly tested binary is restored as the final artifact
and both hashes are recorded.

With a container engine available, the operator supplies a pinned base image:

```sh
python3 scripts/verify_docker.py \
  --image ubuntu:24.04@sha256:<operator-supplied-digest> \
  --require-digest --platform linux/amd64 \
  --cpus 2 --memory 2g --runs 3
```

The script explicitly builds the `verify` stage with `--platform linux/amd64`,
records the requested platform/CPU/memory quota, the engine-applied
`HostConfig`, the observed in-container cgroup CPU quota, and actual
image/toolchain/package metadata. It enforces `amd64` and requires a clean
x86_64 in-container report with no target mismatches. It runs the Linux
verification entrypoint with `--network none`. Without an engine it writes
`status: skipped` and exits 2. It does not invent a digest or claim a run.

The report separates the **verification image** from the **runtime image**. A
passing verify run validates only the validation image. The runtime image is
recorded as pending and is not built, run, or smoke-tested by the verifier.

The Dockerfile is multi-stage; the runtime stage is the final stage. It accepts
`BASE_IMAGE` (default `ubuntu:24.04`), keeps only Python 3, the runner, the
adapter, and the upstream license, runs as a non-root user, and never bakes in
a flag. Build it with `--target runtime` (or `make docker-build`). Build the
validation image with `--target verify` (or `make docker-build-verify`), not
with a plain `docker build`. `SKIP_APT=1` supports a pre-provisioned base image
for offline image builds.

No container engine is available on the local implementation host. The
verification and runtime images were nevertheless built and exercised on
temporary Docker-capable DSec UVMs; the runtime result is preserved at
`reports/phase3a-runtime-real.json`. A verification-image pass alone is still
not evidence that the runtime image works, and the current 238-test revision
has not yet been rerun in a fresh Docker/UVM environment.

## Phase 3A runtime image and isolated evaluation

Phase 3A adds two operator commands. They are implemented and unit-tested here.
The runtime-image command passed on a temporary Docker-capable DSec UVM; the
current strict-boundary revision still requires a fresh real-engine rerun.

```sh
# Build, start, and probe the real runtime image.
python3 scripts/verify_runtime.py --engine docker \
  --base-image ubuntu:24.04@sha256:<operator-digest> \
  --platform linux/amd64 --cpus 2 --memory 2g --pids-limit 64 \
  --report reports/verify-runtime-report.json

# Run a separate target and solver container on one internal network.
# Strict mode requires an explicit trusted holder image reference. It may be
# the same immutable image as the solver only when the operator independently
# trusts that image as executable boundary infrastructure.
python3 evaluator/container_controller.py --engine docker \
  --target-image qjs-ctf-baseline:<local-tag> \
  --solver-image <prebuilt-solver-image> \
  --holder-image <trusted-holder-image> \
  --egress-mode strict \
  --solver-json '["/opt/solve"]' --timeout 30 \
  --report reports/container-evaluation-report.json

# Probe the real-engine target/solver boundary.  --boundary-check defers the
# strict policy until trusted pre-policy controls have run in the holder
# namespace.  Every executable helper uses the resolved immutable holder image;
# the configured solver is created, inspected and removed without being run.
python3 evaluator/container_controller.py --engine docker \
  --target-image qjs-ctf-baseline:<local-tag> \
  --solver-image <prebuilt-solver-image> \
  --holder-image <trusted-holder-image> \
  --egress-mode strict --boundary-check \
  --report reports/container-boundary-report.json

# Explicit legacy development mode is non-accepting and must never be
# reported as formal isolation.
#   --egress-mode legacy   (no strict endpoint-only policy)
```

With no engine each command writes an honest `skipped` report and exits 2.
For `container_controller.py`, exit codes are `0` passed, `1` failed, `2`
skipped and `3` partial; a partial isolation result is deliberately non-zero.
The committed skipped reports are `reports/phase3a-runtime-skipped.json` and
`reports/phase3a-container-skipped.json`; they are not runtime evidence.

The runtime verifier starts the image with no published port and
`--network none`, mounts a synthetic flag read-only, and probes the service
through `docker exec`. It rejects images that declare writable `VOLUME` paths
before starting anything, and a failed log read is reported as unverified
rather than as evidence of non-disclosure. The container evaluator generates a
fresh flag per target, uses a uniquely named internal bridge, publishes no
target port, and gives the solver only `target:8000`. It rejects image-declared
volumes, disables the solver log driver, records helper ownership before each
create/start, retains provisional ownership after a failed start, and retries
cleanup after engine failures. Public solver/engine timeout summaries are
redacted to the operation category without argv or captured output. Legacy
policy install/readback failures retain only bounded, flag-redacted stderr,
stdout byte counts, and install-batch hash/rule-count metadata.

Strict mode holds the trusted idle holder's network namespace FD, verifies
its container identity and that the namespace differs from the host, enters
only that network namespace with `nsenter --net`, installs an IPv4 and an IPv6
filter table with the explicit legacy binaries, reads both back with
`iptables-legacy-save -t filter -c` / `ip6tables-legacy-save -t filter -c`,
and validates every rule and counter before any untrusted solver may start.
Each family restore is atomic; the two-family install sequence is **not**
atomic. The safety property is that only the fixed trusted idle holder exists
in the namespace until both families are installed and read back, and a failed
operation never starts the solver. Normal evaluation creates and exactly
inspects the solver, then performs one final complete live-policy revalidation
immediately before `start`.

The boundary command resolves the trusted holder reference to an immutable
image ID and uses only that ID for the sentinel and the pre-/post-policy
runtime probes. The configured solver and optional probe references never
start in boundary mode. Instead, the actual solver container follows a
`create` -> exact `inspect` -> `remove` path. The inspection requires exact
image and user identity, the sole allowed `SecurityOpt`, private PID/IPC,
read-only root, dropped/no-added capabilities, the exact `/tmp` tmpfs,
allowlisted mounts, no host binds/volumes/devices, no ports or privilege, and
the configured limits. Namespace, filesystem, secret, Docker-socket,
capability and `unshare`/`setns` runtime observations come from the trusted
holder probe; they are not presented as solver self-report. The network checks
also cover test-owned host/gateway, target-other-port, Docker DNS, loopback,
IPv6 and second-network controls. The second network is attached to the trusted
holder before enforcement so its positive control is genuinely reachable; the
same endpoint is denied after policy. If the full boundary is not proven, only
the precisely proven egress property is reported and the formal isolation gate
stays `pending`. A thrown boundary operation is recorded as structured
`failed`, not `not-run`. Boundary engine-call records are metadata-only. See
[docs/phase3a-runtime-and-isolation.md](docs/phase3a-runtime-and-isolation.md).

An internal bridge alone is not proof of endpoint-only egress. Both containers
share the host kernel, so this is a controlled CTF evaluation boundary rather
than proof of resistance to kernel escape.

## Security notes and non-goals

- There is no authentication or TLS. Binding is loopback by default; do not
  expose the adapter beyond a trusted boundary without a front proxy.
- This baseline is not a hardened multi-tenant sandbox. It relies on one
  process per connection, a 64 MiB QuickJS heap limit, a 1 MiB JS stack limit,
  bounded I/O, and an external SIGKILL timeout. It does not add seccomp,
  namespaces, cgroups, or per-connection OS users.
- Scripts can still consume CPU until the external timeout, mutate their own
  intrinsics, and exhaust runtime resources within the configured bounds.
- The adapter serializes evaluations per connection. Pipelined lines are
  processed in order.
- The container-backed evaluator is a controlled CTF boundary, not a formal
  isolation proof. Target and solver share the host kernel. Strict
  endpoint-only egress is implemented with the legacy iptables/ip6tables
  backend and natively tested; whether the real-engine boundary passes must be
  established by running the boundary command on the Docker host. Legacy
  development mode is non-accepting.
- The runtime flag is visible to a same-user process that can inspect the
  worker environment or the mounted flag file. Use a dedicated container/user
  boundary for anything real.
- The local evaluator is a same-user harness. It keeps the flag out of solver
  argv/env/cwd/stdin and public reports, but it does not provide OS-level
  isolation from another process running as the same user.
- Phase 2 does not introduce vulnerabilities, build a reference exploit, or
  implement a challenge. The two challenge variants and the two-hour authoring
  experiment remain pending in `docs/acceptance.md`.
